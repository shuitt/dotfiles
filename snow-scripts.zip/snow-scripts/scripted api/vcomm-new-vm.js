(function process(/*RESTAPIRequest*/ request, /*RESTAPIResponse*/ response) {
    // request body:
    //
    // {
    //    "vm_name": "server123",
    //    "group": "sn group name",
    //    "environ": "Production",
    //    "pd_group": "PD group",
    //    "application": "ServiceNow",
    //    "pci_pii": "NA",
    //    "ip_addr": "1.2.3.4"
    //}

    stUtils = new u_ServerTaggingUtils();
    var vcomReq = null;
    var appId = null;
    var ipAddr = null;
    var errMsg = '';
    var sText = 'vCommander new VM: Starting process:\n';

    try {
        try {
            var parser = new JSONParser();
            vcomReq = parser.parse(request.body.dataString);
        } catch(ex) {
            sText += 'ERROR Parsing string' + ex;
            gs.log(sText);
            response.setError(new sn_ws_err.BadRequestError('Error parsing JSON request body'));
            return;
        }

        var gr = new GlideRecord('u_server_tagging');
    	gr.newRecord();

        // parse the request payload
    	if (vcomReq.hasOwnProperty('vm_name')) {       // server name
            sText += 'vm_name = ' + vcomReq.vm_name + '\n';
            gr.u_server_name = vcomReq.vm_name;
        } else {
            sText += 'vm_name is missing';
            gs.log(sText);
            response.setError(new sn_ws_err.BadRequestError('The vm_name property is required'));
            return;
        }
    	if (vcomReq.hasOwnProperty('group')) {        // sn support group
            sText += 'group = ' + vcomReq.group + '\n';
            gr.u_support_group = stUtils.getGroupId(vcomReq.group);
        } else {
            sText += 'group is missing';
            gs.log(sText);
            response.setError(new sn_ws_err.BadRequestError('The group property is required'));
            return;
        }
    	if (vcomReq.hasOwnProperty('environ')) {       // environment
            sText += 'environ = ' + vcomReq.environ + '\n';
            gr.u_environment = vcomReq.environ;
        } else {
            sText += 'environ is missing';
            gs.log(sText);
            response.setError(new sn_ws_err.BadRequestError('The environ property is required'));
            return;
        }
    	if (vcomReq.hasOwnProperty('pd_group')) {       // pagerduty group
            sText += 'pd_group = ' + vcomReq.pd_group + '\n';
            gr.u_pagerduty_group = vcomReq.pd_group;
        } else {
            sText += 'pd_group is missing';
            gs.log(sText);
            response.setError(new sn_ws_err.BadRequestError('The pd_group property is required'));
            return;
        }
    	if (vcomReq.hasOwnProperty('pci_pii')) {       // pci/pii/sox
            sText += 'pci_pii = ' + vcomReq.pci_pii + '\n';
            gr.u_pci_pii_sox = vcomReq.pci_pii;
        } else {
            sText += 'pci_pii is missing';
            gs.log(sText);
            response.setError(new sn_ws_err.BadRequestError('The pci_pii property is required'));
            return;
        }
    	if (vcomReq.hasOwnProperty('application')) {        // application
            sText += 'application = ' + vcomReq.application + '\n';
            appId = stUtils.getAppId(vcomReq.application);
        } else {
            sText += 'application is missing';
            gs.log(sText);
            response.setError(new sn_ws_err.BadRequestError('The application property is required'));
            return;
        }
    	if (vcomReq.hasOwnProperty('ip_addr')) {       // ip address
            sText += 'ip_addr = ' + vcomReq.ip_addr + '\n';
            ipAddr = vcomReq.ip_addr;
        } else {
            sText += 'ip_addr is missing';
            gs.log(sText);
            response.setError(new sn_ws_err.BadRequestError('The ip_addr property is required'));
            return;
        }

    	// insert the record and set the response
        sText += 'insert server tagging record' + '\n';
    	var st_id = gr.insert();
    	if (st_id != null) {
        	sText += 'server tagging insert successful, sys_id = ' + st_id + '\n';
    		response.setStatus(201);

            // update the ips to discover table
            var ip_id = stUtils.addToIpTable(ipAddr);
            if (ip_id != null) {
                sText += 'IP address insert successful, sys_id = ' + ip_id + '\n';
            } else {
                sText += 'IP address insert failed\n';
            }

            // update the server hosting app m2m table
            if (appId != null) {
                var m2m_id = stUtils.tagToApp(st_id, appId);
                if (m2m_id != null) {
                    sText += vcomReq.vm_name + ' associated to application ' + vcomReq.application + '\n';
                } else {
                    sText += 'association of ' + vcomReq.vm_name + ' to application ' + vcomReq.application + ' failed\n';
                }
            } else {
                sText += 'application ' + vcomReq.application + ' was not found\n';
            }

    	} else {
    		sText += 'insert failed';
            var myError = new sn_ws_err.ServiceError();
            myError.setStatus(500);
            myError.setMessage('Error creating server tagging record');
            myError.setDetail('An error prevented inserting the server tagging record');
            response.setError(myError);
    	}
    } catch(ex) {   // request processing exception
        sText += 'ERROR: processing request' + ex;
        var myError = new sn_ws_err.ServiceError();
        myError.setStatus(500);
        myError.setMessage('Error processing request');
        myError.setDetail('An error occurred while processing the request');
        response.setError(myError);
    }
    gs.log(sText);
})(request, response);
