(function process(/*RESTAPIRequest*/ request, /*RESTAPIResponse*/ response) {
    var chgRec = null;
    var sText = 'RES Change: Starting process:\n';

    try {
        try {
            var parser = new JSONParser();
            chgRec = parser.parse(request.body.dataString);
        } catch(ex) {
            sText += 'ERROR Parsing string' + ex;
            gs.log(sText);
            response.setError(new sn_ws_err.BadRequestError('Error parsing JSON request body'));
            return;
        }
        var gr = new GlideRecord('change_request');
    	gr.newRecord();

    	// set default fields
    	gr.type = 'pipeline';   // if not lowercase workflow does not attach
    	gr.risk = 4;
    	gr.category = 'Software';
    	gr.backout_plan = 'See team';
    	gr.production_system = true;

        if (chgRec.hasOwnProperty('CHANGE_START_TIME')) {
    		gr.start_date = new GlideDateTime(chgRec.CHANGE_START_TIME);
    		sText += 'CHANGE_START_TIME = ' + chgRec.CHANGE_START_TIME + '\n';
    	} else {
    		gr.start_date = new GlideDateTime();
    	}
    	if (chgRec.hasOwnProperty('CHANGE_END_TIME')) {
    		gr.end_date = new GlideDateTime(chgRec.CHANGE_END_TIME);
            sText += 'CHANGE_END_TIME = ' + chgRec.CHANGE_END_TIME + '\n';
    	} else {
    		gr.end_date = new GlideDateTime();
    	}

    	// set common res fields
    	if (chgRec.hasOwnProperty('STATUS')) {
            gr.u_change_status = chgRec.STATUS;
            sText += 'STATUS: ' + chgRec.STATUS + '\n';
        }
    	if (chgRec.hasOwnProperty('CHANGE')) {
            gr.short_description = chgRec.CHANGE;
            sText += 'CHANGE = ' + chgRec.CHANGE + '\n';
        }
    	if (chgRec.hasOwnProperty('CHANGE_OWNER_NAME')) {
            var grGrp = new GlideRecord('sys_user_group');
            grGrp.addQuery('name', chgRec.CHANGE_OWNER_NAME);
            grGrp.query();
            if (grGrp.next()) {
                gr.assignment_group = grGrp.sys_id;
            }
            gr.u_change_owner_name_res = chgRec.CHANGE_OWNER_NAME;
            sText += 'CHANGE_OWNER_NAME = ' + chgRec.CHANGE_OWNER_NAME + '\n';
        }
    	if (chgRec.hasOwnProperty('APPLICATION')) {
            var grApp = new GlideRecord('u_applications');
            grApp.addQuery('name', chgRec.APPLICATION);
            grApp.query();
            if (grApp.next()) {
                gr.assignment_group = grApp.sys_id;
            } else {
                gr.cmdb_ci = 'Not Listed';
                gr.u_missing_ci = chgRec.APPLICATION;
            }
            sText += 'APPLICATION = ' + chgRec.APPLICATION + '\n';
        }
    	if (chgRec.hasOwnProperty('CHANGE_DATASOURCE')) {
            gr.u_change_datasource_res = chgRec.CHANGE_DATASOURCE;
            sText += 'CHANGE_DATASOURCE = ' + chgRec.CHANGE_DATASOURCE + '\n';
        }
    	if (chgRec.hasOwnProperty('ACTION_SOURCE')) {
            gr.u_action_source_res = chgRec.ACTION_SOURCE;
            sText += 'ACTION_SOURCE = ' + chgRec.ACTION_SOURCE + '\n';
        }
    	//if (chgRec.hasOwnProperty('ACTION_TARGET')) {
    	//	gr.u_missing_ci = chgRec.ACTION_TARGET;
    	//	gr.u_action_target_res = chgRec.ACTION_TARGET;
        //    sText += 'ACTION_TARGET = ' + chgRec.ACTION_TARGET + '\n';
    	//}
    	if (chgRec.hasOwnProperty('CHANGE_COMMENTS')) {
            gr.comments_and_work_notes = chgRec.CHANGE_COMMENTS;
            sText += 'CHANGE_COMMENTS = ' + chgRec.CHANGE_COMMENTS + '\n';
        }
    	if (chgRec.hasOwnProperty('CHANGE_DESCRIPTION')) {
            gr.description = chgRec.CHANGE_DESCRIPTION;
            sText += 'CHANGE_DESCRIPTION = ' + chgRec.CHANGE_DESCRIPTION + '\n';
        }
    	if (chgRec.hasOwnProperty('CHANGE_ENTRY_MACHINE')) {
            gr.u_change_entry_machine_res = chgRec.CHANGE_ENTRY_MACHINE;
            sText += 'CHANGE_ENTRY_MACHINE = ' + chgRec.CHANGE_ENTRY_MACHINE + '\n';
        }
    	if (chgRec.hasOwnProperty('CHANGE_ENTRY_USER_DOMAIN')) {
            gr.u_change_entry_user_domain_res = chgRec.CHANGE_ENTRY_USER_DOMAIN;
            sText += 'CHANGE_ENTRY_USER_DOMAIN = ' + chgRec.CHANGE_ENTRY_USER_DOMAIN + '\n';
        }
    	if (chgRec.hasOwnProperty('CHANGE_ENTRY_USER_MACHINE')) {
            gr.u_change_entry_machine_res = chgRec.CHANGE_ENTRY_USER_MACHINE;
            sText += 'CHANGE_ENTRY_USER_MACHINE = ' + chgRec.CHANGE_ENTRY_USER_MACHINE + '\n';
        }
    	if (chgRec.hasOwnProperty('CHANGE_ENTRY_USER')) {
            gr.u_change_entry_user_res = chgRec.CHANGE_ENTRY_USER;
            sText += 'CHANGE_ENTRY_USER = ' + chgRec.CHANGE_ENTRY_USER + '\n';
        }
    	if (chgRec.hasOwnProperty('CHANGE_LOCATION')) {
            gr.u_change_location_res = chgRec.CHANGE_LOCATION;
            sText += 'CHANGE_LOCATION = ' + chgRec.CHANGE_LOCATION + '\n';
        }
    	if (chgRec.hasOwnProperty('CHANGE_MACHINE_IP')) {
            gr.u_change_machine_ip_address_res = chgRec.CHANGE_MACHINE_IP;
            sText += 'CHANGE_MACHINE_IP = ' + chgRec.CHANGE_MACHINE_IP + '\n';
        }

    	// jenkins only fields
    	if (chgRec.hasOwnProperty('BUILD_ID')) {
            gr.u_jenkins_build_id_res = chgRec.BUILD_ID;
            sText += 'BUILD_ID: ' + chgRec.BUILD_ID + '\n';
        }
    	if (chgRec.hasOwnProperty('BUILD_NUMBER')) {
    		gr.u_version = 'Build number ' + chgRec.BUILD_NUMBER;
    		gr.u_jenkins_build_number_res = chgRec.BUILD_NUMBER;
            sText += 'BUILD_NUMBER: ' + chgRec.BUILD_NUMBER + '\n';
    	}
    	if (chgRec.hasOwnProperty('BUILD_TAG')) {
            gr.u_jenkins_build_tag_res = chgRec.BUILD_TAG;
            sText += 'BUILD_TAG: ' + chgRec.BUILD_TAG + '\n';
        }
    	if (chgRec.hasOwnProperty('BUILD_URL')) {
            gr.u_jenkins_build_url_res = chgRec.BUILD_URL;
            sText += 'BUILD_URL: ' + chgRec.BUILD_URL + '\n';
        }
    	if (chgRec.hasOwnProperty('EXECUTOR_NUMBER')) {
            gr.u_jenkins_executor_number_res = chgRec.EXECUTOR_NUMBER;
            sText += 'EXECUTOR_NUMBER: ' + chgRec.EXECUTOR_NUMBER + '\n';
        }
    	if (chgRec.hasOwnProperty('JENKINS_URL')) {
            gr.u_jenkins_url_res = chgRec.JENKINS_URL;
            sText += 'JENKINS_URL: ' + chgRec.JENKINS_URL + '\n';
        }
    	if (chgRec.hasOwnProperty('JOB_URL')) {
            gr.u_jenkins_job_url_res = chgRec.JOB_URL;
            sText += 'JOB_URL: ' + chgRec.JOB_URL + '\n';
        }
    	if (chgRec.hasOwnProperty('NODE_LABELS')) {
            gr.u_jenkins_node_labels_res = chgRec.NODE_LABELS;
            sText += 'NODE_LABELS: ' + chgRec.NODE_LABELS + '\n';
        }
    	if (chgRec.hasOwnProperty('NODE_NAME')) {
            gr.u_jenkins_node_name_res = chgRec.NODE_NAME;
            sText += 'NODE_NAME: ' + chgRec.NODE_NAME + '\n';
        }

    	// insert the record and set the response
        sText += 'insert change request record' + '\n';
    	id = gr.insert();
    	if (id != null) {
        	sText += 'insert successful, sys_id = ' + id + '\n';
    		response.setStatus(201);
    	} else {
    		sText += 'insert failed';
            var myError = new sn_ws_err.ServiceError();
            myError.setStatus(500);
            myError.setMessage('Error creating change request');
            myError.setDetail('An error prevented inserting the new change request record');
            response.setError(myError);
    	}
    } catch(ex) {   // request processing exception
        sText += 'ERROR: processing request' + ex;
        var myError = new sn_ws_err.ServiceError();
        myError.setStatus(500);
        myError.setMessage('Error processing request');
        myError.setDetail('An error occurred while processing the request');
        response.setError(myError);
    }
    gs.log(sText);
})(request, response);
