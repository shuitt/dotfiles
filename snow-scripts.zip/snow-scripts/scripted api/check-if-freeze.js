(function process(/*RESTAPIRequest*/ request, /*RESTAPIResponse*/ response) {
    // request body:
    // {
    //    "group": "assignment_group_name"
    // }
    //

    var sText = 'Checking if in a change freeze window:\n';
    var req = null;
    var group = null;
    var errMsg = '';
    var badReq = false;

    // just in case there's an error
    var myError = new sn_ws_err.ServiceError();
    myError.setStatus(500);
    myError.setMessage('Request failed');

    try {
        try {
            var parser = new JSONParser();
            req = parser.parse(request.body.dataString);
        } catch(ex) {
            sText += 'ERROR Parsing string' + ex;
            gs.log(sText);
            response.setError(new sn_ws_err.BadRequestError('Error parsing JSON request body: ' + ex));
            return;
        }

    	if (req.hasOwnProperty('group')) {       // group name
            sText += 'group = ' + req.group + '\n';
            group = req.group;
            if (gs.nil(group)) {   // teh group proerty is null
                sText += 'ERROR: processing request update failed - group property is null';
                gs.log(sText);
                myError.setDetail('Request failed: the group property was null');
                response.setError(myError);
                return;
            } else {   // check if group exists
                var grp = new GlideRecord('sys_user_group');
                grp.addQuery('name', group);
                grp.query();
                if (!grp.hasNext()) {    // grop does not exist
                    sText += 'ERROR: group ' + group + ' does not exist';
                    gs.log(sText);
                    myError.setDetail('Request failed: group ' + group + ' does not exist');
                    response.setError(myError);
                    return;
                }
            }
        } else {  // the group property was not provided
            sText += 'ERROR: The group property is required';
            gs.log(sText);
            myError.setDetail('Request failed: the group property is required');
            response.setError(myError);
            return;
        }
    } catch(ex) {   // request processing exception
        sText += 'ERROR: exception occured processing request' + ex;
        myError.setDetail('An error occurred while processing the request: ' + ex);
        response.setError(myError);
        return;
    }

    var today = new GlideDateTime();
    // ensure we're dealing in local time
    var chktime = new GlideDateTime(today.getLocalDate() + ' ' + today.getUserFormattedLocalTime());
    sText += 'Current datetime = ' + chktime.getValue() + '\n';
    var encQuery = 'type=awareness^ORtype=soft_freeze^ORtype=hard_freeze^ORtype=2_vp_freeze';
    var gr = new GlideRecord('cmn_schedule');
    gr.addEncodedQuery(encQuery);
    gr.query();

    var sched = new GlideSchedule();
    var results = {
        freezes: []
        };

    // check if any freeze schedule includes current date and time
    while (gr.next()) {
        sched.load(gr.sys_id);
        if (sched.isInSchedule(chktime)) {
            results.freezes.push({
                                     schedule: sched.getName(),
                                     type: gr.type.toString()
                                 });
        }
    }
    
    sText += 'Response = ' + JSON.stringify(results);
    gs.log(sText);
    response.setStatus(200);
    response.setBody(results);
})(request, response);
