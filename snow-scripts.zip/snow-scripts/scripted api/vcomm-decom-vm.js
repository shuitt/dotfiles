(function process(/*RESTAPIRequest*/ request, /*RESTAPIResponse*/ response) {
    // request body:
    // {
    //    "vm_name": "server123"
    // }
    //

    var vcomReq = null;
    var errMsg = '';
    var badReq = false;
    var sText = 'vCommander decommission VM: Starting process:\n';
    stUtils = new u_ServerTaggingUtils();

    try {
        try {
            var parser = new JSONParser();
            vcomReq = parser.parse(request.body.dataString);
        } catch(ex) {
            sText += 'ERROR Parsing string' + ex;
            gs.log(sText);
            response.setError(new sn_ws_err.BadRequestError('Error parsing JSON request body'));
            return;
        }

    	if (vcomReq.hasOwnProperty('vm_name')) {       // server name
            sText += 'vm_name = ' + vcomReq.vm_name + '\n';
            var id = stUtils.dcomTaggedServer(vcomReq.vm_name);
            if (id != null) {
				response.setStatus(201);
                sText += 'update successful, sys_id = ' + id + '\n';
            } else {
                sText += 'ERROR: processing request update failed for ' + vcomReq.vm_name;
                var myError = new sn_ws_err.ServiceError();
                myError.setStatus(500);
                myError.setMessage('Update failed');
                myError.setDetail('An error occurred updating the server tagging record for ' + vcomReq.vm_name);
                response.setError(myError);
            }
        } else {
            sText += 'ERROR: The vm_name property is required';
            response.setError(new sn_ws_err.BadRequestError('The vm_name property is required'));
            return;
        }
    } catch(ex) {   // request processing exception
        sText += 'ERROR: exception occured processing request' + ex;
        var myError = new sn_ws_err.ServiceError();
        myError.setStatus(500);
        myError.setMessage('Error processing request');
        myError.setDetail('An error occurred while processing the request: ' + ex);
        response.setError(myError);
    }
    gs.log(sText);
})(request, response);
