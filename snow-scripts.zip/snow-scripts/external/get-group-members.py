#!/usr/bin/env python3

import requests

# Set the request parameters
url = 'https://nordstromtest.service-now.com/api/now/table/sys_user_grmember?sysparm_display_value=all&sysparm_fields=user%2Cuser.employee_number%2Cuser.email%2Cgroup' #&sysparm_limit=10'

# Eg. User name="admin", Password="admin" for this code sample.
user = 'steve.huitt@nordstrom.com'
#pwd = 'Yzygxwcs5*WCf$'
pwd = 'y@%gA!Z7$Q@4mP'

# Set proper headers
headers = {"Content-Type":"application/json","Accept":"application/json"}

# Do the HTTP request
response = requests.get(url, auth=(user, pwd), headers=headers )

# Check for HTTP codes other than 200
if response.status_code != 200:
    print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())
    exit()

# Decode the JSON response into a dictionary and use the data
data = response.json()
members = data['result']
print('Group\tsys_id\tUser\tEmployee Number\tEmail')
for member in members:
    if member['group']['display_value'] != 'Nordstrom - All' and member['group']['display_value'] != 'ServiceNow Training':
        print(member['group']['display_value'] + '\t' +
              member['group']['value'] + '\t' +
              member['user']['display_value'] + '\t' +
              member['user.employee_number']['value'] + '\t' +
              member['user.email']['value'] + '\t')
