#!/usr/bin/env python3

import requests

# Set the request parameters
url = 'https://nordstromtest.service-now.com/api/now/table/sys_group_has_role?sysparm_fields=role.name%2Crole.sys_id%2Cgroup.name%2Cgroup.sys_id&sysparm_limit=10'

# Eg. User name="admin", Password="admin" for this code sample.
user = 'steve.huitt@nordstrom.com'
#pwd = 'Yzygxwcs5*WCf$'
pwd = 'y@%gA!Z7$Q@4mP'

# Set proper headers
headers = {"Content-Type":"application/json","Accept":"application/json"}

# Do the HTTP request
response = requests.get(url, auth=(user, pwd), headers=headers )

# Check for HTTP codes other than 200
if response.status_code != 200:
    print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())
    exit()

# Decode the JSON response into a dictionary and use the data
data = response.json()
group_roles = data['result']
print('Role\tRole sys_id\tGroup\tGroup sys_id')
for group_role in group_roles:
    print(group_role['role.name'] + '\t' +
          group_role['role.sys_id'] + '\t' +
          group_role['group.name'] + '\t' +
          group_role['group.sys_id'] + '\t')
