#!/usr/bin/env python3

import csv
from datetime import datetime

IN_USERS = '/Users/xsmh/Downloads/SN/Data Imports/H6WS110_Extract_20170501.csv'
OUT_USERS = '/Users/xsmh/Downloads/SN/Data Imports/users.txt'

IN_FIRMS = '/Users/xsmh/Downloads/SN/Data Imports/contracting-firms.txt'
IN_JOBS = '/Users/xsmh/Downloads/SN/Data Imports/Loaded/get_job_list.UAT6.20161202.csv'
IN_DEPTS = '/Users/xsmh/Downloads/SN/Data Imports/Loaded/get_hr_organization_list.UAT6.20161202.csv'
IN_LOCS = '/Users/xsmh/Downloads/SN/Data Imports/Loaded/get_location_list.UAT6.20161202.csv'

KEEP_TYPES = ['contractor', 'cosmetic vendor speciality', 'designer boutique',
              'designer boutique dis', 'employee', 'nfcu', 'trunk club']

HEADER = ['Employee number', 'LAN ID', 'First name', 'Middle name', 'Last name', 'Preferred name', 'User type', 'Hire date',
          'Termination date', 'Projected assignment end date', 'Email', 'Business phone', 'Business TIE line', 'Onsite contractor',
          'Company', 'Manager', 'Department', 'Location', 'Job', 'Person ID', 'User ID']

vendor_dict = {}
job_dict = {}
dept_dict = {}
loc_dict = {}

#------------------------------------------------------------------------------
# read a csv file into a list
#------------------------------------------------------------------------------
def getList(file_name):
    print('Reading CSV file', file_name)
    with open(file_name, 'r') as f:
        reader = csv.reader(f)
        the_list = list(reader)
    f.close()
    print('%d rows read from CSV file' % len (the_list))
    return the_list



#------------------------------------------------------------------------------
# read a csv file into a list
#------------------------------------------------------------------------------
def getListTsv(file_name):
    print('Reading TSV file', file_name)
    with open(file_name, 'r') as f:
        reader = csv.reader(f, dialect="excel-tab")
        the_list = list(reader)
    f.close()
    print('%d rows read from TSV file' % len (the_list))
    return the_list

#------------------------------------------------------------------------------
# write user data to csv file
#------------------------------------------------------------------------------
#  user list elements               out_row list elements
#  0 EMP_CWK_NUMBER	            ->  0 Employee number
#  1 LAN_ID                     ->  1 LAN ID
#  2 FIRST_NAME                 ->  2 First name
#  3 MIDDLE_NAME                ->  3 Middle name
#  4 LAST_NAME                  ->  4 Last name
#  5 PREFERRED_NAME             ->  5 Preferred name
#  6 USER_PERSON_TYPE           ->  6 User type
#  8 HIRE_DATE                  ->  7 Hire date
#  9 TERMINATION_DATE           ->  8 Termination date
# 10 CWK_PROJECTED_END_DATE     ->  9 Projected assignment end date
# 11 CORPORATE_EMAIL            -> 10 Email
# 12 WORK_PHONE                 -> 11 Business phone
# 13 WORK_TIE_LINE              -> 12 Business TIE line
# 16 ONSITE_FLAG                -> 13 Onsite contractor
# 17 CWK_VENDOR_ID              -> 14 Company
# 18 MGR_EMP_NUMBER             -> 15 Manager
# 20 ORGANIZATION_ID            -> 16 Department
# 28 LOCATION_ID                -> 17 Location
# 31 JOB_ID                     -> 18 Job
# 34 PERSON_ID                  -> 19 Person ID
# 11 CORPORATE_EMAIL            -> 20 User ID

def makeUserCsv(user_list, out_file):
    print('Writing CSV file', out_file)
    user_count = 0
    with open(out_file, 'w', newline='') as f:
        writer = csv.writer(f, dialect="excel-tab")
        writer.writerow(HEADER)
        out_row = [''] * len(HEADER)
        for user in user_list:
            if user[6].lower() in KEEP_TYPES:
                out_row[0] = user[0]           # Employee number
                out_row[1] = user[1]           # LAN ID
                out_row[2] = user[2]           # First name
                out_row[3] = user[3]           # Middle name
                out_row[4] = user[4]           # Last name
                out_row[5] = user[5]           # Preferred Name
                out_row[6] = user[6]           # User type
                out_row[7] = makeDate(user[8])      # Hire date
                out_row[8] = makeDate(user[9])      # Termonation date
                out_row[9] = makeDate(user[10])     # Projected assignment end date
                out_row[10] = user[11].lower()  # Email
                out_row[20] = user[11].lower()  # user ID
                out_row[11] = user[12]          # Business phone
                out_row[12] = user[13]          # Business TIE line
                out_row[14] = 'Nordstrom, Inc.' # company (default)
                out_row[15] = user[18]          # Manager (mgr emp nbr)
                out_row[17] = user[28]          # Location (location id)
                out_row[18] = user[31]          # Job (job id)
                out_row[19] = user[34]          # Person ID

                if user[16] == '':              # Consite contractor
                    out_row[13] = ''
                elif user[16] == 'Y':
                    out_row[13] = 'Yes'
                else:
                    out_row[13] = 'No'

                if user[17] != '':              # Company
                    if user[17] in vendor_dict:
                        out_row[14] = vendor_dict[user[17]]
                    else:
                        out_row[14] = ''

                if user[20] != '0' and user[20] != '':    # Department
                    out_row[16] = user[20]
                else:
                    out_row[16] = ''
                writer.writerow(out_row)
                user_count += 1
    print('%d user rows written' % user_count)
    f.close()

#------------------------------------------------------------------------------
# create a dictionary of vendors
# params: vendor_list - list with vendor info
#------------------------------------------------------------------------------
def makeVendorDict(vendor_list):
    del vendor_list[0]
    for vendor in vendor_list:
        vendor_dict[vendor[0]] = vendor[2] # map VENDOR_ID to VENDOR_NAME
    print("%d contracting firms loaded" % len (vendor_dict))

#------------------------------------------------------------------------------
# create a dictionary of jobs
# params: job_list - list with job info
#------------------------------------------------------------------------------
def makeJobDict(job_list):
    del job_list[0]
    for job in job_list:
        job_dict[job[0]] = job[4] # map HR_JOB_ID to JOB_TITLE_DESC
    print("%d jobs loaded" % len (job_dict))

#------------------------------------------------------------------------------
# create a dictionary of departments
# params: dept_list - list with department info
#------------------------------------------------------------------------------
def makeDeptDict(dept_list):
    del dept_list[0]
    for dept in dept_list:
        dept_dict[dept[0]] = dept[1] # map HR_ORGANIZATION_ID to HR_ORGANIZATION_NAME
    print("%d departments loaded" % len (dept_dict))

#------------------------------------------------------------------------------
# create a dictionary of locations
# params: loc_list - list with location info
#------------------------------------------------------------------------------
def makeLocationDict(loc_list):
    del loc_list[0]
    for loc in loc_list:
        loc_dict[loc[0]] = loc[2] # map HR_LOCATION_ID to HR_LOCATION_DESC
    print("%d locations loaded" % len (loc_dict))

#------------------------------------------------------------------------------
# return a datetime object for the specified string
# params: date_string - a string datetime value
#------------------------------------------------------------------------------
def makeDate(date_string):
    #2014-05-23T00:00:00.000-07:00
    if date_string == '':
        return ''
    return datetime.strptime(date_string[:-10], '%Y-%m-%dT%H:%M:%S')

#-----------------------------------------------------------------------------
# main program logic
#------------------------------------------------------------------------------
if __name__ == '__main__':
    print('Script staring')
    #vendor_list = getListTsv(IN_FIRMS)
    #makeVendorDict(vendor_list)
    # job_list = getList(IN_JOBS)
    # makeJobDict(job_list)
    # dept_list = getList(IN_DEPTS)
    # makeDeptDict(dept_list)
    # loc_list = getList(IN_LOCS)
    # makeLocationDict(loc_list)
    user_list = getList(IN_USERS)
    makeUserCsv(user_list, OUT_USERS)
    print('Script completed')
