#!/usr/bin/env python3

import socket
import csv
import requests

#SERVERS = '/Users/xsmh/Downloads/st.csv'
#SERVERS = '/Users/xsmh/Downloads/st-test.csv'
SERVERS = '/Users/xsmh/Downloads/st-prod.csv'
#URL = 'https://nordstromdev.service-now.com/api/nords/v1/vcommander/decomvm'
#URL = 'https://nordstromtest.service-now.com/api/nords/v1/vcommander/decomvm'
URL = 'https://nordstrom.service-now.com/api/nords/v1/vcommander/decomvm'

USER = 'steve.huitt@nordstrom.com'
PWD = ''     # local SN password for instance
HEADERS = {"Content-Type":"application/json","Accept":"application/json"}

#------------------------------------------------------------------------------
# read a csv file into a list
#------------------------------------------------------------------------------
def getList(file_name):
    print('Reading CSV file', file_name)
    with open(file_name, 'r') as f:
        reader = csv.reader(f)
        the_list = list(reader)
    f.close()
    print('%d rows read from CSV file' % len (the_list))
    return the_list

#------------------------------------------------------------------------------
# check the list of servers
#------------------------------------------------------------------------------
def chkServers(server_list):
    for server in server_list:
        (found, ip) = chkDns(server[0])
        if found:
            print(server[0] + ' found in DNS, IP address is ' + ip)
        else:
            print(server[0] + ' is not in DNS')
            decomServer(server[0])

#------------------------------------------------------------------------------
# check dns for the server name
#------------------------------------------------------------------------------
def chkDns(server):
    try:
        ip = socket.gethostbyname(server)
        return (True, ip)
    except Exception:  # when host name not in dns
        return (False, '')

#------------------------------------------------------------------------------
# check dns for the server name
#------------------------------------------------------------------------------
def decomServer(server):
    data = '{"vm_name":"' + server + '"}'
    response = requests.post(URL, auth=(USER, PWD), headers=HEADERS ,data=data)

    # Check for HTTP codes other than 201
    if response.status_code == 201:
        print('Server ' + server + ' successfully decommed')
    else:
        print('Error updating server ' + server + ', Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())

#-----------------------------------------------------------------------------
# main program logic
#------------------------------------------------------------------------------
if __name__ == '__main__':
    print('Script staring')
    server_list = getList(SERVERS)
    chkServers(server_list)
