#!/usr/bin/env python3

import requests

# Set the request parameters
url = 'https://nordstromtest.service-now.com/api/now/table/sys_user_group?sysparm_display_value=&sysparm_fields=name%2Csys_id%2Cemail%2Cmanager.name%2Cmanager.email%2Cmanager.employee_number%2Cu_director.name%2Cu_director.email%2Cu_director.employee_number%2Cx_pd_integration_pagerduty_service%2C%20x_pd_integration_pagerduty_escalation' #&sysparm_limit=10'

# Eg. User name="admin", Password="admin" for this code sample.
user = 'steve.huitt@nordstrom.com'
#pwd = 'Yzygxwcs5*WCf$'
pwd = 'y@%gA!Z7$Q@4mP'

# Set proper headers
headers = {"Content-Type":"application/json","Accept":"application/json"}

# Do the HTTP request
response = requests.get(url, auth=(user, pwd), headers=headers )

# Check for HTTP codes other than 200
if response.status_code != 200:
    print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())
    exit()

# Decode the JSON response into a dictionary and use the data
data = response.json()
groups = data['result']
print('Group\tsys_id\tEmail\tMgr\tMgr Empnbr\tMgr Email\tDir\tDir Empnbr\tDir Email\tPD Service\tPD Escalation')
for group in groups:
    print(group['name']+ '\t' +
          group['sys_id']+ '\t' +
          group['email']+ '\t' +
          group['manager.name']+ '\t' +
          group['manager.employee_number']+ '\t' +
          group['manager.email']+ '\t' +
          group['u_director.name']+ '\t' +
          group['u_director.employee_number']+ '\t' +
          group['u_director.email']+ '\t' +
          group['x_pd_integration_pagerduty_service']+ '\t' +
          group['x_pd_integration_pagerduty_escalation']+ '\t')
