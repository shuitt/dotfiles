#!/usr/bin/env python3
import requests
import os
import logging
import json
import time

#------------------------------------------------------------------------------
# this program creates servicenow mib records for every mib file found is a
# directory. it:
# 1. ges a list of every file in the specified directory
# 2. for each file check if a mib record with a matching name exists
# 3. creates a mib record for each file where a matching record does not exists
# 4. attaches the mib file to teh newly created mib record
# 5. updates the newly created mib to active
#
# simple improvements that could/should be made:
# 1. provide the directory name, servicenow instance name, user name, password
#    and log file name as command line arguments
# 2. check for http 429 errors (too may requests) and retry when encountered
#------------------------------------------------------------------------------
# constants
#------------------------------------------------------------------------------

#INSTANCE = 'nordstromdev'
#INSTANCE = 'nordstromtest'
#INSTANCE = 'nordstrom'
#INSTANCE = 'dev25530'

BASE_MIB_URL = 'https://' + INSTANCE + '.service-now.com/api/now/table/ecc_agent_mib'
BASE_ATT_URL = 'https://' + INSTANCE + '.service-now.com/api/now/attachment/file?table_name=ecc_agent_mib&table_sys_id='
HEADERS = {'Content-Type': 'application/json', 'Accept': 'application/json'}

USER = 'sn user name'       # this user needs a local password and admins rights
PASS = 'sn user password'   # local servicenow password, not sso

PATH = '/Users/xsmh/Downloads/MIBs/sn'          # directory contaning the mib files
LOG_FILE = '/Users/xsmh/Downloads/SN/scratch/mib-upload-' + INSTANCE + '.log'

#------------------------------------------------------------------------------
# get a list of files in a directory
# args: path - a directory containing mib-upload files
# returns: a dictionary with mib file names as keys
#------------------------------------------------------------------------------
def getFiles(path):
    flist = os.listdir(path)
    # create a dict with key = MIB name and value = 0
    fdict = {key: 0 for key in flist}
    logger.info('Found %d files' % (len(fdict)))
    return fdict

#------------------------------------------------------------------------------
# create new mib records in the ecc_agent_mib table
# args: fdict - a dictionary with mib file names as keys
# returns: a dictionary with mib file names as keys and mib record sys_ids as values
#------------------------------------------------------------------------------
def createMibRecs(fdict):
    logger.debug('In createMibRecs()')
    counter = 0
    for key, value in fdict.items():
        if not mibExists(key):
            logger.debug('Create MIB record for %s' % (key))
            payload = {'sysparm_fields': 'sys_id'}
            data = "{'name': '" + key + "', 'description': 'MIB file " + key + " from NNM', 'source': 'Exported from NNM'}"
            response = requests.post(BASE_MIB_URL, auth=(USER, PASS), headers=HEADERS, data=data, params=payload)
            logger.debug('URL: %s' % (response.url))
            logger.debug('Status code is %d' % (response.status_code))
            logger.debug('Response body: %s' % (response.text))
            if response.status_code == 201:
                body = json.loads(response.text)
                result = body['result']
                if len(result) > 0:
                    fdict[key] = result['sys_id']   # set the value to the mib rec sys_id
                    counter += 1
                    logger.info('MIB record %s created' % (key))
                else:
                    logger.error('Got a 201 status but no sys_id - record creation failed for MIB %s?' % (key))
            else:
                logger.error('MIB record creation failed for %s' % (key))
        else:
            logger.info('MIB record already exists for %s' % (key))

    logger.info('Created %d new MIB records' % (counter))
    return fdict

#------------------------------------------------------------------------------
# see if a mib record exists
# args: mibName - the mib name to check for
# returns: reue if mib exists, false otherwise
#------------------------------------------------------------------------------
def mibExists(mibName):
    logger.debug('In mibExists()')
    payload = {'sysparm_query': 'name=' + mibName, 'sysparm_fields': 'sys_id'}
    response = requests.get(BASE_MIB_URL, auth=(USER, PASS), headers=HEADERS, params=payload)
    logger.debug('URL: %s' % (response.url))
    logger.debug('Status code is %d' % (response.status_code))
    logger.debug('Response body: %s' % (response.text))
    body = json.loads(response.text)
    result = body['result']
    if len(result) > 0:
        logger.debug('Found MIB %s' % (mibName))
        return True
    else:
        logger.debug('Did not find MIB %s' % (mibName))
        return False

#------------------------------------------------------------------------------
# upload mib files as attachements to mib records
# args: fdict - a dictionary with mib file names as keys and mib record sys_ids as values
# returns: nothing
#------------------------------------------------------------------------------
def uploadMibFiles(fdict):
    logger.debug('In uploadMibFiles()')
    counter = 0
    for key, value in fdict.items():
        if value != 0:
            logger.debug('Upload MIB file %s with sys_id=%s' % (key, value))
            url = BASE_ATT_URL + value + '&file_name=' + key
            logger.debug('Upload URL is %s' % (url))
            data = open(PATH + '/' + key, 'rb').read()
            response = requests.post(url, auth=(USER, PASS), headers=HEADERS, data=data)
            logger.debug('Status code is %d' % (response.status_code))
            logger.debug('Response body: %s' % (response.text))
            if response.status_code == 201:
                logger.info('MIB file %s successfully uploaded' % (key))
                counter += 1
            else:
                logger.error('Error uploading MIB file %s, HTTP status is %d' % (key, response.status_code))
        else:
            logger.debug('Skip upload of MIB file %s' % (key))

    logger.info('Attached %d MIB files' % (counter))
    return

#------------------------------------------------------------------------------
# change the status of mib records to active
# args: fdict - a dictionary with mib file names as keys and mib record sys_ids as values
# returns: nothing
#------------------------------------------------------------------------------
def makeMibsActive(fdict):
    logger.debug('In makeMibsActive()')
    counter = 0
    for key, value in fdict.items():
        if value != 0:
            payload = {'sysparm_fields': 'active'}
            data = "{'active': 'true'}"
            url = BASE_MIB_URL + '/' + value
            response = requests.put(url, auth=(USER, PASS), headers=HEADERS, data=data, params=payload)
            logger.debug('URL: %s' % (response.url))
            logger.debug('Status code is %d' % (response.status_code))
            logger.debug('Response body: %s' % (response.text))
            logger.debug('Set MIB %s to active' % (key))
            if response.status_code == 200:
                logger.info('MIB record %s set to Active' % (key))
                counter += 1
            else:
                logger.error('Setting MIB record %s to Active failed' % (key))

    logger.info('Set %d MIB records to Active' % (counter))
    return

#------------------------------------------------------------------------------
# configure logging
# args: none
# returns: a Logger object
#------------------------------------------------------------------------------
def configLogger():
    logger = logging.getLogger('mib-upload')
    fh = logging.FileHandler(LOG_FILE)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    return logger

#------------------------------------------------------------------------------
#  main program logic
#------------------------------------------------------------------------------
if __name__ == '__main__':
    logger = configLogger()
    logger.setLevel(logging.INFO)
    #logger.setLevel(logging.DEBUG)
    logger.info('Starting MIB upload to instance %s' % (INSTANCE))
    fdict = getFiles(PATH)
    fdict = createMibRecs(fdict)
    uploadMibFiles(fdict)
    makeMibsActive(fdict)
    logger.info('MIB uploading complete')
