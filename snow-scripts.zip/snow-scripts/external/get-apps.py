#!/usr/bin/env python3

import requests

# Set the request parameters
url = 'https://nordstrom.service-now.com/api/now/table/u_applications?sysparm_fields=u_long_name%2Csys_id'

# Eg. User name="admin", Password="admin" for this code sample.
user = 'steve.huitt@nordstrom.com'
#pwd = 'Yzygxwcs5*WCf$'
#pwd = 'y@%gA!Z7$Q@4mP'
pwd = 'k3xyn&T!WzsG8j'

# Set proper headers
headers = {"Content-Type":"application/json","Accept":"application/json"}

# Do the HTTP request
response = requests.get(url, auth=(user, pwd), headers=headers )

# Check for HTTP codes other than 200
if response.status_code != 200:
    print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())
    exit()

# Decode the JSON response into a dictionary and use the data
data = response.json()
apps = data['result']
print('Application\tsys_id')
for app in apps:
#for i in range(0, len(data)):
    print(app['u_long_name']+ '\t' + app['sys_id'])
