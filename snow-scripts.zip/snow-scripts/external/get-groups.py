#!/usr/bin/env python3

import requests

# Set the request parameters
url = 'https://nordstromtest.service-now.com/api/now/table/sys_user_group?sysparm_fields=name%2Csys_id'

# Eg. User name="admin", Password="admin" for this code sample.
user = 'steve.huitt@nordstrom.com'
#pwd = 'Yzygxwcs5*WCf$'
pwd = 'y@%gA!Z7$Q@4mP'

# Set proper headers
headers = {"Content-Type":"application/json","Accept":"application/json"}

# Do the HTTP request
response = requests.get(url, auth=(user, pwd), headers=headers )

# Check for HTTP codes other than 200
if response.status_code != 200:
    print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())
    exit()

# Decode the JSON response into a dictionary and use the data
data = response.json()
groups = data['result']
print('sys_id\tGroup')
for group in groups:
#for i in range(0, len(data)):
    print(group['name']+ '\t' + group['sys_id'])
