var catRoleId = '098ecf6c0a80165002aaec84d906014';
var test1ID = '4b936715db3132002914788dbf961979';
var test2ID = 'c4b36715db3132002914788dbf96197c';
var roles = [test1ID, test2ID];
//inherited
var userGR = new GlideRecord ("sys_user_has_role");
var gr = new GlideRecord("sys_user");
gr.setLimit(10);
gr.query();
var rec = 0;
while(gr.next()) {
    userGR.intialize();
    userGR.user = gr.getUniqueValue();
    userGR.role = roles[rec];
    userGR.insert();
    gs.print('Added ' + roles[rec] + ' role to user:' + userGR.user.getDisplayValue());
    rec += 1;
}

gs.print('Removing directly assigned test_role_1:');
var userGR = new GlideRecord ("sys_user_has_role");
userGR.addEncodedQuery('role.nameSTARTSWITHtest_role_1^inherited=false');
userGR.query();
while (userGR.next()) {
    gs.print(userGR.user.user_name);
    userGR.deleteRecord();
}

// this script will remove the catalog role from users

(function(){
    // remove the catalog role from users where directly assigned (inherit == false)
    var catRoleId = 'e098ecf6c0a80165002aaec84d906014'; // sys_id for catalog role
    var gr = new GlideRecord ('sys_user_has_role');
    gr.addQuery('role', catRoleId);
    gr.addQuery('inherited', false);
    gr.query();
    gs.print('Found ' + gr.getRowCount() + ' users directly assigned the catalog role');
    while (gr.next()) {
        gr.deleteRecord();
    }
}())

// this script will add users to the Nordstorm - All group

(function(){
    // add all users to the 'Nordstrom - all' group
    function inGroup(grpID, user) {
        var gr = new GlideRecord ('sys_user_grmember');
        gr.addQuery('group', grpID);
        gr.addQuery('user', user);
        gr.query();
        if (gr.next()) {
            return true;
        } else {
            return false;
        }
    }

    var grpID = '7767f219db71f280cdf5f8fdae9619c2';  // sys_id for Nordstorm- All group
    var grUser = new GlideRecord ('sys_user');
    var grMbrs = new GlideRecord ('sys_user_grmember');
    grUser.query();
    gs.print('Found ' + grUser.getRowCount() + ' users');
    while (grUser.next()) {
        if (!inGroup(grpID, grUser.getUniqueValue())) {
            grMbrs.initialize();
            grMbrs.group = grpID;
            grMbrs.user = grUser.getUniqueValue();
            grMbrs.insert();
        }
    }

    grMbrs = new GlideRecord ('sys_user_grmember');
    grMbrs.addQuery('group', grpID);
    grMbrs.query();
    gs.print('Group has ' + grMbrs.getRowCount() + ' members');
}())
