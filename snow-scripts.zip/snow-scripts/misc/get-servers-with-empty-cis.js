(function(){
    var grSt = new GlideRecord('u_server_tagging');

    grSt.addEncodedQuery('u_server_ciISEMPTY^u_decommissioned=false');
    grSt.query();
    while (grSt.next()) {
        gs.print(grSt.u_server_name + '\t' + grSt.getUniqueValue());
    }
}())
