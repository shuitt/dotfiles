(function(){
    function getTypeId(type) {
        var id = null;
        var gr = new GlideRecord('sys_user_group_type');
        gr.addQuery('name', type);
        gr.query();
        if (gr.next()) {
            id = gr.getUniqueValue();
        }
        gs.print('sys_id for the ' + type + ' group type is ' + id);
        return id;
    }

    var si_id = getTypeId('security incident');
    var itil_id = getTypeId('itil');
    var resp_id = getTypeId('response_task');

    var gr = new GlideRecord ('sys_user_group');
    gr.orderBy('name');
    gr.query();
    while (gr.next()) {
        gs.print('Group: ' + gr.name + ', Type: ' + gr.type);
        var types = gr.type.toString().split(",");
        if (gr.type.toString().includes(itil_id)) {
            gs.print('    has the itil type');
            if (gr.type.toString().includes(resp_id)) {
                gs.print('    already has the response task type');
            } else {
                gs.print('    add the response task type');
                var newType = types.join(",") + ',' + resp_id
                gs.print('    old type: ' + gr.type);
                gs.print('    new type: ' + newType);
                gr.type = newType;
                gr.update();
            }
        } else {
            gs.print('    DOES NOT have the itil type');
        }
    }
}())
