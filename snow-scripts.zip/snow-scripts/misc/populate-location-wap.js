(function(){
	gWap = new GlideRecord('cmdb_ci_wap_network');  // wireless ap table
	gWc = new GlideRecord('u_cmdb_ci_wireless_controller');  // wireless controller table
	gWap.addEncodedQuery('location=false^ORlocationISEMPTY');
	gWap.query();
	gs.print('Found ' + gWap.getRowCount() + ' wireless access points without location');
	// *** Script: Found 1598 wireless access points without location
	while (gWap.next()) {
		gWc.initialize();
		gWc.addQuery('sys_id', gWap.u_wireless_controller);
		gWc.query();
		if (gWc.next()) {
			gs.print('Update AP ' + gWap.name + ' location to ' + gWc.location.u_store_number);
			gWap.location = gWc.location;
			gWap.update();
		} else {
			gs.print('AP: ' + gWap.name + ' - wireless controller ' + gWap.u_wireless_controller + ' not found');
		}
	}
}())
