(function(){
    var grGrp = new GlideRecord('sys_user_group');

    grGrp.query();
    gs.print('Found ' + grGrp.getRowCount() + ' groups');

    grGrp.initialize();
    grGrp.addNullQuery('x_pd_integration_pagerduty_escalation');
    gs.print('Found ' + grGrp.getRowCount() + ' groups without PD attribus');

    grGrp.setValue('x_pd_integration_pagerduty_escalation',  'PXWRB9G');
    grGrp.setValue('x_pd_integration_pagerduty_service',  'P1DSVBA');
    grGrp.updateMultiple();

    grGrp.initialize();
    grGrp.addQuery('x_pd_integration_pagerduty_escalation',  'PXWRB9G');
    grGrp.query();
    gs.print('Found ' + grGrp.getRowCount() + ' groups with IRT PD escalation policy');

    grGrp.initialize();
    grGrp.addQuery('x_pd_integration_pagerduty_service',  'P1DSVBA');
    grGrp.query();
    gs.print('Found ' + grGrp.getRowCount() + ' groups with IRT PD service');
}())
