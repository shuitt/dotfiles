(function(){
    var gr = new GlideRecord('sys_user');
    gr.addQuery('web_service_access_only', true);
    gr.orderBy('user_name');
    gr.query();
    while (gr.next()) {
        if (gr.u_production_service_account) {
            gr.active = false;
            gr.locked_out = true;
            gr.update();
        } else {
            gr.active = true;
            gr.locked_out = false;
            gr.update();
        }
    }

    // reset property so test accts won't collide with real accounts
    gs.setProperty('u_nord.api.userid.seq', 4000, 'Next sequence value for service accounts');
}())
