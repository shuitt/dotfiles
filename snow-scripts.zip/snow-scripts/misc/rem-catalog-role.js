(function(){
    var role = 'e098ecf6c0a80165002aaec84d906014'; // sys_id for catalog role
    var grp  = '7767f219db71f280cdf5f8fdae9619c2'; // sys_id for Nordstrom - All group

    var gr = new GlideRecord('sys_group_has_role');
    gr.addQuery('role', role);
    gr.addQuery('group', grp);
    gr.query();
    if (gr.next()) {
        gs.print('Found it: role = ' + gr.role.name + ', group = ' + gr.group.name);
        gr.deleteRecord();
    } else {
        gs.print('Hmmmm, did find the record');
    }
}())
