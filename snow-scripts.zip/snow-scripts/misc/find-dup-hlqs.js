(function(){
	var logMsg = 'PagerDuty Delete Duplicate On-calls: script starting';
	var gr = new GlideAggregate('u_hlq');
	gr.addAggregate('COUNT');
	gr. groupBy('u_hlq');
	gr.query();
	while (gr.next()) {
		recs = gr.getAggregate('COUNT');
		if (recs > 1) {
			gs.print(gr.u_hlq + ' ==> ' + recs);
		}
	}
}())
