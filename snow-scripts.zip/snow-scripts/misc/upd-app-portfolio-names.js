(function(){
    function copyShortToAbacus() {
        var gr = new GlideRecord('u_applications');
        //gr.addEncodedQuery('u_long_nameSTARTSWITHsteve');
        gr.query();
        gs.print('*** updating abacus short name for ' + gr.getRowCount() + ' records');
        while (gr.next()) {
            gs.print('setting abacus short name to ' + gr.name);
            gr.u_abacus_short_name = gr.name;
            gr.update();
        }
    }

    function copyLongToShort() {
        var gr = new GlideRecord('u_applications');
        //gr.addEncodedQuery('u_long_nameSTARTSWITHsteve');
        gr.query();
        gs.print('*** updating short name for ' + gr.getRowCount() + ' records');
        while (gr.next()) {
            gs.print('setting short name to ' + gr.u_long_name);
            gr.name = gr.u_long_name;
            gr.update();
        }
    }

    copyShortToAbacus();
    copyLongToShort();
}())
