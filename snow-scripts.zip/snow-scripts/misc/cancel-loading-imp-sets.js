(function(){
    var gr = new GlideRecord('sys_import_set');
    gr.addEncodedQuery('state=loading^table_nameSTARTSWITHu_hrws');
    gr.query();
    gs.print(gr.getRowCount() + ' rows found');
    while (gr.next()) {
        gs.print('Number: ' + gr.number + ' created on ' + gr.sys_created_on);
        gr.state = 'cancelled';
        gr.update();
    }
}())
