(function(){
    var grGrp = new GlideRecord('sys_user_group');
    var grRole = new GlideRecord ('sys_group_has_role');

    grGrp.query();
    while (grGrp.next()) {
        grRole.initialize();
        grRole.addQuery('group', grGrp.getUniqueValue());
        grRole.query();
        if (!grRole.next()) {
            gs.print(grGrp.name);
        }
    }
}())
