(function(){
    // update server tagging ci reference
    var grCi = new GlideRecord('cmdb_ci_server');
    var grSt = new GlideRecord('u_server_tagging');
    var updated = 0;
    var not_found = 0;

    grSt.addEncodedQuery('u_server_ciISEMPTY^u_decommissioned=false');
    //grSt.setLimit(20);
    grSt.query();
    gs.print('Found ' + grSt.getRowCount() + ' servers with an empty CI reference');
    while (grSt.next()) {
        grCi.initialize();
        grCi.addQuery('name', grSt.u_server_name);
        grCi.query();
        if (grCi.next()) {
            gs.print('Updating server: ' + grSt.u_server_name);
            grSt.u_server_ci = grCi.getUniqueValue();
            grSt.update();
            updated += 1;
        } else {
            gs.print('No Ci found matching server: ' + grSt.u_server_name);
            not_found += 1;
        }
    }
    gs.print('Updated servers: ' + updated + ', servers not found: ' + not_found);
}())
