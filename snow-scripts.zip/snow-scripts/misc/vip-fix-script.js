(function(){
	var gr = new GlideRecord('sys_user');       // find active users
	var grSQ = gr.addJoinQuery('u_jobs', 'u_job', 'sys_id');       // join with jobs
	gr.addQuery('active', 'true');              // get active users
	grSQ.addCondition('u_leadership_rank', 5);  // with leadership rank = 5
	gr.query();
	gs.info('Found ' + gr.getRowCount() + ' rank 5 users');
	gr.setValue('vip',  true);
	gr.updateMultiple();
	//while (gr.next()) {
	//    gs.info(gr.name);
	//}
	gr = new GlideRecord('sys_user');       // find active users
	grSQ = gr.addJoinQuery('u_jobs', 'u_job', 'sys_id');       // join with jobs
	gr.addQuery('active', 'true');              // get active users
	grSQ.addCondition('u_leadership_rank', 4);  // with leadership rank = 5
	gr.query();
	gs.info('Found ' + gr.getRowCount() + ' rank 4 users');
	gr.setValue('vip',  true);
	gr.updateMultiple();
	//while (gr.next()) {
	//    gs.info(gr.name);
	//}
}())
