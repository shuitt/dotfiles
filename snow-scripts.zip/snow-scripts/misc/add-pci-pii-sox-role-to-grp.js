(function(){
    // assign the nord_pci_pii_sox_support_group to groups supproting a pci/pii/sox application
    var utils = new u_PciPiiSoxSupGrpUtils();
    var qry_str = 'u_pci=true^ORu_pii=true^ORu_soc1=true^ORu_soc1_bank=true^ORu_sox=true^support_groupISNOTEMPTY';
    var gr = new GlideRecord ('u_applications');
    gr.addEncodedQuery(qry_str);
    gr.query();
    gs.print('Found ' + gr.getRowCount() + ' PCI/PII/SOX applications');
    while (gr.next()) {
        utils.addRoleToGrp(gr.support_group);
    }
}())
