// Turn off Email
gs.setProperty('glide.email.read.active', false);
gs.setProperty('glide.email.smtp.active', false);


// comment out any table you want to keep data for
cleanDemo('incident');
cleanDemo('problem_task');
cleanDemo('problem');
cleanDemo('change_request');
cleanDemo('change_task');
cleanDemo('sc_task');
cleanDemo('sc_req_item');
cleanDemo('sc_request');
cleanDemo('new_call');

function cleanDemo(tableName) {
    // Workflow
    var workflowGR = new GlideRecord('wf_context');
    workflowGR.addQuery('table', tableName);
    workflowGR.deleteMultiple();

    // Delete Data
    var taskGR = new GlideRecord(tableName);
    taskGR.deleteMultiple();

    // Delete SLAs (if any remain after clearing tasks)
    var slaGR = new GlideRecord('task_sla');
    slaGR.addQuery('task.sys_class_name', tableName);
    slaGR.query();
    while (slaGR.next()) {
        slaContextGR = new GlideRecord('wf_context');
        slaContextGR.addQuery('id', slaGR.sys_id);
        slaContextGR.deleteMultiple();

        slaGR.deleteRecord();

    }

    // Delete Metrics
    var metricGR = new GlideRecord('metric_instance');
    metricGR.addQuery('table', tableName);
    metricGR.deleteMultiple();

    // Number Maintenance
    var numberGR = new GlideRecord('sys_number');
    numberGR.addQuery('category', tableName);
    numberGR.query();
    if (numberGR.hasNext()) {
        numberGR.next();

        numberGR.number = 1;
        numberGR.update();
    }

    // Number Counter
    var numberCounterGR = new GlideRecord('sys_number_counter');
    numberCounterGR.addQuery('table', tableName);
    numberCounterGR.query();
    if (numberCounterGR.hasNext()) {
        numberCounterGR.next();

        numberCounterGR.number = 1;
        numberCounterGR.update();
    }
}

// Turn on Email
gs.setProperty('glide.email.read.active', true);
gs.setProperty('glide.email.smtp.active', true);
