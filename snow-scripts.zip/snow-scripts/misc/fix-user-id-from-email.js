(function(){
    var gr = new GlideRecord ('sys_user');
    gr.addNullQuery('user_name');
    gr.addNotNullQuery('email');
    gr.query();
    gs.print('Found ' + gr.getRowCount() + ' users with emails but null user IDs');

    while (gr.next()) {
        gs.print('Email: ' + gr.email);
        gr.user_name = gr.email;
        gr.update();
    }

    gr.initialize();
    gr.addNullQuery('user_name');
    gr.addNotNullQuery('email');
    gr.query();
    gs.print('Found ' + gr.getRowCount() + ' users with emails but null user IDs');
}())
