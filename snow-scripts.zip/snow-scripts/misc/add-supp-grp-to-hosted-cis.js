(function(){
    // update the support group of cis with a 'runs on' relationship to a server to be
    // the same as the server's support group

    function updateParentCi(ci_id, grp_id) {
        var grApp = new GlideRecord('cmdb_ci_appl');
        //gs.print('Do update, ci sys_id: ' + ci_id + ', group sys_id: ' + grp_id);
        grApp.addQuery('sys_id', ci_id);
        grApp.query();
        if (grApp.next()) {
            //gs.print('Found the parent CI');
            grApp.support_group = grp_id;
            grApp.update();
        } else {
            //gs.print('Did not find the parent CI');
        }
    }

    var grRel = new GlideRecord('cmdb_rel_ci');
    var match = 0;
    var empty_child = 0;
    var updated = 0;

    grRel.addEncodedQuery('type=60bc4e22c0a8010e01f074cbe6bd73c3');  // runs on::runs rel type
    //grRel.setLimit(20);
    grRel.query();
    gs.print('Found ' + grRel.getRowCount() + ' CIs with a Runs On relationship to a server');
    while (grRel.next()) {
        var msg = '';
        var sg = grRel.child.support_group;
        //gs.print('');
        //gs.print('Parent: ' + grRel.parent.name + ' (' + grRel.parent + ')');
        //if (JSUtil.notNil(grRel.parent.support_group)) {
        //    gs.print('Parent support group: ' + grRel.parent.support_group.name + ' (' + grRel.parent.support_group + ')');
        //} else {
        //    gs.print('Parent support group: empty');
        //}
        //gs.print('Child: ' + grRel.child.name);
        //if (JSUtil.notNil(grRel.child.support_group)) {
        //    gs.print('Child support group: ' + grRel.child.support_group.name + ' (' + grRel.child.support_group + ')');
        //} else {
        //    gs.print('Child support group: empty');
        //}
        if (JSUtil.notNil(grRel.child.support_group)) {
            if (JSUtil.notNil(grRel.parent.support_group) &&
                grRel.parent.support_group == grRel.child.support_group) {
                    //gs.print('Support groups match');
                    match += 1;
            } else {
                updateParentCi(grRel.parent, grRel.child.support_group);
                updated += 1;
            }
        } else {
            //gs.print('Skip update - child support group empty');
            empty_child += 1;
        }
    }
    gs.print('Updated CIs: ' + updated + ', CIs matching server: ' + match + ', Servers with no group: ' + empty_child);
}())
