(function(){
    // script to load the hosted applications table from the application ci table
    var prod = 'Production';
    var test = 'Non-Production';
    var grCI = new GlideRecord('cmdb_ci_appl');
    grCI.addQuery('sys_class_name', 'cmdb_ci_appl');
    grCI.query();
    gs.info('Number of applications CIs found: ' + grCI.getRowCount());
    var updCnt = 0;
    while (grCI.next()) {
		var grApp = new GlideRecord('u_server_tagging_application');
        grApp.addQuery('u_application_name', grCI.name);
		grApp.query();
		gs.info('getRowCount(): ' + grApp.getRowCount());
        if (grApp.getRowCount() == 0) {
			gs.info('Hosted application not found: ' + grCI.name);
            grApp.newRecord();
        	grApp.u_application_ci = grCI.sys_id;
        	grApp.u_application_name = grCI.name;
            grApp.u_application_long_name = grCI.u_long_name
        	grApp.u_application_and_environment = grCI.u_long_name + 'v(' + prod + ')';
        	grApp.u_environment = prod;
        	grApp.update();
            grApp.newRecord();
        	grApp.u_application_ci = grCI.sys_id;
        	grApp.u_application_name = grCI.name;
            grApp.u_application_long_name = grCI.u_long_name
        	grApp.u_application_and_environment = grCI.u_long_name + ' (' + test + ')';
        	grApp.u_environment = test;
        	grApp.update();
            updCnt = updCnt + 2;
        } else {
			gs.info('Hosted application found: ' + grCI.name);
		}
    }
	gs.info('Updated user records: ' + updCnt);
}())
