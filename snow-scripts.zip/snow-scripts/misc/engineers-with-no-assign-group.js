(function(){
    // -- run this as a backgroun script --
    // this script creates a list of active users with 'engineer' in their job title who are
    // not a member of a group other than 'Nordstrom - All'
    var count = 0;
    var gr = new GlideRecord('sys_user');
    var grm = new GlideRecord('sys_user_grmember');

    // find all active users with a given title job title - uncomment one of the lines below
    // to get a count for a particular job title

    //gr.addEncodedQuery('u_job.u_job_titleLIKEengineer^active=true');   // engineers, not just tech
    //gr.addEncodedQuery('active=true^u_job.u_job_titleLIKEengineer^u_job.u_job_familyLIKEtechnology');   // engineers, just tech
    //gr.addEncodedQuery('active=true^u_job.u_job_titleLIKEprogram^u_job.u_job_familyLIKEtechnology');   // pgm mgrs, just tech
    //gr.addEncodedQuery('active=true^u_job.u_job_titleLIKEtechnician^u_job.u_job_familyLIKEtechnology');   // techs, just tech

    gr.query();
    gs.print('Active users with engineer in their job title: ' + gr.getRowCount());
    gs.print('Name\tJob Title\tManager\tDirector');

    // check if the user is a member of a group othr than 'Nordstrom - All'
    while (gr.next()) {
        grm.initialize();
        grm.addQuery('user', gr.getUniqueValue());
        grm.addQuery('group', '!=', '7767f219db71f280cdf5f8fdae9619c2');  // sys_id of Nordstrom - All group
        grm.query();
        if (!grm.next()) {
            // not in a group - print the user info
            gs.print(gr.name + '\t' + gr.u_job.u_job_title + '\t' + gr.manager.name + '\t' + gr.manager.manager.name);
            count += 1;
        }
    }
    gs.print('Active engineers not in an assignment group: ' + count);
}())
