(function(){
    var hlq = new GlideRecord('u_hlq');
    var app = new GlideRecord('u_applications');
    app.orderBy('u_hlq');
    app.query();
    while (app.next()) {
        if (app.u_hlq.nil()) {
            gs.print(app.u_long_name + '\tN/A');
        } else {
            var hlqs = app.u_hlq.split(',');
            for(var i = 0; i < hlqs.length; i++) {
               //gs.print(app.u_long_name + '\t' + hlqs[i]);
               hlq.initialize();
               hlq.addQuery('u_hlq', hlqs[i]);
               hlq.query();
               if (hlq.next()) {
                   if (hlq.u_application_portfolio != app.sys_id) {
                       gs.print(app.u_long_name + '\t' + hlqs[i] + '\tpoints to ' + hlq.u_application_portfolio.u_long_name);
                   } else {
                       //gs.print(app.u_long_name + '\tHLQ OK');
                   }
               }
            }
        }
    }
}())
