(function(){
    var gr = new GlideRecord('u_applications');
    var nbr = 1;

    gr.addNullQuery('u_app_id');
    gr.query();
    gs.print('records with no App ID: ' + gr.getRowCount());
    while (gr.next()) {
        var n = '00000' + nbr.toString();
        var appid = 'APP' + n.slice(n.length - 5);
        //gs.print('AppID: ' + appid + ', Name: ' + gr.u_long_name);
        gr.u_app_id =  appid;
        gr.setWorkflow(false);
        gr.autoSysFields(false);
        gr.update();
        nbr++;
    }

    gr.initialize();
    gr.addNullQuery('u_app_id');
    gr.query();
    gs.print('records with no App ID: ' + gr.getRowCount());
}())
