(function(){
    var grGrp = new GlideRecord('sys_user_group');
    var grMbr = new GlideRecord ('sys_user_grmember');

    grGrp.query();
    gs.print('Found ' + grGrp.getRowCount() + ' groups');
    gs.print('Group, Director, Manager, Members');
    while (grGrp.next()) {
        grMbr.initialize();
        grMbr.addQuery('group', grGrp.getUniqueValue());
        grMbr.query();
        gs.print(grGrp.name + ', ' + grGrp.u_director.user_name + ', ' + grGrp.manager.user_name + ', ' + grMbr.getRowCount());
    }
}())
