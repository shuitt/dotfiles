(function(){
    var utils = new OracleEbsIntegrationUtils('HRWS101 Get Jobs List: ');
    var webService = 'HRWS101 Get Jobs List';   // name of the outbound REST message
    var post = 'post';                           // http method - case sensitive!

    var response = utils.sendMsg(webService, post);    
    if (response == null) {
        utils.log('response is null - exiting');
        return;
    }

    var httpStatus = response.getStatusCode();
    utils.log('response code = ' + response.getStatusCode());
    var parsed = JSON.parse(response.getBody());      // convert JSON response to javascript object

    jobs = utils.getList(parsed, 'OUT_JOBS', 'OUT_JOBS_ITEM');
    recCount = jobs.length;
    utils.log('number of records = ' + recCount);

    // skip if the job list is empty
    if (recCount > 0) {
        //Create a new import set
        var impTable = 'u_hrws101_jobs';             //import set table name
        impSet = utils.getImpSet(impTable);
        var restGR = new GlideRecord(impTable);         //import set table
        utils.log('process jobs');

        //process response
        for (var i = 0; i < recCount; i++) {
            restGR.newRecord();
            restGR.u_job_id = jobs[i].HR_JOB_ID;
            restGR.u_job_title = jobs[i].JOB_TITLE_DESC;
            restGR.u_job_family = jobs[i].JOB_FAMILY_DESC;
            if (!(jobs[i].JOB_LEADERSHIP_RANK.hasOwnProperty('@xsi:nil'))) {
                restGR.u_leadership_rank = jobs[i].JOB_LEADERSHIP_RANK;
            }
            if (!(jobs[i].JOB_CLASS_DESC.hasOwnProperty('@xsi:nil'))) {
                restGR.u_job_class = jobs[i].JOB_CLASS_DESC;
            }
            restGR.insert();
        }
        // data is all loaded so run the transformation
        utils.log('data loaded');
        impSet.state = 'loaded';
        var mapName = 'HRWS101 Jobs';
        utils.doTransform(impSet, mapName);
        utils.log('all done');
    }
}())
