(function(){
	var utils = new u_ServerTaggingUtils();

	// find cluster node CIs with no support group. update the support group of the cluster
	// node and related clusters and cluster resources to the asociated server support group
	gr = new GlideRecord('cmdb_ci_cluster_node');
	gr.addEncodedQuery('support_groupISEMPTY');
	gr.query();
	gs.log('u_Upd_Cluster_CI_Supp_Grp: found ' + gr.getRowCount() + ' cluster nodes with no support group');
	while (gr.next()) {
		var grp_id = gr.server.support_group;
		if (JSUtil.notNil(grp_id)) {
			 //update cluster node
			 gr.support_group = grp_id;
			 gr.update();
			// update referenced cluster
			var cl = gr.cluster.getRefRecord(); //Returns the GlideRecord the referenced cluster
			cl.support_group = grp_id;
			cl.update();
			// see if server related to any cluster resource, if so update their
			// cluster resource support group
			utils.updateClResCi(gr.getUniqueValue(), grp_id);
		}
	}

	// find cluster resource CIs with no support group and update the support to the associated server
	// support group
	gr = new GlideRecord('cmdb_ci_cluster_resource');
	var grCnr = new GlideRecord('cmdb_ci_cluster_node_resource');
	gr.addEncodedQuery('support_groupISEMPTY');
	gr.query();
	gs.log('u_Upd_Cluster_CI_Supp_Grp: found ' + gr.getRowCount() + ' cluster resources with no support group');
	while (gr.next()) {
		grCnr.initialize();
		grCnr.addQuery('cluster_resource', gr.getUniqueValue());
		grCnr.query();
		while (grCnr.next()) {
			gr.support_group = grCnr.cluster_node.server.support_group;
			gr.update();
		}
	}

	// find cluster CIs with no support group. update the support group to the associated
	// server support group
	gr = new GlideRecord('cmdb_ci_cluster');
	gr.addEncodedQuery('support_groupISEMPTY');
	gr.query();
	gs.log('u_Upd_Cluster_CI_Supp_Grp: found ' + gr.getRowCount() + ' clusters with no support group');
	while (gr.next()) {
		gr.support_group = gr.server.support_group;
		gr.update();
	}
}())
