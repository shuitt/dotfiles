(function(){
    var gr = new GlideRecord('sys_user');
    // find all users where:
    //    the termination date is on or before today and
    //    (active == true or locked out == false or user ID is not empty)
    gr.addEncodedQuery('u_termination_date<=javascript:gs.daysAgoEnd(0)^active=true^ORlocked_out=false^ORuser_nameISNOTEMPTY');
    gr.query();
    gs.print('Found ' + gr.getRowCount() + ' users');
    while (gr.next()) {
        gs.print('User name: ' + gr.name);
        gr.active = false;
        gr.locked_out = true;
        gr.user_name = '';
        gr.update();
    }
}())
