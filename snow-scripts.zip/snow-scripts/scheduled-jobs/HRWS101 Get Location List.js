(function(){
    var utils = new OracleEbsIntegrationUtils('"HRWS101 Get Location List: ');
    var webService = 'HRWS101 Get Location List';   // name of the outbound REST message
    var post = 'post';                           // http method - case sensitive!

    var response = utils.sendMsg(webService, post);
    if (response == null) {
        utils.log('response is null - exiting');
        return;
    }

    var httpStatus = response.getStatusCode();
    utils.log('response code = ' + response.getStatusCode());
    var parsed = JSON.parse(response.getBody());      // convert JSON response to javascript object

    locations = utils.getList(parsed, 'OUT_LOCATIONS', 'OUT_LOCATIONS_ITEM');
    recCount = locations.length;
    utils.log('number of records = ' + recCount);

    // skip if the location list is empty
    if (recCount > 0) {
        //Create a new import set
        var impTable = 'u_hrws101_location';            //import set table name
        impSet = utils.getImpSet(impTable);
        var restGR = new GlideRecord(impTable);         //import set table
        utils.log('process locations');

        //process response
        for (var i = 0; i < recCount; i++) {
            restGR.newRecord();
            restGR.u_city = locations[i].TOWN_OR_CITY;
            restGR.u_company = "Nordstrom, Inc.";
            restGR.u_location_id = locations[i].LOCATION_ID;
            restGR.u_name = locations[i].LOCATION_DESC;
            restGR.u_state_province = locations[i].STATE_OR_PROVINCE;
            restGR.u_store_number = locations[i].LOCATION_NUMBER;
            restGR.u_zip_postal_code = locations[i].POSTAL_CODE;
            // combine multiple address lines as needed
            var street = locations[i].ADDRESS_LINE_1;
            if (!(locations[i].ADDRESS_LINE_2.hasOwnProperty('@xsi:nil'))) {
               street = street + '\n' + locations[i].ADDRESS_LINE_2;
            }
            if (!(locations[i].ADDRESS_LINE_3.hasOwnProperty('@xsi:nil'))) {
               street = street + '\n' + locations[i].ADDRESS_LINE_3;
            }
            restGR.u_street = street;
            restGR.insert();
        }
        // data is all loaded so run the transformation
        utils.log('data loaded');
        impSet.state = 'loaded';
        var mapName = 'HRWS101 Location';
        utils.doTransform(impSet, mapName);
        utils.log('all done');
    }
}())
