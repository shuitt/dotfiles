(function(){
    var utils = new OracleEbsIntegrationUtils('HRWS101 Get HR Organization List: ');
    var webService = 'HRWS101 Get HR Organization List';   // name of the outbound REST message
    var post = 'post';                                  // http method - case sensitive!

    // get the last run date/time
    var lastRun = utils.getLastUpdate(webService);
    if (lastRun === null) {
        utils.log('unable to find last run date/time in control table');
        return;
    }
    utils.log('getting updates since ' + lastRun);

    var response = utils.sendMsgWithDate(webService, post, lastRun);
    if (response == null) {
        utils.log('response is null - exiting');
        return;
    }

    var httpStatus = response.getStatusCode();
    utils.log('response code = ' + response.getStatusCode());
    var parsed = JSON.parse(response.getBody());      // convert JSON response to javascript object

    // get last run date and record count
    lastRun = parsed['OutputParameters']['OUT_CONTROL_RECORD'].LAST_EFFECTIVE_DATE;
    utils.log('LAST_EFFECTIVE_DATE = ' + lastRun);
    recCount = parsed['OutputParameters']['OUT_CONTROL_RECORD'].RECORD_COUNT;
    utils.log('RECORD_COUNT = ' + parsed['OutputParameters']['OUT_CONTROL_RECORD'].RECORD_COUNT);

    // skip if the org list is empty
    if (recCount > 0) {
        depts = utils.getList(parsed, 'OUT_HR_ORGANIZATIONS', 'OUT_HR_ORGANIZATIONS_ITEM');

        //Create a new import set for dept
        var impTableDept = 'u_hrws101_departments';         // dept import set table name
        impSetDept = utils.getImpSet(impTableDept);
        var grDept = new GlideRecord(impTableDept);         // import set table

        //Create a new import set for cost center
        var impTableCostCtr = 'u_hrws101_cost_center';      // cost ctr import set table name
        impSetCostCtr = utils.getImpSet(impTableCostCtr);
        var grCostCtr = new GlideRecord(impTableCostCtr);   // import set table

        //process response
        utils.log('process departments and cost centers');
        var loadedCostCtrs = {};

        for (var i = 0; i < recCount; i++) {
            // get department info
            grDept.newRecord();
            grDept.u_id = depts[i].ORGANIZATION_ID;
            grDept.u_name = depts[i].ORGANIZATION_NAME;
            grDept.u_payroll_store_id = depts[i].PAYROLL_STORE;
            grDept.u_payroll_store_description = depts[i].PAYROLL_STORE_DESC;
            grDept.u_payroll_department_id = depts[i].PAYROLL_DEPT;
            grDept.u_payroll_department_description = depts[i].PAYROLL_DEPT_DESC;
            grDept.u_valid_from = utils.makeDate(depts[i].ORG_DATE_FROM);
            grDept.u_valid_to = utils.makeDate(depts[i].ORG_DATE_TO);
            grDept.u_business_unit_id = depts[i].GL_BUSINESS_UNIT;
            grDept.u_business_unit_description = depts[i].GL_BUSINESS_UNIT_DESC;
            grDept.u_cost_center = depts[i].GL_COST_CENTER;
            grDept.insert();

            // get cost center info
            if (!loadedCostCtrs.hasOwnProperty([depts[i].GL_COST_CENTER])) {
                loadedCostCtrs[depts[i].GL_COST_CENTER] = 1;
                grCostCtr.newRecord();
                grCostCtr.u_name = depts[i].GL_COST_CENTER_DESC;
                grCostCtr.u_account_number = depts[i].GL_COST_CENTER;
                grCostCtr.u_business_unit = depts[i].GL_BUSINESS_UNIT;
                grCostCtr.u_business_unit_description = depts[i].GL_BUSINESS_UNIT_DESC;
                grCostCtr.insert();
            }
        }
        utils.log('data loaded');

        // run the dept transformation
        utils.log('transform departments');
        impSetDept.state = 'loaded';
        var mapName = 'HRWS101 Departments';
        utils.doTransform(impSetDept, mapName);

        // run the cost center transformationtransformation
        utils.log('transform cost centers');
        impSetCostCtr.state = 'loaded';
        mapName = 'HRWS101 Cost centers';
        utils.doTransform(impSetCostCtr, mapName);
    }
    utils.log('update last run date to ' + lastRun);
    utils.setLastUpdate(webService, lastRun);
    utils.log('all done');
}())
