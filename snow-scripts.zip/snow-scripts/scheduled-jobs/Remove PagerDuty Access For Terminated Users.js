(function(){
	function keepAccess(email) {
		var keep = false;
		var gr = new GlideRecord('sys_user');
		gr.addQuery('email', email);
		gr.addNullQuery('u_termination_date');
		gr.query();
		if (gr.next()) {
			keep = true;
		}
		return keep;
	}

    var logmsg = 'Remove PagerDuty Access For Terminated Users: script starting';
    var termed_users = [];
	var rem_count = 0;
	var keep_count = 0;
    var days = 21;   // number of days to wait before removing access for termed user
    var query = 'x_pd_integration_pagerduty_idISNOTEMPTY^u_termination_dateISNOTEMPTY^u_termination_date<=javascript:gs.daysAgoEnd(' + days + ')';

    var gr = new GlideRecord('sys_user');
    gr.addEncodedQuery(query);
    gr.query();
    logmsg += '\nFound ' + gr.getRowCount() + ' terminated users with a PagerDuty ID';

    while (gr.next()) {
        termed_users.push({name: gr.name.getDisplayValue(),
                           email: gr.email.getDisplayValue(),
                           pd_id: gr.x_pd_integration_pagerduty_id.getDisplayValue(),
                           sys_id: gr.getUniqueValue()
                          });
    }

    for (var i = 0; i < termed_users.length; i++) {
		gr.initialize();
		gr.get(termed_users[i].sys_id);
		if (keepAccess(termed_users[i].email)) {
			logmsg += '\nRemoving PagerDuty ID from termed user record: Name: ' + gr.name + ', email: ' +  gr.email +
					  'employee nuumber: ' + gr.employee_number + ', sys_id: ' + gr.getUniqueValue();
			gr.x_pd_integration_pagerduty_id = '';
			gr.update();
			keep_count++;
		} else {
			logmsg += '\nRemoving PagerDuty access from termed user: Name: ' + gr.name + ', email: ' +  gr.email +
					  'employee nuumber: ' + gr.employee_number + ', sys_id: ' + gr.getUniqueValue();
			// event.parm1 = user rec sys_id
			// event.parm2 = user's pd id
			gs.eventQueue('nord.remove.pagerduty.access', gr, gr.getUniqueValue(), gr.x_pd_integration_pagerduty_id);
			rem_count++;
		}
    }
	logmsg += '\nPagerDuty access removed from ' + rem_count + ' users' +
			  '\nPagerDuty access kept for ' + keep_count + ' users';
    gs.log(logmsg);

}());
