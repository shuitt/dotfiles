(function(){
    var teams = [];
    var mbrs = [];
    var req = null;
    var utils = new u_nord_PagerDuty_provisioning();
    var user = 'PC58PFH';
    var team = 'P88GC8I';
    var i = 0;

    teams = utils.getUserTeams(user);
    gs.print('top: teams returned: ' + teams.length);
    for (i = 0; i < teams.length; i++) {
        gs.print('top: teams[' + i + ']: ' + teams[i]);
    }

    mbrs = utils.getTeamMembers(team, user);
    gs.print('top: members returned: ' + mbrs.length);
    for (i = 0; i < mbrs.length; i++) {
        gs.print('top: mbrs[' + i + ']: ' + mbrs[i]);
    }

    if (mbrs.length > 0) {
        for (i = 0; i < mbrs.length; i++) {
            if (utils.userExists(mbrs[i])) {
                gs.print('top: member ' + mbrs[i] + ' exists');
            } else {
                gs.print('top: member ' + mbrs[i] + ' does not exist');
            }
        }
    }

    gs.print('top: call findReplacement');
    rep = utils.findReplacement(user);
    gs.print('top: replacement user id: ' + rep);

}())
