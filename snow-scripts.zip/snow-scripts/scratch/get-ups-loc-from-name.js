(function () {
    // get a list of ups where location is empty
    var pat = /up0*(\d+)\D.*/;

    var locs = new GlideRecord('cmn_location');
    var ups = new GlideRecord('cmdb_ci_ups');
    ups.addEncodedQuery('location.u_store_numberISEMPTY');
    //ups.setLimit(5);
    ups.query();

    while (ups.next()) {
        var l = ups.name.match(pat);
        if (!gs.nil(l) && l.length > 0) {
            gs.print('store: ' + l[1]);
            locs.initialize();
            locs.addQuery('u_store_number', l[1]);
            locs.query();
            if (locs.next()) {
                gs.print('found: ' + locs.name);
                ups.location = locs.sys_id;
                ups.setWorkflow(false);
                ups.update();
            }
        }
    }
})();
