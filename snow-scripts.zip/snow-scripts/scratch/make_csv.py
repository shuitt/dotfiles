#!/usr/bin/env python3

import csv
from datetime import datetime

IN_FILE = '/Users/xsmh/Downloads/SN/Data Imports/hrws101_org_full_list_03-14-2017.csv'
# IN_FILE = '/Users/xsmh/Downloads/SN/Data Imports/test.csv'
OUT_DEPT = '/Users/xsmh/Downloads/SN/Data Imports/dept_03-15-17.csv'
OUT_COST_CTR = '/Users/xsmh/Downloads/SN/Data Imports/cost_center_03-15-17.csv'

#------------------------------------------------------------------------------
# read a csv file into a list
#------------------------------------------------------------------------------
def getList(file_name):
    print('Reading CSV file', file_name)
    with open(file_name, 'r') as f:
        reader = csv.reader(f)
        the_list = list(reader)
    f.close()
    return the_list

#------------------------------------------------------------------------------
# write the department csv file
#------------------------------------------------------------------------------
# 0 - ORGANIZATION_ID
# 1 - ORGANIZATION_NAME
# 2 - PAYROLL_STORE
# 3 - PAYROLL_STORE_DESC
# 4 - PAYROLL_DEPT
# 5 - PAYROLL_DEPT_DESC
# 6 - ORG_DATE_FROM
# 7 - ORG_DATE_TO
# 8 - GL_BUSINESS_UNIT
# 9 - GL_BUSINESS_UNIT_DESC
# 10 - GL_STORE
# 11 - GL_STORE_DESC
# 12 - GL_COST_CENTER
# 13 - GL_COST_CENTER_DESC
def makeDeptCsv(org_list, out_file):
    print('Writing CSV file', out_file)
    with open(out_file, 'w', newline='') as f:
        out_row = ['Company', 'Cost center', 'Department head', 'Description', 'Head count', 'ID', 'Name', 'Parent', 'Primary contact',
                    'Business unit desctiption', 'Business unit ID', 'Payroll department description', 'Payroll department ID',
                    'Payroll store description', 'Payroll store ID', 'Valid from', 'Valid to']
        writer = csv.writer(f)
        writer.writerow(out_row)
        out_row[0] = 'Nordstrom, Inc.'      # Company
        out_row[2] = ''                     # Department head
        out_row[4] = ''                     # Head count
        out_row[7] = ''                     # Parent
        out_row[8] = ''                     # Primary contact
        for in_row in org_list:
            out_row[1] = in_row[13]          # Cost center = GL_COST_CENTER_DESC
            out_row[3] = in_row[3] + ' ' + in_row[5]  # Description = HR_PAYROLL_STORE_DESC + HR_PAYROLL_DEPT_DESC
            out_row[5] = str(in_row[0])      # ID = HR_ORGANIZATION_ID
            out_row[6] = in_row[1]          # Name = HR_ORGANIZATION_NAME
            out_row[9] = in_row[9]          # Business unit desctiption = GL_BUSINESS_UNIT_DESC
            out_row[10] = str(in_row[8])          # Business unit ID = GL_BUSINESS_UNIT
            out_row[11] = in_row[5]          # Payroll department description = HR_PAYROLL_DEPT_DESC
            out_row[12] = str(in_row[4])          # Payroll department ID = HR_PAYROLL_DEPT
            out_row[13] = in_row[3]          # Payroll store description = HR_PAYROLL_STORE_DESC
            out_row[14] = str(in_row[2])          # Payroll store ID = HR_PAYROLL_STORE
            out_row[15] = in_row[6][:10]     # Valid from = HR_ORG_DATE_FROM
            out_row[16] = in_row[7][:10]     # Valid to = HR_ORG_DATE_TO
            writer.writerow(out_row)
    f.close()

#------------------------------------------------------------------------------
# write the cost center csv file
#------------------------------------------------------------------------------
# 8 - GL_BUSINESS_UNIT
# 9 - GL_BUSINESS_UNIT_DESC
# 10 - GL_STORE
# 11 - GL_STORE_DESC
# 12 - GL_COST_CENTER
# 13 - GL_COST_CENTER_DESC
def makeCostCenterCsv(org_list, out_file):
    print('Writing CSV file', out_file)
    with open(out_file, 'w', newline='') as f:
        out_row = ['Account number', 'Code', 'Location', 'Manager',	'Name', 'Parent',
        'Business unit', 'Business unit description', 'Valid from', 'Valid to']
        writer = csv.writer(f)
        writer.writerow(out_row)
        out_row[1] = ''                              # Code Account number
        out_row[2] = ''                              # Location
        out_row[3] = ''                              # Manager
        out_row[5] = ''                              # Parent
        out_row[8] = ''                              # Valid from = HR_ORG_DATE_FROM
        out_row[9] = ''                              # Valid to = HR_ORG_DATE_TO
        for in_row in org_list:
            out_row[0] = str(in_row[12])             # Account number = GL_COST_CENTER
            out_row[4] = in_row[13]                  # Name = GL_COST_CENTER_DESC
            out_row[6] = in_row[8]                   # Business unit = GL_BUSINESS_UNIT
            out_row[7] = in_row[9]                   # Business unit description = GL_BUSINESS_UNIT_DESC
            writer.writerow(out_row)
    f.close()

#------------------------------------------------------------------------------
# return a datetime object for the specified string
# params: date_string - a string datetime value
#------------------------------------------------------------------------------
def makeDate(date_string):
    return datetime.strptime(date_string[:-6], '%Y-%m-%dT%H:%M:%S')

#-----------------------------------------------------------------------------
# main program logic
#------------------------------------------------------------------------------
if __name__ == '__main__':
    print('Script staring')
    org_list = getList(IN_FILE)
    makeDeptCsv(org_list, OUT_DEPT)
    makeCostCenterCsv(org_list, OUT_COST_CTR)
    print('Script completed')
