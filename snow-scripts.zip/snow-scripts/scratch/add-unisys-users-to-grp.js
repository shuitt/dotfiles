(function(){
    function isMember(sys_id) {
        var grp = '7a9c82bcdb3c2bc0cdf5f8fdae9619ac';
        var gr = new GlideRecord('sys_user_grmember');
        gr.addQuery('group', grp);
        gr.addQuery('user', sys_id);
        gr.query();
        if (gr.next()) {
            //gs.print('sys_id ' + sys_id + ' is a member');
            return true;
        } else {
            //gs.print('sys_id ' + sys_id + ' is NOT member');
            return false;
        }
    }

    function addToGroup(sys_id) {
        var grp = '7a9c82bcdb3c2bc0cdf5f8fdae9619ac';
        var gr = new GlideRecord('sys_user_grmember');
        gr.newRecord();
        gr.user.setValue(sys_id);
        gr.group.setValue(grp);
        var id = gr.insert();
        if (!gs.nil(id)) {
            //gs.print('insert OK');
        } else {
            gs.print('insert FAILED');
        }
    }

    var users = new GlideRecord('sys_user');
    // active = true & user id is not empty & company is unisys corporation
    var user_query = 'active=true^company=60b678ebdb161f444192da654b961903^user_nameISNOTEMPTY';
    var user_list = [];
    var user_count = 0;

    users.addEncodedQuery(user_query);
    //users.setLimit(5);
    users.query();
    //gs.print('Count from query: ' + users.getRowCount());

    while (users.next()) {
        user_count = user_list.push(users.sys_id.getValue());
    }
    //gs.print('List length: ' + user_count);

    for (var i = 0; i < user_count; i++ ) {
        //gs.print(user_list[i]);
        if (!isMember(user_list[i])) {
            gs.print('add to group');
            addToGroup(user_list[i]);
        }
    }
}())
