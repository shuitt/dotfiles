# This script will get the FireEye HX agent ID of a computer.
# The script take one arguement and that arugement is used as a search term to determine the host that you want to get the agent ID for.
# THe arguement for the script can be anything from a computername or an IP address

import requests, json, sys
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

tokenurl = "https://fe0319p01.nordstrom.net:3000/hx/api/v3/token/" # This is the URL that will be used to get our API token
token_request = requests.get(tokenurl,verify=False,auth=('pSNFE','xbg+~2^R82^p')) # This line makes the REST call to get the FireEye HX token
if token_request.status_code == 204: # This line checks to see if a token was returned
    fe_token = token_request.headers["X-FeApi-Token"] # This line will grab the FireEye token from the header and store it in a variable

feurl = "https://fe0319p01.nordstrom.net:3000/hx/api/v3/hosts/" # This is the URL that wil be used to get the agent ID
fe_headers = {"Content-Type": "application/json", "Accept": "application/json", "X-FeApi-Token": fe_token} # This variable defines the headers that will be sent with the REST call to get the agent ID
hosts_payload = {'search': str(sys.argv[1]), 'limit': 1} # This is POST parameters that will be sent in the REST call to get the agent ID of a host. The arguement is being used here as a search term to search for the host that last reported to the FireEye console as that hostname or IP address
hosts_request = requests.get(feurl, params=hosts_payload, headers=fe_headers, verify=False) # This is POST REST call to the FireEye HX console that will search for the host that we gave in the arguement
print json.dumps(json.loads(hosts_request.text), indent=4, sort_keys=True) # This line will print all of the information that is returned from the pervious POST REST call that was made
if bool(hosts_request.json()["data"]["entries"]) == True: # This line is checking to see if POST REST call returned any information about the hostname or the IP address that was searched. If there isn't anything returned, it's safe to say that the FireEye HX agent is not installed on that system
    agent_id = hosts_request.json()["data"]["entries"][0]["_id"] # This line will stored the agent ID in the variable agent_id after parasing the JSON object will all of the host information that was initally returned to us
    print "Agent ID: %s" %agent_id # This line just prints the agent ID
