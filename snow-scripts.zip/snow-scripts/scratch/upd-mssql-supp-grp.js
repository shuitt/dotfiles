// BEGIN SCRIPT
gs.log(gs.nowDateTime(), "MSSQL Support Group Update");

var mssqlGR = new GlideRecord('cmdb_ci_db_mssql_instance');
mssqlGR.addNullQuery('support_group');
mssqlGR.query();
gs.log("Updating " + mssqlGR.getRowCount() + " MSSQL Instance records with a Support Group", "MSSQL Support Group Update");
var i = 1;
while (mssqlGR.next()) {
    var runningProcess = mssqlGR.running_process;
    if (runningProcess == '') {
        gs.log(i + ":  No Running Process for MSSQL Instance:  " + runningProcess.name + "/" + mssqlGR.name, "MSSQL Support Group Update");
        i++;
        continue;
    }

    var computer = mssqlGR.running_process.computer;
    if (computer == '') {
        gs.log(i + ":  NO Computer for Running Process:  " + mssqlGR.running_process.name + "/" + mssqlGR.name, "MSSQL Support Group Update");
        i++;
        continue;
    }

    var supportGroup = mssqlGR.running_process.computer.support_group;
    if (supportGroup == '') {
        gs.log(i + ":  NO Support Group for Computer:  " + mssqlGR.running_process.computer.name + "/" + mssqlGR.name, "MSSQL Support Group Update");
        i++;
        continue;
    }

    mssqlGR.support_group = supportGroup;
    mssqlGR.setWorkflow(false);
    mssqlGR.update();

    gs.log(i + ":  Update MSSQL Instance " + mssqlGR.name + " = " + computer.support_group.name, "MSSQL Support Group Update");

    i++;
}

gs.log(gs.nowDateTime(), "MSSQL Support Group Update");
// END SCRIPT
