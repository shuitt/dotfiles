(function(){
    var gr = new GlideRecord('sys_user_grmember');
    gr.addEncodedQuery('user.active=false^user.web_service_access_only=false');
    gr.query();
    gs.print('Group membership records with inactive users: ' + gr.getRowCount());
    while(gr.next()) {
        gr.deleteRecord();
    }

    // if inherited is set to true and the user has no group memberships the delete will fail
    gr = new GlideRecord('sys_user_has_role');
    gr.addEncodedQuery('user.active=false^user.web_service_access_only=false');
    gr.query();
    gs.print('User has role records with inactive users: ' + gr.getRowCount());
    while(gr.next()) {
        gr.state = 'pending_approval';
        gr.inherited = false;
        gr.update();
    }

    gr = new GlideRecord('sys_user_has_role');
    gr.addEncodedQuery('user.active=false^user.web_service_access_only=false');
    gr.query();
    while(gr.next()) {
        gr.deleteRecord();
    }
}())
