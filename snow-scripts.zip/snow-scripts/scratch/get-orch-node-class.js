(function () {
    function getCiClass(name) {
        var classes = [];
        var ci = new GlideRecord('cmdb_ci');
        ci.addQuery('name', name);
        ci.query();
        while (ci.next()) {
            classes.push(ci.sys_class_name);
        }
        if (classes.length > 0) {
            return classes.join();
        } else {
            return 'class unknown';
        }
    }

    var agg = new GlideAggregate('orch_execution');
    agg.addAggregate('COUNT');
    agg.orderBy('node_id');
    agg.groupBy('node_id');
    agg.query();
    while (agg.next()) {
        gs.print(agg.node_id + '\t' + agg.getAggregate('COUNT') + '\t' + getCiClass(agg.node_id));
    }
})();
