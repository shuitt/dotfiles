(function executeRule(current, previous /*null when async*/) {
    statusId = new Discovery().discoveryFromIP(current.u_ip_address);
	current.u_discovery_status_id = statusId;
    //gs.addInfoMessage('Discovery of IP address ' + current.u_ip_address + ' submitted, status ID is ' + statusId);
})(current, previous);
