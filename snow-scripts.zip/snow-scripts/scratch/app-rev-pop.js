(function(){
    var logmsg = 'Populate application review table: script starting';

    logmsg += '\nDelete existing application review records';
    var rev = new GlideRecord('u_application_review');
    rev.query();
    if (rev.hasNext()) {
        logmsg += '\Deleting ' + rev.getRowCount() + ' records';
        rev.deleteMultiple();
    } else {
        logmsg += '\nNo records to delete';
    }

    logmsg += '\nCreate application review records';
    var app = new GlideRecord('u_application_portfolio');
    app.addEncodedQuery('support_groupISNOTEMPTY^operational_status=1');
    app.query();
    logmsg += '\nFound ' + app.getRowCount() + ' applications to review' ;
    while (app.next()) {
        rev.initialize();
        rev.u_name = app.name;
        rev.u_app_id = app.u_app_id;
        rev.u_support_group = app.support_group;
        rev.u_operational_status = app.operational_status;
        rev.u_pci = app.u_pci;
        rev.u_pii = app.u_pii;
        rev.u_sox = app.u_sox;
        rev.u_soc1_nordstrom = app.u_soc1_nordstrom;
        rev.u_soc1_bank = app.u_soc1_bank;
        rev.u_review_complete = false;
        rev.insert();
    }

    rev.initialize();
    rev.query();
    logmsg += '\n' + rev.getRowCount() + ' records ready for review\nScript done';
    gs.log(logmsg);
}())
