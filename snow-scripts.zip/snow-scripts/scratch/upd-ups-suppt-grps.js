(function(){
    var ups = [
        {group: 'Regional IT - CT Local Region', upslist: [
            {name: 'up544-1a'	, ip_address: '10.165.162.28'},
            {name: 'up551-1a'	, ip_address: '10.167.66.28'},
            {name: 'up622-1a'	, ip_address: '10.162.2.28'},
            {name: 'up625-1a'	, ip_address: '10.166.130.28'},
            {name: 'up626-1a'	, ip_address: '10.162.130.28'},
            {name: 'up628-1a'	, ip_address: '10.162.162.28'},
            {name: 'up629-1a'	, ip_address: '10.162.194.28'},
            {name: 'up631-1a'	, ip_address: '10.163.130.28'},
            {name: 'up634-1a'	, ip_address: '10.163.162.28'},
            {name: 'up635-1a'	, ip_address: '10.163.66.28'},
            {name: 'up637-1a'	, ip_address: '10.162.226.28'},
            {name: 'up639-1a'	, ip_address: '10.164.194.28'},
            {name: 'up642-1a'	, ip_address: '10.165.2.28'},
            {name: 'up643-1a'	, ip_address: '10.164.226.28'},
            {name: 'up645-1a'	, ip_address: '10.176.34.28'},
            {name: 'up656-1a'	, ip_address: '10.177.194.28'},
            {name: 'up677-1a'	, ip_address: '10.177.2.28'},
            {name: 'up751-1a'	, ip_address: '10.193.194.28'},
            {name: 'up754-1a'	, ip_address: '10.196.194.28'}
        ]},
        {group: 'Regional IT - MW Local Region', upslist: [
            {name: 'up227-1a'	, ip_address: '10.64.226.28'},
            {name: 'up230-1a'	, ip_address: '10.65.66.28'},
            {name: 'up238-1a'	, ip_address: '10.67.2.28'},
            {name: 'up239-1a'	, ip_address: '10.67.98.28'},
            {name: 'up241-1a'	, ip_address: '10.66.226.28'},
            {name: 'up243-1a'	, ip_address: '10.67.162.28'},
            {name: 'up247-1a'	, ip_address: '10.68.2.28'},
            {name: 'up248-1a'	, ip_address: '10.68.34.28'},
            {name: 'up273-1a'	, ip_address: '10.66.34.28'},
            {name: 'up276-1a'	, ip_address: '10.64.194.28'},
            {name: 'up277-1a'	, ip_address: '10.69.2.28'},
            {name: 'up279-1a'	, ip_address: '10.69.194.28'},
            {name: 'up281-1a'	, ip_address: '10.68.226.28'},
            {name: 'up284-1a'	, ip_address: '10.70.2.28'},
            {name: 'up286-1a'	, ip_address: '10.69.226.28'},
            {name: 'up676-1a'	, ip_address: '10.177.34.28'}
        ]},
        {group: 'Regional IT - NCAL Local Region', upslist: [
            {name: 'up471-1a'	, ip_address: '10.131.2.28'},
            {name: 'up477-1a'	, ip_address: '10.131.194.28'}
        ]},
        {group: 'Regional IT - NE Local Region', upslist: [
            {name: 'up510-1a'	, ip_address: '10.176.162.28'},
            {name: 'up512-1a'	, ip_address: '10.163.194.28'},
            {name: 'up513-1a'	, ip_address: '10.167.34.28'},
            {name: 'up514-1a'	, ip_address: '10.166.66.28'},
            {name: 'up515-1a'	, ip_address: '10.164.98.28'},
            {name: 'up519-1a'	, ip_address: '10.166.2.28'},
            {name: 'up526-1a'	, ip_address: '10.160.194.28'},
            {name: 'up529-1a'	, ip_address: '10.166.34.28'},
            {name: 'up531-1a'	, ip_address: '10.161.130.28'},
            {name: 'up535-1a'	, ip_address: '10.161.162.28'},
            {name: 'up536-1a'	, ip_address: '10.164.2.28'},
            {name: 'up542-1a'	, ip_address: '10.160.162.28'},
            {name: 'up543-1a'	, ip_address: '10.165.98.28'},
            {name: 'up545-1a'	, ip_address: '10.165.130.28'},
            {name: 'up546-1a'	, ip_address: '10.164.66.28'},
            {name: 'up548-1a'	, ip_address: '10.166.226.28'},
            {name: 'up550-1a'	, ip_address: '10.161.194.28'},
            {name: 'up552-1a'	, ip_address: '10.166.98.28'},
            {name: 'up554-1a'	, ip_address: '10.167.130.28'},
            {name: 'up560-1a'	, ip_address: '10.176.2.28'}
        ]},
        {group: 'Regional IT - NW Local Region', upslist: [
            {name: 'up109-1a'	, ip_address: '10.36.226.28'},
            {name: 'up011-1a'	, ip_address: '10.34.98.28'},
            {name: 'up012-1a'	, ip_address: '10.3.2.28'},
            {name: 'up130-1a'	, ip_address: '10.37.34.28'},
            {name: 'up009-1a'	, ip_address: '10.32.162.28'}
        ]},
        {group: 'Regional IT - SCAL Local Region', upslist: [
            {name: 'up331-1a'	, ip_address: '10.103.162.28'},
            {name: 'up366-1a'	, ip_address: '10.120.2.28'},
            {name: 'up047-1a'	, ip_address: '10.34.194.28'},
            {name: 'up048-1a'	, ip_address: '10.34.66.28'},
            {name: 'up706-1a'	, ip_address: '10.34.130.28'}
        ]},
        {group: 'Regional IT - SE Local Region', upslist: [
            {name: 'up641-1a'	, ip_address: '10.165.34.28'},
            {name: 'up648-1a'	, ip_address: '10.177.66.28'},
            {name: 'up701-1a'	, ip_address: '10.223.194.28'},
            {name: 'up711-1a'	, ip_address: '10.200.2.28'},
            {name: 'up716-1a'	, ip_address: '10.200.130.28'},
            {name: 'up717-1a'	, ip_address: '10.200.98.28'},
            {name: 'up750-1a'	, ip_address: '10.193.226.28'},
            {name: 'up758-1a'	, ip_address: '10.199.66.28'},
            {name: 'up759-1a'	, ip_address: '10.197.98.28'},
            {name: 'up760-1a'	, ip_address: '10.192.130.28'},
            {name: 'up764-1a'	, ip_address: '10.192.226.28'},
            {name: 'up772-1a'	, ip_address: '10.195.34.28'},
            {name: 'up782-1a'	, ip_address: '10.196.130.28'},
            {name: 'up783-1a'	, ip_address: '10.197.162.28'},
            {name: 'up787-1a'	, ip_address: '10.197.226.28'},
            {name: 'up788-1a'	, ip_address: '10.198.66.28'},
            {name: 'up791-1a'	, ip_address: '10.199.162.28'},
            {name: 'up792-1a'	, ip_address: '10.199.34.28'}
        ]},
        {group: 'Regional IT - SW Local Region', upslist: [
            {name: 'up150-1a'	, ip_address: '10.82.226.28'},
            {name: 'up151-1a'	, ip_address: '10.81.66.28'},
            {name: 'up155-1a'	, ip_address: '10.83.66.28'},
            {name: 'up166-1a'	, ip_address: '10.104.130.28'},
            {name: 'up361-1a'	, ip_address: '10.98.226.28'},
            {name: 'up367-1a'	, ip_address: '10.103.98.28'},
            {name: 'up371-1a'	, ip_address: '10.83.2.28'},
            {name: 'up376-1a'	, ip_address: '10.82.162.28'},
            {name: 'up377-1a'	, ip_address: '10.100.194.28'},
            {name: 'up379-1a'	, ip_address: '10.100.2.28'},
            {name: 'up380-3a'	, ip_address: '10.99.98.28'},
            {name: 'up381-2a'	, ip_address: '10.100.130.28'},
            {name: 'up383-1a'	, ip_address: '10.101.98.28'},
            {name: 'up386-1a'	, ip_address: '10.101.2.28'},
            {name: 'up388-1a'	, ip_address: '10.102.98.28'},
            {name: 'up389-1a'	, ip_address: '10.102.130.28'},
            {name: 'up713-1a'	, ip_address: '10.201.98.28'},
            {name: 'up721-1a'	, ip_address: '10.216.2.28'},
            {name: 'up730-1a'	, ip_address: '10.194.130.28'},
            {name: 'up732-1a'	, ip_address: '10.195.66.28'},
            {name: 'up734-1a'	, ip_address: '10.195.162.28'},
            {name: 'up741-1a'	, ip_address: '10.196.66.28'},
            {name: 'up744-1a'	, ip_address: '10.197.130.28'},
            {name: 'up745-1a'	, ip_address: '10.197.194.28'},
            {name: 'up746-1a'	, ip_address: '10.198.226.28'},
            {name: 'up747-1a'	, ip_address: '10.199.2.28'},
            {name: 'up748-1a'	, ip_address: '10.198.194.28'},
            {name: 'up749-1a'	, ip_address: '10.198.162.28'},
            {name: 'up770-1a'	, ip_address: '10.193.2.28'},
            {name: 'up770-1b'	, ip_address: '10.193.2.28'},
            {name: 'up785-1a'	, ip_address: '10.198.2.28'}
        ]}
    ];
    function updateGroup(ups) {
        var gr = new GlideRecord('cmdb_ci_ups');
        var sys_id = getGroupSysid(ups.group);
        for (var i = 0; i < ups.upslist.length; i++) {
            gr.initialize();
            gr.addQuery('name', ups.upslist[i].name);
            gr.addQuery('ip_address', ups.upslist[i].ip_address);
            gr.setWorkflow(false);
            gr.setLimit(1);
            gr.query();
            if (gr.next()) {
                gs.print('Updating UPS: ' + ups.upslist[i].name + ', IP: ' + ups.upslist[i].ip_address + ', Group: ' + ups.group);
                gr.support_group.setValue(sys_id);
                gr.update();
            } else {
                gs.print('Did not find UPS: ' + ups.upslist[i].name + ', IP: ' + ups.upslist[i].ip_address);
            }
        }
    }

    function getGroupSysid(group) {
        var gr = new GlideRecord('sys_user_group');
        gr.addQuery('name', group);
        gr.query();
        if (gr.next()) {
            gs.print('Sys_id for group ' + group + ' is ' + gr.sys_id);
            return gr.sys_id;
        } else {
            gs.print('Group ' + group + ' not found');
            return null;
        }
    }

    for (var i = 0; i < ups.length; i++) {
        updateGroup(ups[i]);
    }
}())
