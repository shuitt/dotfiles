#!/usr/bin/env python3

import csv

IN_APP_MAP = '/Users/xsmh/Downloads/sn-apps-with-sys_ids.txt'
IN_APPS = '/Users/xsmh/Downloads/Server Tagging Apps.txt'
OUT_APPS = '/Users/xsmh/Downloads/Server Tagging Apps Updated.txt'

app_dict = {}

#------------------------------------------------------------------------------
# read a tsv file into a list
#------------------------------------------------------------------------------
def getListTsv(file_name):
    print('Reading TSV file', file_name)
    with open(file_name, 'r') as f:
        reader = csv.reader(f, dialect="excel-tab")
        the_list = list(reader)
    f.close()
    print('%d rows read from TSV file' % len (the_list))
    return the_list

#------------------------------------------------------------------------------
# create a dictionary of apps to their sys_ids
# params: app_list - list with app info
#------------------------------------------------------------------------------
def makeAppMap(app_list):
    del app_list[0]
    for app in app_list:
        if app[0] in app_dict:
            print('Duplication app: ' + app[0])
        else:
            app_dict[app[0]] = app[1] # map app long name to sys_id
    print("%d mapped applications loaded" % len(app_dict))
    #for k, v in app_dict.items():
    #    print(k + ' => ' + v)

#------------------------------------------------------------------------------
# create a new server tagging tsv file with
# params: st_list - list with st info
#------------------------------------------------------------------------------
def makeTaggingCsv(st_list, out_file):
    print('Output tagging file is ' + out_file)
    missing_apps = []
    header = ['Server Name', 'App Name', 'Sys_id']
    del st_list[0]
    server_count = 0
    with open(out_file, 'w', newline='') as f:
        writer = csv.writer(f, dialect="excel-tab")
        writer.writerow(header)
        for server in st_list:
            out_row = [''] * len(header)
            out_row[0] = server[0]      # server name
            if server[1] in app_dict:   # check app name
                out_row[1] = server[1]  # app name
                out_row[2] = app_dict[server[1]]  # app sys_id
                writer.writerow(out_row)
                server_count += 1
            else:
                if not server[1] in missing_apps:
                    missing_apps.append(server[1])
    print('%d user rows written' % server_count)
    print('Applciations not found in SN:')
    for app in missing_apps:
        print('\t' + app)
    f.close()

#-----------------------------------------------------------------------------
# main program logic
#------------------------------------------------------------------------------
if __name__ == '__main__':
    print('Script staring')
    app_list = getListTsv(IN_APP_MAP)
    makeAppMap(app_list)
    st_list = getListTsv(IN_APPS)
    makeTaggingCsv(st_list, OUT_APPS)
    print('Script completed')
