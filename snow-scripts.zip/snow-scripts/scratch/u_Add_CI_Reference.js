// Before insert or update into u_server_tagging
// condition: u_server_ci is empty

(function executeRule(current, previous /*null when async*/) {
	stUtils = new u_ServerTaggingUtils();
	var ci_id = stUtils.findServerCI(current.u_server_name);

    // if matching ci exists add ci <-> st rec refrences
	if (ci_id != null) {
		current.u_server_ci = ci_id;
		stUtils.addRefToCI(ci_id, current.sys_id);
	}
})(current, previous);
