(function(){
	stUtils = new u_ServerTaggingUtils();
	var id = null;
	var ci_id = null;
	var st_id = null;

	// existing server ci and it's sys_id
	var a0001t01 = 'a0001t01';
	var a0001t01_ci_id = 'd1e71345db587640cdf5f8fdae9619ba';
	var a0001t01_st_id = '82d19194db4a7ac063f6fcfaae961988';
	var a0002dc1 = 'a0002dc1';
	var a0002dc1_ci_id = '2f6757c1db587640cdf5f8fdae961914';
	var a0004dc1 = 'a0004dc1';
	var a0004dc1_id = 'e3385fc5db587640cdf5f8fdae961982';


	// existing st ecord it's sys_id
	var test = 'test';
	var test_id = '715acbafdbf936c063f6fcfaae96192d';

	// non-existant server and sys_id
	var nunya = 'nunya';
	var nunya_id = 'd1e7134000087640cdffffae9619ba';

	// test findServerCI(server_name)
	id = stUtils.findServerCI(a0001t01);  // existing server
	if (id == a0001t01_ci_id) {
		gs.print('findServerCI: found a0001t01');
	} else {
		gs.print('findServerCI: ERROR: a0001t01 not found - id returned was: ' + id + ', should be: ' + a0001t01_ci_id);
	}
	id = stUtils.findServerCI(nunya);  // non existant server
	if (id == null) {
		gs.print('findServerCI: nunya not found, as expected');
	} else {
		gs.print('findServerCI: ERROR: huh, nunya found: ' + id);
	}

	// test findTaggedServer(server_name)
	id = stUtils.findTaggedServer(a0001t01);  // existing st rec
	if (id == a0001t01_st_id) {
		gs.print('findTaggedServer: found a0001t01');
	} else {
		gs.print('findTaggedServer: ERROR: a0001t01 not found - id returned was: ' + id + ', should be: ' + a0001t01_st_id);
	}
	id = stUtils.findServerCI(nunya);  // non existant st rec
	if (id == null) {
		gs.print('findTaggedServer: nunya not found, as expected');
	} else {
		gs.print('findTaggedServer: ERROR: huh, nunya found: ' + id);
	}

	// test addRefToCI(ci_id, tags_id)
	id = stUtils.addRefToCI(a0001t01_ci_id, a0001t01_st_id);	// existing records
	if (id != null) {
		gs.print('addRefToCI: a0001t01 updated with st ref');
		ci_id = id;
	} else {
		gs.print('addRefToCI: ERROR: a0001t01 update failed');
	}
	id = stUtils.addRefToCI(nunya_id, a0001t01_st_id);	// non existant ci sys_id
	if (id == null) {
		gs.print('addRefToCI: nunya_id update failed, as expected');
	} else {
		gs.print('addRefToCI: ERROR: nunya_id update did not fail, id is' + id);
	}
	id = stUtils.addRefToCI(a0002dc1_ci_id, nunya_id);	// non existant st sys_id
	if (id != null) {
		gs.print('addRefToCI: a0002dc1 updated, as expected, id is ' + id);
	} else {
		gs.print('addRefToCI: ERROR: a0002dc1 update failed unexpectedly');
	}

	// test addRefToServer(tags_id, ci_id)
	id = stUtils.addRefToServer(a0001t01_st_id, ci_id);	// existing records
	if (id != null) {
		gs.print('addRefToServer: a0001t01 updated with ci ref');
		st_id = id;
	} else {
		gs.print('addRefToServer: ERROR: a0001t01 update failed');
	}
	id = stUtils.addRefToServer(nunya_id, ci_id);	// 2 - non existant tags_id
	if (id != null) {
		gs.print('addRefToServer: ERROR: huh? nunya_id updated with ci ref');
	} else {
		gs.print('addRefToServer: nunya_id update failed, as expected');
	}
	id = stUtils.addRefToServer(st_id, nunya_id);	// 3 - non existant ci_id
	if (id != null) {
		gs.print('addRefToServer:a0001t01 updated with nunya ci ref');
	} else {
		gs.print('addRefToServer: ERROR: a0001t01 update failed with nunya server ref sys_id');
	}

	// test createTaggedServer(server_name, ci_id)
	id = stUtils.createTaggedServer(a0004dc1, a0004dc1_id);	// 1 - non existant server name
	if (id != null) {
		gs.print('createTaggedServer: a0004dc1 record created');
		st_id = id;
	} else {
		gs.print('createTaggedServer: ERROR: a0004dc1 create record failed');
	}
	id = stUtils.stUtils(a0004dc1, a0004dc1_id);	// 2 - existing server name
	if (id == st_id) {
		gs.print('createTaggedServer: duplicate a0004dc1 returns existing record sys_id');
	} else {
		gs.print('createTaggedServer: ERROR: duplicate a0004dc1 returned null');
	}
	id = stUtils.stUtils(a0001t01, nunya_id);	// 3 - non existant ci_id
	if (id == st_id) {
		gs.print('createTaggedServer:a0001t01 updated with nunya_id');
	} else {
		gs.print('createTaggedServer: ERROR: a0001t01 not updated with nunya_id');
	}
}())
