var u_Unisys_Integration_Utils = Class.create();
u_Unisys_Integration_Utils.prototype = {
	LOGPFX: '--> Unisys integration: ',

    initialize: function(logging) {
		this.logging = logging;
		this.audit = new GlideRecord('u_unisys_integration_audit_record');
    },

	//// functions supporting outbound integration

	// send a message to Unisys to create an associated srms ticket
	// task - task GlideRecord
	createTicket: function(task) {
		this.writeLog('Creating ticket for ' + task.number);
		var msg = this.makeCreateMsg(task);
		var result = this.callUnisysApi(msg);
		if (result.success) {
			task.comments.setJournalEntry('Unisys message broker successfuly called.');
		} else {
			this.writeErrorLog('Message broker call failed for : ' + task.number + '\nResponse:' +
						   JSON.stringify(result.body) + '\nHTTP status: ' + result.status);
			task.assignment_group.setValue(gs.getProperty('u_nord.unisys.task.reassign.group.id'));
			task.comments.setJournalEntry('Unisys message broker call failed. Reassigning to Service Desk.');
			task.assigned_to.setValue('');
		}
		task.u_unisys_ticket.setValue('');
		task.u_unisys_state.setValue('');
		this.outboundAudit(task, 'Create', msg.getRequestBody(), result);
	},

	// set the create srms ticket message properties
	// task - task GlideRecord
	makeCreateMsg: function(task) {
		this.writeLog('In makeCreateMsg for ' + task.number);
		var msg = new sn_ws.RESTMessageV2(this.getRestMsgName(), 'create');

		// set the properties common to all task types
		msg.setStringParameter('task_type', this.getUnisysTaskType(task.sys_class_name.getValue()));
		msg.setStringParameter('source_id', this.generateSourceId());
		msg.setStringParameter('sent_date', new GlideDateTime().toString());
		msg.setStringParameter('sntask', task.number.getValue());
		msg.setStringParameter('sys_id', task.sys_id.getValue());
		msg.setStringParameter('opened_on', this.getLocLocalTime(task));
		msg.setStringParameter('short_description', this.escapeCtrlChars(task.short_description));

		// add headings if there are comments or work notes
		var comments = task.comments.getJournalEntry(-1);
		if (!gs.nil(comments)) {
			comments += 'Comments:\n\n' + comments + '\n\n';
		} else {
			comments = '';
		}
		var notes = task.work_notes.getJournalEntry(-1);
		if (!gs.nil(notes)) {
			notes += 'Work notes: \n\n' + notes;
		} else {
			notes = '';
		}
		msg.setStringParameter('notes', this.escapeCtrlChars(comments) + this.escapeCtrlChars(notes));

		// set some common or default field values
		msg.setStringParameter('reqester', '');
		msg.setStringParameter('reqester_phone', '');
		msg.setStringParameter('serial', '');
		msg.setStringParameter('urgency', task.priority);
		var phone = null;

		// set task type type specific fields
		if (task.sys_class_name == 'incident') {  // incident
			msg.setStringParameter('description', this.escapeCtrlChars(task.description));
			msg.setStringParameter('location', task.location.u_store_number);
			msg.setStringParameter('code', this.getIncStyle(task));
			msg.setStringParameter('serial', task.cmdb_ci.serial_number);
			msg.setStringParameter('fname', task.caller_id.first_name);
			msg.setStringParameter('lname', task.caller_id.last_name);
			phone = task.caller_id.phone;
		} else if (task.sys_class_name == 'sc_task') {  // sc task
			var ritmvars = this.getRitmVars(task);
			msg.setStringParameter('description', this.escapeCtrlChars(task.description) +
												  this.escapeCtrlChars(this.formatRitmVars(ritmvars)));
			msg.setStringParameter('code', this.getScTaskStyle(task));
			msg.setStringParameter('fname', task.request.requested_for.first_name);
			msg.setStringParameter('lname', task.request.requested_for.last_name);
			phone = task.request.requested_for.phone;
			msg.setStringParameter('reqester', task.request.opened_by.name);
			msg.setStringParameter('reqester_phone', task.request.opened_by.phone);
			var store = findStoreFromVars(ritmvars);
			if (!gs.nil(store)) {
				msg.setStringParameter('location', store);
			} else {
				msg.setStringParameter('location', task.request_item.request.requested_for.location.u_store_number);
			}
		} else { // other task types
			msg.setStringParameter('description', this.escapeCtrlChars(task.description));
			msg.setStringParameter('location', task.location.u_store_number);
			msg.setStringParameter('code', 'NRD1-SMT');
			msg.setStringParameter('fname', task.opened_by.first_name);
			msg.setStringParameter('lname', task.opened_by.last_name);
			phone = task.opened_by.phone;
		}

		// if user's phone is null get location phone
		if (gs.nil(phone)) {
			msg.setStringParameter('phone', task.location.phone);
		} else {
			msg.setStringParameter('phone', phone);
		}

		this.writeLog('Leaving makeCreateMsg for ' + task.number);
		return msg;
	},

	// convert task opned at to the location's local time
	// task - task GlideRecord
	getLocLocalTime: function(task) {
		this.writeLog('In getLocLocalTime for ' + task.number);
		var opened_at = new GlideDateTime(task.opened_at);
		this.writeLog('Location: ' + task.location.name + ', TZ offset: ' + task.location.u_time_zone_offset);
		if (!gs.nil(task.location.u_time_zone_offset)) {
			var offset = task.location.u_time_zone_offset.split(':');
			opened_at.addSeconds(60 * 60 * offset[0] + 60 * offset[1]);
		}
		this.writeLog('In getLocLocalTime: task.opened_at: ' + task.opened_at.toString() + ', localtime: ' + opened_at.toString());
		return opened_at.toString();
	},

	// get the unisys defined task type value, assume incident
	// type - task class name
	getUnisysTaskType: function(type) {
		this.writeLog('In getUnisysTaskType');
		var u_type = 'Incident';
        switch (type) {
            case 'sc_task':
                u_type = 'SC Task';
                break;
            case 'incident_task':
                u_type = 'Incident Task';
                break;
            case 'problem_task':
                u_type = 'Problem Task';
                break;
            case 'change_task':
                u_type = 'Change Task';
                break;
        }
		this.writeLog('SN task type: ' + type + ', SRMS type: ' + u_type);
        return u_type;
	},

	// get the ritm vars for a sc task and store in an array of objects
	// task - task GlideRecord
	getRitmVars: function(task) {
        this.writeLog('In getRitmVars for ' + task.number);
        var vars = [];
        var set = new GlideappVariablePoolQuestionSet();
        set.setRequestID(task.request_item);
        set.load();
        var vs = set.getFlatQuestions();
        for (var i = 0; i < vs.size(); i++) {
            if(vs.get(i).getLabel() != '') {
                vars.push({label: vs.get(i).getLabel(),
                            name: vs.get(i).getName(),
                            value: vs.get(i).getDisplayValue(),
                            type: vs.get(i).getType()});
            }
        }
        if (!gs.nil(vars)) {
            return vars;
        } else {
            return '';
        }
	},

	// format a ritm variables object into a string
	// vars - object containing ritm variable info
	formatRitmVars: function(vars) {
        this.writeLog('In formatRitmVars');
        var varstring = '';
        for (var i = 0; i < vars.length; i++) {
            if (vars[i].label.endsWith(':')) {
                varstring += '\n' + vars[i].label.slice(0, -1) + ': ' + vars[i].value;
            } else {
                varstring += '\n' + vars[i].label + ': ' + vars[i].value;
            }
        }
        if (!gs.nil(varstring)) {
            return 'Request item variables:\n' + varstring;
        } else {
            return varstring;
        }
    },

	// check ritm variables for a reference to cmn_location and if found get
	// the location's store number
	// vars - object containing ritm variable info
	findStoreFromVars: function(vars) {
        this.writeLog('In findStoreFromVars');
        var query = 'reference=cmn_location^name=';
        var gr = new GlideRecord('item_option_new');
        var store = new GlideRecord('cmn_location');

		// for single line (6) or reference (8) type vars see if they reference the
		// cmn_location table. if so use the variale's value to get the store number.
        for (var i = 0; i < vars.length; i++) {
            if (vars[i].type == 6 || vars[i].type == 8) {
                gr.initialize();
                gr.addEncodedQuery(query + vars[i].name);
                gr.query();
                if (gr.next()){
                    store.initialize();
                    store.addQuery('name', vars[i].value);
                    store.query();
                    if (store.next()) {
                        return store.u_store_number;
                    }
                }
            }
        }
        return null;
    },

	// get the unisys pcd style code for an incident
	// task - incident GlideRecord
	getIncStyle: function(task) {
		this.writeLog('In getIncStyle for ' + task.number);
		var style = 'NRD1-SMT';
		if (task.cmdb_ci.name.toLowerCase() == 'mpos' &&
			task.category == 'hardware' &&
			task.subcategory == 'mobile_device') {
				style = 'NRD1-MPS';
		} else if (task.cmdb_ci.name.toLowerCase() == 'tpos' &&
			task.category == 'hardware' &&
			task.subcategory == 'register') {
				style = 'NRD1-TPS';
		} else if (task.cmdb_ci.name.toLowerCase() == 'rpos' &&
			task.category == 'hardware' &&
			task.subcategory == 'register') {
				style = 'NRD1-RPS';
		} else if (task.category == 'hardware') {
			if (task.subcategory== 'desktop_laptop') {
				style = 'NRD1-DSS';
			} else if (task.subcategory== 'mobile_device') {
				style = 'NRD1-IPD';
			} else if (task.subcategory== 'printer_scanner_MFD') {
				style = 'NRD1-PRT';
			}
		}
		this.writeLog('PCD style: ' + style);
		return style;
	},

	// get the style code for a sc task
	// task - task GlideRecord
	getScTaskStyle: function(task) {
		this.writeLog('In getScTaskStyle for ' + task.number);
		var style = 'NRD1-SMT';
		var item_name = task.request_item.cat_item.name.toLowerCase();
		if (item_name.indexOf('remov') >= 0 || item_name.indexOf('replac') >= 0 || item_name.indexOf('recycle') >= 0) {
			style = 'NRD1-DIN';
		} else if (item_name.indexOf('relocat') >= 0 || item_name.indexOf('move') >= 0 ) {
			style = 'NRD1-MOV';
		} else if (item_name.indexOf('computer set') >= 0 || item_name.indexOf('reimage') >= 0) {
			style = 'NRD1-DSS';
		} else if (item_name.indexOf('phone extension change') >= 0) {
			style = 'NRD1-CHG';
		} else if (item_name.indexOf('new phone') >= 0 || item_name.indexOf('add') >= 0 ||
			item_name.indexOf('install') >= 0 || item_name.indexOf('activat') >= 0 ||
			item_name.indexOf('store depot') >= 0 || item_name.indexOf('hardware purchase') >= 0 ||
			item_name.indexOf('supply') >= 0 || item_name.indexOf('order') >= 0) {
				style = 'NRD1-INS';
		}
		this.writeLog('PCD style: ' + style);
		return style;
	},

	// add new SN task comments or work notes to srms ticket
	// task - task GlideRecord
	updateTicket: function(task) {
		this.writeLog('Updating ticket for ' + task.number + ', (SRMS ' + task.u_unisys_ticket + ')');
		var msg = this.makeUpdateMsg(task);
		var result = this.callUnisysApi(msg);
		if (result.success) {
			task.comments.setJournalEntry('Unisys message broker successfuly called.');
		} else {
			this.writeErrorLog('Message broker call failed for : ' + task.number + '\nResponse:' +
					   JSON.stringify(result.body) + '\nHTTP status: ' + result.status);
			task.comments.setJournalEntry('Unisys message broker call failed. Comments or work  notes not updated in SRMS ticket.');
		}
		this.outboundAudit(task, 'Update', msg.getRequestBody(), result);
	},

	// set the update srms ticket message properties
	// task - task GlideRecord
	makeUpdateMsg: function(task) {
		this.writeLog('In makeUpdateMsg for ' + task.number);
		var msg = new sn_ws.RESTMessageV2(this.getRestMsgName(), 'update');
		msg.setStringParameter('task_type', task.sys_class_name.getValue());
		msg.setStringParameter('source_id', this.generateSourceId());
		msg.setStringParameter('sent_date', new GlideDateTime().toString());
		msg.setStringParameter('sntask', task.number.getValue());
		msg.setStringParameter('srms', task.u_unisys_ticket.getValue());

		var update = '';
		if (task.comments.changes()) {
			update = task.comments.getJournalEntry(1);
		} else if (task.work_notes.changes()) {
			update = task.work_notes.getJournalEntry(1);
		}

		msg.setStringParameter('notes', this.escapeCtrlChars(update));
		this.writeLog('Leaving makeUpdateMsg for ' + task.number);
		return msg;
	},

	// SRMS sent reassignment update
	// task - task GlideRecord
	reassignTicket: function(task) {
		this.writeLog('Reassigning ticket for ' + task.number + ', (SRMS ' + task.u_unisys_ticket + ')');
		task.u_unisys_ticket.setValue('');
		task.u_unisys_state.setValue('');
		task.assigned_to.setValue('');
		task.assignment_group.setValue(gs.getProperty('u_nord.unisys.task.reassign.group.id'));
		task.state.setValue(1);
	},

	// sn task assignment group chgs from unisys dispatch queue
	// task - task GlideRecord
	unassignTicket: function(task) {
		this.writeLog('Unassigning ticket for ' + task.number + ', (SRMS ' + task.u_unisys_ticket + ')');
		var msg = this.makeCancelMsg(task, 'reassigned');
		var result = this.callUnisysApi(msg);

		if (result.success) {
			this.writeErrorLog('Message broker call failed for : ' + task.number + '\nResponse:' +
						   JSON.stringify(result.body) + '\nHTTP status: ' + result.status);
			task.comments.setJournalEntry('Cancel SRMS ticket message successfuly sent - SRMS ticket ' + task.u_unisys_ticket +' will be cancelled.');
		} else {
			task.comments.setJournalEntry('Cancel SRMS ticket message failed - SRMS ticket ' + task.u_unisys_ticket +' will NOT be cancelled.');
		}

		task.u_unisys_ticket.setValue('');
		task.u_unisys_state.setValue('');
		task.assigned_to.setValue('');
		task.state.setValue(1);
		this.outboundAudit(task, 'Unassign', msg.getRequestBody(), result);
	},

	// SN task state chg to cancel or resolve
	// task - task GlideRecord
	cancelTicket: function(task) {
		this.writeLog('Cancelling ticket for ' + task.number + ', (SRMS ' + task.u_unisys_ticket + ')');
		var msg = this.makeCancelMsg(task, 'cancelled');
		var result = this.callUnisysApi(msg);

		if (result.success) {
			task.comments.setJournalEntry('Cancel SRMS ticket message successfuly sent - SRMS ticket ' + task.u_unisys_ticket +' will be cancelled.');
		} else {
			this.writeErrorLog('Message broker call failed for : ' + task.number + '\nResponse:' +
						   JSON.stringify(result.body) + '\nHTTP status: ' + result.status);
			task.comments.setJournalEntry('Cancel SRMS ticket message failed - SRMS ticket ' +
										   task.u_unisys_ticket +' will NOT be cancelled.');
		}

		task.u_unisys_ticket.setValue('');
		task.u_unisys_state.setValue('cancel');
		this.outboundAudit(task, 'Cancel', msg.getRequestBody(), result);
	},

	// set the cancel srms ticket message properties
	// task - task GlideRecord
	makeCancelMsg: function(task, reason) {
		this.writeLog('In makeCancelMsg for ' + task.number);
		var msg = new sn_ws.RESTMessageV2(this.getRestMsgName(), 'cancel');
		msg.setStringParameter('task_type', task.sys_class_name.getValue());
		msg.setStringParameter('source_id', this.generateSourceId());
		msg.setStringParameter('sent_date', new GlideDateTime().toString());
		msg.setStringParameter('sntask', task.number.getValue());
		msg.setStringParameter('srms', task.u_unisys_ticket.getValue());
		var text = 'The ServiceNow ticket has been ' + reason + ' by Nordstrom\n\n';

		var update = '';
		if (task.comments.changes()) {
			update = task.comments.getJournalEntry(1);
		} else if (task.work_notes.changes()) {
			update = task.work_notes.getJournalEntry(1);
		}

		msg.setStringParameter('notes', this.escapeCtrlChars(text) + this.escapeCtrlChars(update));
		this.writeLog('Leaving makeCancelMsg for ' + task.number);
		return msg;
	},

	// determine which rest message to use based on instance
	getRestMsgName: function() {
		this.writeLog('In getRestMsgName: instance is ' + gs.getProperty('instance_name'));
		if (gs.getProperty('instance_name') == 'nordstrom') {
			this.writeLog('Using REST message Unisys Message Broker Prod');
			return 'Unisys Message Broker Prod';
		} else {
			this.writeLog('Using REST message Unisys Message Broker Nonprod');
			return 'Unisys Message Broker Nonprod';
		}
	},

	// escape control chars in a string
	escapeCtrlChars: function(str) {
		return str.replace(/\n/g, "\\n").replace(/\r/g, "\\r");
	},

	// generate a guid-like source id for unisys message broker calls
	generateSourceId: function() {
        var uuid = '';
        for (var i = 0; i < 32; i++) {
            var random = Math.random() * 16 | 0;
            if (i == 8 || i == 12 || i == 16 || i == 20) {
                uuid += '-';
            }
            uuid += (i == 12 ? 4 : (i == 16 ? (random & 3 | 8) : random)).toString(16);
        }
        return uuid;
    },

	// call the unisys message broker api
	// msg - rest message object
	callUnisysApi: function(msg) {
		this.writeLog('In callUnisysApi');
		var response = null;
		var result = {'status': null,
			'body': null,
			'errmsg': null,
			'success': true
		};

		try {
			response = msg.execute();
		} catch(ex) {
			result.errmsg = 'REST message exception: ' + ex.getMessage();
			result.success = false;
			return result;
		}

		result.status = response.getStatusCode();
		if (result.status == 401) {
			result.errmsg = 'Unauthorized - Unisys message broker credential are probably incorrect';
			result.success = false;
			return result;
		}
		if (result.status == 0) {
			result.errmsg = 'Error code: ' + response.getErrorCode() + ', ' + response.getErrorMessage();
			result.success = false;
			return result;
		}

		if (!gs.nil(response)) {
			result.body = JSON.parse(response.getBody());
		}
		if (gs.nil(result.body.CommAck.Acknowledge) || result.body.CommAck.Acknowledge != '1') {
			result.success = false;
		}
		return result;
	},

	//// functions supporting inbound integration

	// get properties from an inbound api requst
	// req - request body object
	getReqProperties: function(req){
		var logmsg = 'In getReqProperties, request properties:';
		var props = {};
		if (req.hasOwnProperty('state')) {  // new task state
			logmsg += '\nstate = ' + req.state;
			props.state = req.state;
		}
		if (req.hasOwnProperty('comments')) {  // new task comments
			logmsg += '\ncomments = ' + req.comments;
			props.comments = req.comments;
		}
		if (req.hasOwnProperty('u_unisys_ticket')) {  // associated unisys srms ticket
			logmsg += '\nu_unisys_ticket = ' + req.u_unisys_ticket;
			props.u_unisys_ticket = req.u_unisys_ticket;
		}
		if (req.hasOwnProperty('u_unisys_workflow')) {  // new unisys workflow state
			logmsg += '\nu_unisys_workflow = ' + req.u_unisys_workflow;
			props.u_unisys_workflow = req.u_unisys_workflow;
		}
		if (req.hasOwnProperty('close_code')) {  // incident resolve code
			logmsg += '\nclose_code = ' + req.close_code;
			props.close_code = req.close_code;
		}
		if (req.hasOwnProperty('close_notes')) {  // incident resolve notes
			logmsg += '\nclose_notes = ' + req.close_notes;
			props.close_notes = req.close_notes;
		}
		if (req.hasOwnProperty('hold_reason')) {  // incident hold reason
			logmsg += '\nhold_reason = ' + req.hold_reason;
			props.hold_reason = req.hold_reason;
		}
		this.writeLog(logmsg);
		return props;
	},

	// get the record to update
	// sys_id - task sys_id
	getTaskRecord: function(sys_id) {
		this.writeLog('In getTaskRecord: sys_id = ' + sys_id);
    	var gr = new GlideRecord('incident');
    	gr.addQuery('sys_id', sys_id);
    	gr.setLimit(1);
    	gr.query();
    	if (gr.next()) {
			this.writeLog('In getTaskRecord: found: ' + gr.number);
			return gr;
		} else {
	    	gr = new GlideRecord('task');
	    	gr.addQuery('sys_id', sys_id);
	    	gr.setLimit(1);
	    	gr.query();
			if (gr.next()) {
				this.writeLog('In getTaskRecord: found: ' + gr.number);
				return gr;
			} else {
				return null;
			}
		}
    },

	// update a task when the srms bond failed
	// task - task GlideRecord
	// props - object containing request body properties
	updateFailedBond: function(task, props) {
		this.writeLog('In updateFailedBond for ' + task.number);
		task.assigned_to.setValue("");
		task.assignment_group = gs.getProperty('u_nord.unisys.task.reassign.group.id');
		task.u_unisys_state = props.u_unisys_workflow;
		task.state = 1;
		var reason = props.comments + '';
		task.comments.setJournalEntry('Task being reassigned due to Unisys SRMS ticket bonding failure: ' + reason);
		return task.update();
	},

	// set response and log inbound api errors
	// response - rest message response object
	// logmsg - string, will be logged
	// errmsg - string describing error in detail
	// status - the http status code to return to the caller
	inBoundError: function(response, logmsg, errmsg, status) {
		this.writeLog('In inBoundError');
	    var myError = new sn_ws_err.ServiceError();
	    myError.setMessage('Request failed');
	    myError.setDetail(errmsg);
	    myError.setStatus(status);
	    response.setError(myError);
	    this.writeErrorLog(logmsg + '\nError: ' + errmsg);
	},

	// update a sn incident
	// task - incident GlideRecord
	// props - object containing request body properties
	updateSnIncident: function(task, props) {
		this.writeLog('In updateSnIncident for ' + task.number);
		if (!gs.nil(props.state)) {
			task.state = props.state;
			if (props.state == 6 || props.state == 8) {  // resolve or cancel
				task.close_code = props.close_code;
				task.close_notes = props.close_notes;
				if (gs.nil(task.cmdb_ci)) {
					this.writeLog('In updateSnIncident: setting incident CI');
					task.cmdb_ci.setValue(gs.getProperty('nordstrom.notlisted.ci'));
					task.u_missing_ci = 'Unknown';
				}
			} else if (props.state == 3) {  // on hold
				task.hold_reason = props.hold_reason;
			}
		}
		if (!gs.nil(props.u_unisys_ticket)) {
			task.u_unisys_ticket = props.u_unisys_ticket;
		}
		if (!gs.nil(props.u_unisys_workflow)) {
			task.u_unisys_state = props.u_unisys_workflow;
		}
		if (!gs.nil(props.comments)) {
			task.comments.setJournalEntry(props.comments);
		}
		return task.update();
	},

	// update a sn task
	// task - task GlideRecord
	// props - object containing request body properties
	updateSnTask: function(task, props) {
		this.writeLog('In updateSnTask for ' + task.number);
		if (!gs.nil(props.state)) {
			task.state = props.state;
		}
		if (!gs.nil(props.u_unisys_ticket)) {
			task.u_unisys_ticket = props.u_unisys_ticket;
		}
		if (!gs.nil(props.u_unisys_workflow)) {
			task.u_unisys_state = props.u_unisys_workflow;
		}
		if (!gs.nil(props.comments)) {
			task.comments.setJournalEntry(props.comments);
		}
		return task.update();
	},

	// check whether a choice field value is valid
	// type - task class name
	// element - sys_choice element name
	// value - sys_choice value
	isValidChoice: function(type, element, value) {
		this.writeLog('In isValidHoldChoiceReason: type: ' + type + ', element: ' + element + ', value: ' + value);
		var gr = new GlideRecord('sys_choice');
		if (type == 'incident') {
        	gr.addQuery('name', type);
		} else {
			gr.addQuery('name', 'task');
		}
        gr.addQuery('element', element);
        gr.addQuery('value', value.toString());
		gr.addQuery('inactive', false);
        gr.setLimit(1);
        gr.query();
        return gr.hasNext();
	},

	//// auditing and logging functions

	// write a record to the audit table for an outbound integration action
	// task - a task GlideRecord
	// action - action performed
	// body - outbound request body
	// result - object containing outbound result
	outboundAudit: function(task, action, body, result) {
		this.writeLog('In outboundAudit');
		this.audit.NewRecord();
		this.audit.u_action = 'Outbound ' + action;
		this.audit.u_outbound_message_body = body;
		this.audit.u_outbound_response = JSON.stringify(result);
		this.audit.u_outbound_status_code = result.status;
		this.audit.u_srms_ticket_number = task.u_unisys_ticket;
		this.audit.u_task = task.sys_id.getValue();
		this.audit.insert();
	},

	// write a record to the audit table for an inbound integration action
	// task - a task GlideRecord
	// action - action performed
	// body - inbound request body
	// result - object containing inbound processing result
	// status - http status code returned
	inboundAudit: function(task, action, body, result, status) {
		this.writeLog('In inboundAudit');
		this.audit.NewRecord();
		this.audit.u_action = 'Inbound ' + action;
		this.audit.u_inbound_message_body = body;
		this.audit.u_inbound_response = result;
		this.audit.u_inbound_status_code = status;
		if (!gs.nil(task)) {
			this.audit.u_srms_ticket_number = task.u_unisys_ticket;
			this.audit.u_task = task.sys_id.getValue();
		}
		this.audit.insert();
	},

	// write a message to the SN system log
	// msg - string to write to the log
	writeLog: function(msg) {
		if (this.logging) {
			gs.info(this.LOGPFX + '(' + new GlideDateTime().getNumericValue() + ') ' + msg);
		}
	},

	// write an error message to the SN system log
	// msg - string to write to the log
	writeErrorLog: function(msg) {
		gs.error(this.LOGPFX + '(' + new GlideDateTime().getNumericValue() + ') ' + msg);
	},

    type: 'u_Unisys_Integration_Utils'
};
