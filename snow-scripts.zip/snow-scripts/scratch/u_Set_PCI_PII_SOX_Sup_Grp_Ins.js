// Business Rule: u_Set_PCI_PII_SOX_Sup_Grp_Ins
// Table: u_applications
// When: After
// Filter: Support Group is not empty and
//         PCI is true or
//         PII is true or
//         SOC1 Nordstrom is true or
//         SOC1 Bank  is true or
//         SOX  is true

(function executeRule(current, previous /*null when async*/) {
	gs.addInfoMessage('u_Set_PCI_PII_SOX_Sup_Grp_Ins fired on ' + current.u_long_name);
	var utils = new u_PciPiiSoxSupGrpUtils();
	gs.addInfoMessage('add role nord_pci_pii_sox_support_group to ' + current.support_group.name);
	utils.addRoleToGrp(current.support_group);
})(current, previous);
