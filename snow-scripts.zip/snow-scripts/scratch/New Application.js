// get an available HLQ
var gr = new  GlideRecord('u_hlq');
gr.addQuery('u_assigned',false);
gr.addEncodedQuery('u_assigned=false^u_application_portfolioISEMPTY');
gr.setLimit(1);
gr.query();
if (gr.next()) {
    workflow.scratchpad.new_hlq = gr.getValue('u_hlq');

    // insert new application record
    var grapp = new GlideRecord('u_applications');
    grapp.newRecor();
    grapp.u_long_name = current.variables.v_application_name;
    grapp.name = current.variables.v_application_short_name;
    grapp.u_abacus_short_name = current.variables.v_application_short_name;
    grapp.support_group = current.variables.v_supporting_group_name;
    grapp.owned_by = current.variables.v_business_owner;
    grapp.u_application_type = current.variables.v_type;
    grapp.used_for = current.variables.v_status;
    grapp.vendor = current.variables.v_vendor_name;
    grapp.short_description = current.variables.v_application_description;
    grapp.service_classification = 'Application Service';
    grapp.u_hlq = gr.getValue('u_hlq');

    // set pci, pii checks
    var secreq = current.variables.v_security_requirements.toString();
    var secreqlist = secreq.split(',');
    for (i = 0; i < secreqlist.length; i++) {
        if (secreqlist[i] == "44371842db4abe44cdf5f8fdae961942") {   // pci?
            grapp.u_pci = true;
        }
        if (secreqlist[i] == "e9b75446db4abe44cdf5f8fdae96194e") {   // pii?
            grapp.u_pii = true;
        }
    }
    var app_sysid = grapp.insert();

    gr.u_application_portfolio = app_sysid;
    gr.u_assigned = true;
    gr.update();
} else {
    workflow.scratchpad.new_hlq = null;
}
