(function executeRule(current, previous /*null when async*/) {
	var ciUtils = new u_CiOwnerUtils();
    var loc = ciUtils.getLocation(current.name);	// get loc based on dev name
	if (gs.nil(loc)) {
        loc = ciUtils.getLocationFromSw(current.name);  // get loc based on connected sw
    }
    if (!gs.nil(loc)) {    // pdate if we got a loc
		current.location = loc;
        current.update();
    }
})(current, previous);
