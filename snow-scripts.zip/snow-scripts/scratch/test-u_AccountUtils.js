(function(){
    var gr = new GlideRecord('sc_req_item');
    if (gr.get('a3ac5de8dbf50744cdf5f8fdae9619da')) {
        gs.print('RITM group from form: ' + gr.variables.v_group + '(' + gr.variables.v_group.name+ ')')
        gs.print('REQ: ' + gr.request + '(' + gr.request.number + ')')
    }
    var utils = new u_AccountUtils(gr);
    var acct_info = utils.createSvcAccts();
    for(var key in acct_info) {
        gs.print('\n' + key + ': ' + acct_info[key]);
    }

    gr = new GlideRecord('sys_user');
    if (gr.get(acct_info.dev_sysid)) {
        gs.print('Service account ' + acct_info.dev_user_id + ' created');
    } else {
        gs.print('Service account ' + acct_info.dev_user_id + ' not created');
    }
    gr.initialize();
    if (gr.get(acct_info.prod_sysid)) {
        gs.print('Service account ' + acct_info.prod_user_id + ' created');
    } else {
        gs.print('Service account ' + acct_info.prod_user_id + ' not created');
    }
}())
