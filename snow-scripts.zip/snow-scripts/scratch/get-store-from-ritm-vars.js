(function(){
    function getRitmVars(task) {
        //this.writeLog('In getRitmVars for ' + task.number);
        gs.print('In getRitmVars for ' + task.number);
        var vars = [];
        var set = new GlideappVariablePoolQuestionSet();
        set.setRequestID(task.request_item);
        set.load();
        var vs = set.getFlatQuestions();
        for (var i = 0; i < vs.size(); i++) {
            if(vs.get(i).getLabel() != '') {
                vars.push({label: vs.get(i).getLabel(),
                            name: vs.get(i).getName(),
                            value: vs.get(i).getDisplayValue(),
                            type: vs.get(i).getType()});
            }
        }
        if (!gs.nil(vars)) {
            return vars;
        } else {
            return '';
        }
    }

    function formatRitmVars(vars) {
        //this.writeLog('In formatRitmVars for ' + task.number);
        gs.print('In formatRitmVars, vars size is ' + vars.length);
        var varstring = '';
        for (var i = 0; i < vars.length; i++) {
            if (vars[i].label.endsWith(':')) {
                varstring += '\n' + vars[i].label.slice(0, -1) + ': ' + vars[i].value;
            } else {
                varstring += '\n' + vars[i].label + ': ' + vars[i].value;
            }
        }
        if (!gs.nil(varstring)) {
            return 'Request item variables:\n' + varstring;
        } else {
            return varstring;
        }
    }

    function findStoreFromVars(vars) {
        //this.writeLog('In findStoreFromVars');
        gs.print('In findStoreFromVars, vars size is ' + vars.length);
        var query = 'reference=cmn_location^name=';
        var gr = new GlideRecord('item_option_new');
        var store = new GlideRecord('cmn_location');
        for (var i = 0; i < vars.length; i++) {
            if (vars[i].type == 6 || vars[i].type == 8) {
                //gs.print('check ' + vars[i].name);
                gr.initialize();
                gr.addEncodedQuery(query + vars[i].name);
                gr.query()
                if (gr.next()){
                    gs.print(vars[i].name + ' reference cmn_location');
                    store.initialize();
                    store.addQuery('name', vars[i].value);
                    store.query();
                    if (store.next()) {
                        gs.print(vars[i].value + ' is store ' + store.u_store_number);
                        return store.u_store_number;
                    }
                }
            }
        }
        return null;
    }

    var task = new GlideRecord('sc_task');
    task.get('84b85376db32a700cdf5f8fdae961939');
    gs.print(task.number);
    var vars = getRitmVars(task);
    gs.print('vars: ' + JSON.stringify(vars));
    var vstring = formatRitmVars(vars);
    gs.print('vstring:\n' + vstring);
    var store = findStoreFromVars(vars);
    if (!gs.nil(store)) {
        gs.print('got my store');
    } else {
        gs.print('no store');
    }
}())
