(function process(/*RESTAPIRequest*/ request, /*RESTAPIResponse*/ response) {
	// the sys_id of the task to update is passed in the url and is required
	// request body:
	// {
    //    "state": 1,								 <-- optional
    //    "comments": "some comments",				 <-- optional
    //    "u_unisys_ticket": "12345",				 <-- req for bonding, opt otherwise
    //    "u_unisys_workflow": "Accept",			 <-- req for bonding, opt otherwise
    //    "close_code": "Solved (Permanently)",      <-- inc only, req when resolving or cancelling
    //    "close_notes": "blah",                     <-- inc only, req when resolving
	//    "hold_reason": 3                           <-- inc only, req when changing to on hold
	// }

	var utils = new u_Unisys_Integration_Utils(true);
	var logmsg = 'Unisys Task Update API';
	var props = null;
	var body = null;
	var updated = false;
	var result = null;
	var error = null;
	var bond = false;

    // get the task sys_id from the url
	var pathParams = request.pathParams;
	var sys_id = pathParams.id;
	logmsg += '\npath params sys_id: ' + sys_id;

	try {
		var parser = new JSONParser();
		var req = parser.parse(request.body.dataString);
		props = utils.getReqProperties(req);
		body = JSON.stringify(props);
	} catch(ex) {
		error = 'Exception occurred while parsing request body: ' + ex;
		utils.inBoundError(response, logmsg, error, 500);
		return;
	}

	// get the record to update
	var gr = utils.getTaskRecord(sys_id);
    if (gs.nil(gr)) {
		error = 'A task with sys_id ' + sys_id + ' was not found';
		utils.inBoundError(response, logmsg, error, 404);
		utils.inboundAudit(null, 'Update', body, 'Request failed: ' + error, 404);
        return;
    }

	logmsg += '\ntask type:  ' + gr.sys_class_name + '\nnumber: ' + gr.number;

	// verify correct updating of unisys srms ticket number
	if (gs.nil(gr.u_unisys_ticket)) {
		bond = true;
		if (gs.nil(props.u_unisys_ticket) || props.u_unisys_ticket == '') {
			if (props.u_unisys_workflow.toLowerCase() != 'accept' &&
				props.u_unisys_workflow.toLowerCase() != 'reject') {
					error = 'Attempting to update a task that has not been bound to SRMS';
					utils.inBoundError(response, logmsg, error, 400);
					utils.inboundAudit(gr, 'Bond', body, 'Request failed: ' + error, 400);
			        return;
			}
			if (props.u_unisys_workflow.toLowerCase() == 'reject') {
				updated = utils.updateFailedBond(gr, props);
				result = { message: gr.number + ' reassigned due to bonding failure' };
				response.setStatus(200);
				response.setBody(result);
				logmsg += '\nSRMS bonding failed for ' + gr.number;
				this.writeErrorLog(logmsg);
				utils.inboundAudit(gr, 'Bond', body, JSON.stringify(result), 200);
				return;
			}
		}
	} else if (!gs.nil(props.u_unisys_ticket)) {
		if (gr.u_unisys_ticket != props.u_unisys_ticket) {
			error = 'Attempting to change the SRMS ticket number for a task previously bound to SRMS (' + gr.u_unisys_ticket + ')';
			utils.inBoundError(response, logmsg, error, 409);
			utils.inboundAudit(gr, 'Update', body, 'Request failed: ' + error, 409);
	        return;
		}
	}

	// verify that if state was specified it is valid
	if (!gs.nil(props.state) && !utils.isValidChoice(gr.sys_class_name, 'state', props.state)) {
		error = props.state + ' is an invalid state for task type ' + gr.sys_class_name;
		utils.inBoundError(response, logmsg, error, 400);
		utils.inboundAudit(gr, 'Update', body, 'Request failed: ' + error, 400);
        return;
	}

	// verify a valid hold reason incident state on hold
	if (gr.sys_class_name == 'incident' && props.state == 3) {
		if (gs.nil(props.hold_reason)) {
			error = 'A hold reason is required when changing incident state to 3 (On Hold)';
			utils.inBoundError(response, logmsg, error, 400);
			utils.inboundAudit(gr, 'Update', body, 'Request failed: ' + error, 400);
			return;
		} else if (!utils.isValidChoice(gr.sys_class_name, 'hold_reason', props.hold_reason)) {
			error = props.hold_reason + ' is an invalid incident on hold reason';
			utils.inBoundError(response, logmsg, error, 400);
			utils.inboundAudit(gr, 'Update', body, 'Request failed: ' + error, 400);
			return;
		}
	}

	// verify required fields for incident resolve
	if (gr.sys_class_name == 'incident' && props.state == 6	) {
		if (gs.nil(props.close_code) || gs.nil(props.close_notes)) {
			error = 'Close notes and close code are both required to resolve an incident';
			utils.inBoundError(response, logmsg, error, 400);
			utils.inboundAudit(gr, 'Update', body, 'Request failed: ' + error, 400);
	        return;
		}
		// verify valid close code
		if (!utils.isValidChoice(gr.sys_class_name, 'close_code', props.close_code)) {
			error = props.close_code + ' is an invalid incident resolution close code';
			utils.inBoundError(response, logmsg, error, 400);
			utils.inboundAudit(gr, 'Update', body, 'Request failed: ' + error, 400);
	        return;
		}
	}

	// verify there there are close notes settig incident state to cancelled
	if (gr.sys_class_name == 'incident' && props.state == 8 && gs.nil(props.close_code)) {
		error = 'Close code is required when cancelling an incident';
		utils.inBoundError(response, logmsg, error, 400);
		utils.inboundAudit(gr, 'Update', body, 'Request failed: ' + error, 400);
		return;
	}

	// prevent setting incident state to closed
	if (gr.sys_class_name == 'incident' && props.state == 7) {
		error = 'Incident state cannot be set to 7 (Closed)';
		utils.inBoundError(response, logmsg, error, 400);
		utils.inboundAudit(gr, 'Update', body, 'Request failed: ' + error, 400);
		return;
	}

	// update the task record
	if (gr.sys_class_name == 'incident' ) {
		updated = utils.updateSnIncident(gr, props);
	} else {
		updated = utils.updateSnTask(gr, props);
	}

	// do logging and auditing of the udpate
	if (updated) {
		result = { 'message': gr.number + ' successfully updated' };
		response.setStatus(200);
		response.setBody(result);
		logmsg += '\nResponse = ' + JSON.stringify(result);
		if (bond) {
			utils.inboundAudit(gr, 'Bond', body, JSON.stringify(result), 200);
		} else {
			utils.inboundAudit(gr, 'Update', body, JSON.stringify(result), 200);
		}
	} else {
		error = 'Task update failed (GlideRecord failure)';
		utils.inBoundError(response, logmsg, error, 500);
		utils.inboundAudit(gr, 'Update', body, 'Request failed: ' + error, 500);
	}

	utils.writeLog(logmsg);
})(request, response);
