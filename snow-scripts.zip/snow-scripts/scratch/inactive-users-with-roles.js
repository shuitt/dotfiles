(function(){
    gs.print('Starting script...');
    var gr = new GlideRecord('sys_user_has_role');
    gr.addQuery('user.active', false);
    gr.query();
    while (gr.next()) {
        gs.print(gr.user.name + '\t' + gr.role.name);
    }
    gs.print('Script done');
}())
