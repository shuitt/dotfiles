var u_Validate_Caller = Class.create();
u_Validate_Caller.prototype = Object.extendsObject(AbstractAjaxProcessor, {
	doValidation: function() {
		// validate a caller's identity using the HRWS101 Validate Identity web service
		empNbr = this.getParameter('sysparm_empNbr');
		last4 = this.getParameter('sysparm_last4');
		gs.log('u_Validate_Caller: employee number = ' + empNbr);

        var restMessage = new sn_ws.RESTMessageV2('HRWS101 Validate Identity', 'post');
        restMessage.setStringParameter('employee_number', empNbr);
        restMessage.setStringParameter('last_four', last4);
		var response = null;

        try {
            response = restMessage.execute();
        } catch(ex) {
            gs.log('exception: ' + ex.getMessage());
        }

		var result = {};
        var httpStatus = response.getStatusCode();
        gs.log('u_Validate_Caller: response code = ' + httpStatus);

		if (httpStatus == 200 ) {
			var body = JSON.parse(response.getBody());
			result.code = body.OutputParameters.OUT_VALIDATION_CODE;
			result.msg = body.OutputParameters.OUT_VALIDATION_MESSAGE;
		} else {
			result.code = "ERROR";
			result.msg = "Unable to validate caller due to valdation service error";
		}

		var data = JSON.stringify(result);    //JSON formatted string
        gs.log('u_Validate_Caller: response: ' + data);
		return data;
	},

    type: 'u_Validate_Caller'
});
