(function () {
    var gr = new GlideRecord('sys_user_group');
    gr.addEncodedQuery('emailISNOTEMPTY');
    gr.query();
    gs.print('Groups with an email address: ' + gr.getRowCount());
    while (gr.next()) {
        gr.u_distribution_list = gr.email;
        gr.update();
    }
})();
