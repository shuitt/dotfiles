/**
    N.B. As of Istanbul release CTI implementations must conform to the following rules for security reasons.

    Existing CTI implementations must be made to conform and tested in a sub-prod instance before upgrading the
    production instance to Istanbul, or the CTI implementation will malfunction in production.

    1) any function invoked via sysparm_cti_rule must be defined in a sys_script entry which is marked client callable,
       or the function will not be found. CTIProcessor (cti.do) now looks only in rhino.sandbox scope for such functions.
       Accordingly, this sample sys_script entry is now marked client callable.

    2) any client-callable function invoked via sysparm_cti_rule which needs to insert, update, or delete any GlideRecord(s)
       must delegate to (i.e. call) a separate NON-client callable function to do the update(s), or the attempted update(s)
       will fail with a log warning of the form:

       *** WARNING *** Security restricted: User tried to run update(String reason) in GlideRecordSandbox

       The sample code below which does a GlideRecord update is commented out (as has always been the case)
       but if one were to un-comment it, it would fail at the line "task.update()".  To make it work,
       that section of code would need to be moved into a new function in a new sys_script entry which is NOT client callable.
       Any values obtained via the various sysparm_ variables needed by that code would have to be passed as arguments to
       the new function.

    3) any CTI function which sets a value in the global variable called 'answer' for the CTIProcessor to use as the redirect URL
       must now set the variable 'answer' in the rhino.sandbox scope rather than rhino.global scope. In other words, the script
       which executes the line of code 'answer = .....' must be a client-callable script.
 **/
  /*----------------------- start of original servicenow script -------------------------
 function cti() {
  var url = null;
  var name = sysparm_caller_name;
  eid = sysparm_caller_id;
  var phone = sysparm_caller_phone;
  var taskID = sysparm_task_id;
  var fQuery = sysparm_query;
  if (fQuery == null)
     fQuery = '';
  var view = sysparm_view;

  if (view == null || view == '')
      view = "itil";

  var userID = null;
  if (eid != null && eid != '') {
      userID = UserGetSysId("employee_number",eid);
  }
  if (userID == null && name != null && name != '') {
      userID = UserGetSysId("name", name);
  }
  if (userID == null && phone != null && phone != '') {
      userID = UserGetSysId("phone", phone);
  }
  if (userID != null) {
      var gr = new GlideRecord("incident");
      gr.addQuery("active", "true");
      gr.addQuery("caller_id", userID);
      gr.setWorkflow(false);
      gr.query();
      if (gr.next())
         url = "sys_user.do?sys_id=" + userID + "&sysparm_view=" + view;
      } else {
          if (taskID != null && taskID != '') {
             //var task = new GlideRecord('incident');
             //task.addQuery('number', taskID);
             //task.query();
             //if (task.next()) {
                 //if (typeof(sysparm_work_notes) != 'undefined')
                 //    task.work_notes.setJournalEntry(sysparm_work_notes);
                 //if (typeof(sysparm_priority) != 'undefined')
                 //    task.priority = sysparm_priority;
                 //task.update();
             //}
          url = "task.do?sys_id=" + taskID + "&sysparm_view=" + view;
          }
      }
      if (userID != null) {
          if (fQuery.length > 0)
              fQuery += "^";
          fQuery += "caller_id=" + userID;
      }
      if (url == null) {
          url = "incident.do?sys_id=-1";
          if (fQuery != null)
             url += "&sysparm_query=" + fQuery;
      }
      answer = url;
      return url;
}
------------------------- end of original servicenow script -------------------------*/

/*----------------------- start of nordstrom script updates ------------------------
this business rule is used to open a new call record (table new_call) via the avaya one-X agent when a service desk tech takes a call.
one-X agent will open a url of the form:

https://<instance>/cti.do?sysparm_caller_id=<employee number>
https://nordstromdev.service-now.com/cti.do?sysparm_caller_id=368977
*/

function cti() {
    var empNbr = sysparm_caller_id;     // employee number
    var url = 'nav_to.do?uri=new_call.do';   // this url will open a new call record

    // if we have an employee number and a matching user exists insert a call record
    if (empNbr != null && empNbr != '') {
        var user = new GlideRecord('sys_user');
        user.addQuery('employee_number', empNbr);
        user.query();
        if (user.next()) {
			// prepare script include args
			var ctiArgs = {};
			ctiArgs.cti_sys_id = user.sys_id;
			ctiArgs.cti_emp_nbr = user.employee_number;
			ctiArgs.cti_lan_id = user.u_lan_id;

			// call the script include to create a new call record
			var ctiEvaluator = new CTIEvaluator("new AvayaIntUtils().u_CTI_Create_Call()", ctiArgs);
		    var callSysId = ctiEvaluator.evaluate();
            //callSysId = '7cc9d72fdb283200cdf5f8fdae961957';
			if (callSysId != null) {
				url += '?sys_id=' + callSysId;   // set url to open the just created call record
			}
        }
    }

	answer = url;
    return url;
}
//------------------------- end of nordstrom script updates -------------------------

function UserGetSysId(field, value) {
    var user = new GlideRecord("sys_user");
    user.addQuery(field, value);
    user.query();
    if (user.next())
        return user.sys_id;
    else
        return null;
}
