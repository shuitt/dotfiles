var OracleEbsPeopleUtils = Class.create();
OracleEbsPeopleUtils.prototype = {
    initialize: function() {
		this.keepTypes = ['contractor', 'cosmetic vendor speciality', 'designer boutique',
                  'designer boutique dis', 'employee', 'nfcu', 'trunk club'];
    },

	// determine whether a given property has a volue
	hasValue: function(obj, prop) {
	    if (obj[prop].hasOwnProperty('@xsi:nil')) {
	        return false;
	    } else {
	        return true;
	    }
	},

    // see if a given user exists
    userExists: function(empNbr) {
        var gr = new GlideRecord('sys_user');
        gr.addQuery('employee_number', empNbr);
        gr.query();
        return gr.next();   // true if there's a record
    },

    // convert the ebs web service datetime string to a GlideDateTime
    makeDate: function(dateStr) {
        parts = dateStr.split(/[T.]/g);     // input fmt is 'yyyy-mm-ddThh:mm:ss.ttt-hh:00'
        dt = parts[0] + ' ' + parts[1];     // fmt is 'yyyy-mm-dd hh:mm:ss'
        return new GlideDateTime(dt);
    },

    // determine if the user update indicates the user has been terminated
    termedUser: function(user) {
        exists = this.userExists(user.EMP_CWK_NUMBER);
        if (user.PURGE_FLAG == 'Y' && exists) {
            return true;
        }
        if (user.ASSIGNMENT_STATUS == 'Terminate Assignment' && exists) {
            return true;
        }
        if (this.hasValue(user, 'TERMINATION_DATE')) {
            termDate = makeDate(user.TERMINATION_DATE);
            today = new GlideDateTime();
            if (termDate.compareTo(today) <= 0 && exists) {
                return true;
            }
        }
        return false;
    },

    // determine whether to process a user update
    processThisUser: function(user) {
        if (keepTypes.indexOf(user.USER_PERSON_TYPE.toLowerCase()) >= 0) {
            return true;
        } else {
            return false;
        }
    },

    type: 'OracleEbsPeopleUtils'
};
