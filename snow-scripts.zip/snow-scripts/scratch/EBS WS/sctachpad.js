getMidServer: function(sName, sContains) {
		var grMS = new GlideRecord('ecc_agent');
		grMS.addQuery('name', sName);
		grMS.addQuery('validated', 'true');
		grMS.addQuery('status', 'Up');
		grMS.query();
		if (grMS.next()) {
			return grMS.name;
		} else {
			grMS = new GlideRecord('ecc_agent');
			grMS.addEncodedQuery('nameLIKE' + sContains + '^statusSTARTSWITHup^validatedINtrue');
			grMS.query();
			if (grMS.next()) {
				return grMS.name;
			}
		}
	},


    getMidServer: function(contains) {
        var contains = 'integration';
        var gr = new GlideRecord('ecc_agent');
        gr.addEncodedQuery('nameENDSWITH' + contains + '^statusSTARTSWITHup^validatedINtrue');
        gr.orderBy('last_refreshed')
        gr.query();
        if (gr.next()) {
            return gr.name;
        } else {
            return null;
        }
    },

        restMessage.setMIDServer("mid_server_name");
