(function(){
    var utils = new OracleEbsIntegrationUtils('HRWS102 Contracting Agencies List: ');
    var webService = 'HRWS102 Contracting Agencies';   // name of the outbound REST message
    var post = 'post';                           // http method - case sensitive!

    response = utils.sendMsg(webService, post);
    var httpStatus = response.getStatusCode();
    utils.log('response code = ' + response.getStatusCode());
    var parsed = JSON.parse(response.getBody());      // convert JSON response to javascript object

    agencies = utils.getList(parsed, 'OUT_VENDORS', 'OUT_VENDORS_ITEM');
    recCount = agencies.length;
    utils.log('number of records = ' + recCount);

    // skip if the location list is empty
    if (recCount > 0) {
        //Create a new import set
        var impTable = 'u_hrws102_contracting_agencies';      //import set table name
        impSet = utils.getImpSet(impTable);
        var restGR = new GlideRecord(impTable);         //import set table
        utils.log('process agencies');

        //process response
        for (var i = 0; i < recCount; i++) {
            restGR.newRecord();
            restGR.u_vendor_id = agencies[i].AP_VENDOR_ID;
            restGR.u_vendor_number = agencies[i].AP_VENDOR_NUMBER;
            restGR.u_name = agencies[i].AP_VENDOR_NAME;
            restGR.u_vendor = true;
            restGR.insert();
        }
        // data is all loaded so run the transformation
        utils.log('data loaded');
        impSet.state = 'loaded';
        var mapName = 'HRWS102 Contracting Agencies';
        utils.doTransform(impSet, mapName);
        utils.log('all done');
    }
}())
