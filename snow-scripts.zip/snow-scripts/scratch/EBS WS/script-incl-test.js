(function(){
    var ciUtils = new u_CiOwnerUtils();
	var nsgGroupId = 'fbe773f6db5d7200cdf5f8fdae9619b5';
	var st1Id = 'a819a94ddb672200cdf5f8fdae9619de';
	var st319Id = '7019e94ddb672200cdf5f8fdae961919';
	var nwLocalReg = '18f7b3f6db5d7200cdf5f8fdae9619f5';
	var dev1 = 'cs001-1b';
	var dev999 = 'cs999-1b';
	var devxxx = 'csxxx-1b';
	var id = null;

	gs.print('Test getting a location sys_id');
	// valid loc gets a sys_id
	id = ciUtils.getLocId('1');
	gs.print('Store 1 id: ' + id + ', should be: ' + st1Id);
	id = ciUtils.getLocId('999');
	gs.print('Store 999 id: ' + id + ', should be: null');

	gs.print('Test getting location from device name');
    id = ciUtils.getLocation(dev1);
	gs.print('Device ' + dev1 + ' id: ' + id + ', should be: ' + st1Id);
    id = ciUtils.getLocation(dev999);
	gs.print('Device ' + dev999 + ' id: ' + id + ', should be: null');
    id = ciUtils.getLocation(devxxx);
	gs.print('Device ' + devxxx + ' id: ' + id + ', should be: null');

	gs.print('Test getting NSG group');
	id = ciUtils.getNsgGroup();
	gs.print('ID: ' + id + ', should be: ' + nsgGroupId);

    gs.print('Test getting support group');
	id = ciUtils.getOwningGroup(st1Id);
	gs.print('St 1 Group ID: ' + id + ', should be: ' + nwLocalReg);
	id = ciUtils.getOwningGroup(st319Id);
	gs.print('St 319 Group ID: ' + id + ', should be: ' + nsgGroupId);
	id = ciUtils.getOwningGroup('a819a11166672200cd0008fdae9619de');
    gs.print('St nonsense Group ID: ' + id + ', should be: null');
}())
