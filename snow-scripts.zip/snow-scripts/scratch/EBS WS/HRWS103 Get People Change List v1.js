(function(){
    var utils = new OracleEbsIntegrationUtils('HRWS103 People Change List: ');
    var peopleUtils = new OracleEbsPeopleUtils();
    var webService = 'HRWS103 People Change List';   // name of the outbound REST message
    var post = 'post';

    // get the last run date/time
    var lastRun = utils.getLastUpdate(webService);
	utils.log('last rune date was ' + lastRun);
    if (lastRun === null) {
        utils.log('unable to find last run date/time in control table');
        return;
    }

    var more = true;
    var needImpSet = true;
    var doTransform = false;
    var restGR = null;
    var impSet = null;

    while (more) {
        utils.log('getting updates since ' + lastRun);
        response = utils.sendMsgWithDate(webService, post, lastRun);
		var httpStatus = response.getStatusCode();
		utils.log('response code = ' + response.getStatusCode());
        var parsed = JSON.parse(response.getBody());      // convert JSON response to javascript object

        // get last run date, record count and check whether there are more records to get
        lastRun = parsed['OutputParameters']['OUT_CONTROL_RECORD'].LAST_EFFECTIVE_DATE_TIME;
		utils.log('LAST_EFFECTIVE_DATE_TIME = ' + lastRun);
		recCount = parsed['OutputParameters']['OUT_CONTROL_RECORD'].RECORD_COUNT;
		utils.log('RECORD_COUNT = ' + parsed['OutputParameters']['OUT_CONTROL_RECORD'].RECORD_COUNT);

        if (parsed['OutputParameters']['OUT_CONTROL_RECORD'].MORE_DATA_FLAG == 'N') {
            more = false;
            utils.log('got all records');
        } else {
            utils.log('more records to get');
        }

        if (parsed['OutputParameters']['OUT_CONTROL_RECORD'].RECORD_COUNT > 0)
            {
            updates = utils.getList(parsed, 'OUT_HR_PEOPLE', 'OUT_HR_PEOPLE_ITEM');
            utils.log('number of records in list = ' + recCount);

            // skip if the people list is empty
            if (recCount > 0) {       //import set table
                doTransform = true;
                utils.log('process users');
                if (needImpSet) {
                    //Create a new import set
                    var impTable = 'u_hrws103_people_changes';      //import set table name
                    impSet = utils.getImpSet(impTable);
                    restGR = new GlideRecord(impTable);
                    needImpSet = false;
                }

                //process response
                for (var i = 0; i < recCount; i++) {
                    if (peopleUtils.termedUser(updates[i])) {
                        restGR.newRecord();
                        restGR.u_employee_number = updates[i].EMP_CWK_NUMBER;
                        restGR.u_active = false;
                        restGR.u_user_type = updates[i].USER_PERSON_TYPE;
                        if (peopleUtils.hasValue(updates[i], 'TERMINATION_DATE')) {
                            restGR.u_termination_date = updates[i].TERMINATION_DATE;
                        }
                        restGR.insert();
                    } else if (peopleUtils.processThisUser(updates[i].USER_PERSON_TYPE)) {
                        restGR.newRecord();
                        restGR.u_active = true;
                        restGR.u_employee_number = updates[i].EMP_CWK_NUMBER;
                        restGR.u_person_id = updates[i].PERSON_ID;
                        if (peopleUtils.hasValue(updates[i], 'LAN_ID')) { restGR.u_lan_id = updates[i].LAN_ID; }
                        if (peopleUtils.hasValue(updates[i], 'FIRST_NAME')) { restGR.u_first_name = updates[i].FIRST_NAME; }
                        if (peopleUtils.hasValue(updates[i], 'MIDDLE_NAME')) { restGR.u_middle_name = updates[i].MIDDLE_NAME; }
                        if (peopleUtils.hasValue(updates[i], 'LAST_NAME')) { restGR.u_last_name = updates[i].LAST_NAME.replace(/&apos;/g, "'"); }
                        if (peopleUtils.hasValue(updates[i], 'PREFERRED_NAME')) { restGR.u_preferred_name = updates[i].PREFERRED_NAME; }
                        if (peopleUtils.hasValue(updates[i], 'USER_PERSON_TYPE')) { restGR.u_user_type = updates[i].USER_PERSON_TYPE; }
                        if (peopleUtils.hasValue(updates[i], 'HIRE_DATE')) { restGR.u_hire_date = updates[i].HIRE_DATE; }
                        if (peopleUtils.hasValue(updates[i], 'TERMINATION_DATE')) { restGR.u_termination_date = updates[i].TERMINATION_DATE; }
                        if (peopleUtils.hasValue(updates[i], 'CWK_PROJECTED_END_DATE')) { restGR.u_projected_assignment_end_date = updates[i].CWK_PROJECTED_END_DATE; }
                        if (peopleUtils.hasValue(updates[i], 'CORPORATE_EMAIL')) { restGR.u_email = updates[i].CORPORATE_EMAIL.replace(/&apos;/g, "'"); }
                        if (peopleUtils.hasValue(updates[i], 'CORPORATE_EMAIL')) { restGR.u_user_id = updates[i].CORPORATE_EMAIL.replace(/&apos;/g, "'"); }
                        if (peopleUtils.hasValue(updates[i], 'WORK_PHONE')) { restGR.u_business_phone = updates[i].WORK_PHONE; }
                        if (peopleUtils.hasValue(updates[i], 'WORK_TIE_LINE')) { restGR.u_business_tie_line = updates[i].WORK_TIE_LINE; }
                        if (peopleUtils.hasValue(updates[i], 'CWK_VENDOR_ID')) { restGR.u_company = updates[i].CWK_VENDOR_ID; }
                        if (peopleUtils.hasValue(updates[i], 'MGR_EMP_NUMBER')) { restGR.u_manager = updates[i].MGR_EMP_NUMBER; }
                        if (peopleUtils.hasValue(updates[i], 'ORGANIZATION_ID')) { restGR.u_department = updates[i].ORGANIZATION_ID; }
                        if (peopleUtils.hasValue(updates[i], 'LOCATION_ID')) { restGR.u_location = updates[i].LOCATION_ID; }
                        if (peopleUtils.hasValue(updates[i], 'JOB_ID')) { restGR.u_job = updates[i].JOB_ID; }
                        if (peopleUtils.hasValue(updates[i], 'ONSITE_FLAG')) {
                            if (updates[i].ONSITE_FLAG == 'Y') {
                                restGR.u_onsite_contractor = 'Yes';
                            } else {
                                restGR.u_onsite_contractor = 'No';
                            }
						}
                        restGR.insert();
                    }
                }
            }
        }
    }
    utils.log('update last run date to ' + lastRun);
    utils.setLastUpdate(webService, lastRun);

    // data is all loaded so run the transformation
    if (doTransform) {
        utils.log('data loaded');
        impSet.state = 'loaded';
        var mapName = 'HRWS103 People Changes';
        utils.doTransform(impSet, mapName);
    }
    utils.log('all done');
}())
