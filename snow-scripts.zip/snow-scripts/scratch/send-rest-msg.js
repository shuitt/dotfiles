(function(){
    var msg = new sn_ws.RESTMessageV2();
    msg.setEndpoint('https://esbuatt1wm.ito.unisys.com:7500/rest/Tiel1ICLStd_JSON_New.Inbound.UnisysMBICL');
    msg.setHttpMethod('post');
    msg.setRequestHeader('Accept','Application/json');
    msg.setRequestHeader('Content-Type','Application/json');
    msg.setRequestBody('{}');
    msg.setBasicAuth('http_NordStorm', 'Unisys123*');
    var response = msg.execute();
    gs.print('Status: ' + response.getStatusCode() + ', body: ' + response.getBody());
}())
