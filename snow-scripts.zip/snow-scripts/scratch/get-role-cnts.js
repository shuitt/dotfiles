(function () {
    var count = 0;
    var agg = new GlideAggregate('sys_user_has_role');
    agg.addEncodedQuery('role=282bf1fac6112285017366cb5f867469^user.web_service_access_only=false');
    agg.addAggregate('COUNT');
    agg.query();
    if (agg.next()) {
        gs.print('getting itil role users...');
        count = agg.getAggregate('COUNT');
    }
    gs.print('Number of users with itil role: ' + count);

    count = 0;
    agg = new GlideAggregate('sys_user_has_role');
    agg.addEncodedQuery('role=282bf1fac6112285017366cb5f867469^user.last_login>javascript:gs.daysAgoStart(30)^user.web_service_access_only=false');
    agg.addAggregate('COUNT');
    agg.query();
    if (agg.next()) {
        gs.print('getting aggregate...');
        count = agg.getAggregate('COUNT');
    }
    gs.print('Number of users with itil role that have not logged in for 30 days or more: ' + count);

    var trend = new GlideAggregate('sys_user');
    trend.addTrend ('last_login','Month');
    trend.addAggregate('COUNT');
    trend.setGroup(false);
    trend.query();
    while(trend.next()) {
        gs.print(trend.getValue('timeref') + ': ' + trend.getAggregate('COUNT'));
    }
})();
