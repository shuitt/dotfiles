// impersonation, option 1

var userSysId = "e482b4d9dbe5fe048b475434ce9619f0"; // sys_id of a sys_user record
var myId = gs.getSession().impersonate(userSysId);
gs.print("Running as " + gs.getUserName() + "...");

gs.getSession().impersonate(myId);
gs.print("...running as " + gs.getUserName());

// impersonation, option 2

var userSysId = "e482b4d9dbe5fe048b475434ce9619f0";
var impUser = new GlideImpersonate();
var myId = impUser.impersonate(userSysId);
gs.print("Running as " + gs.getUserName() + "...");

impUser.impersonate(myId);
gs.print("...running as " + gs.getUserName());
