# This script will contain and/or uncontain a machine in FireEye HX
# This script will also check the status of containment for a host in FireEye HX

import requests, json, sys
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

feurl = "https://fe0319p01.nordstrom.net:3000/hx/api/v3/hosts/" # This line is part of the URL that we will use for checking the status of containment, request containment, approve containment, and uncontain
fe_headers = {"Content-Type": "application/json", "Accept": "application/json", "X-FeApi-Token": "API TOKEN GOES HERE"}  # This variable defines the headers that will be used for all containment related calls

def contain_machine(agent_id): # This line just defines the function that will contain a machine in FireEye. The function takes the agent id as input
    contain_request = requests.post(feurl + agent_id + "/containment/", headers=fe_headers, verify=False) # This line makes the request to contain a host in FireEye HX
    if contain_request.status_code == 202: # This line checks to see if the request to contain a host was acutally accepted
        contain_body = {"state": "contain"} # This line defines the body of the request that will be passed for approval for containment request
        contain_request = requests.patch(feurl + agent_id + "/containment/", headers=fe_headers, verify=False)  # This line will actually approve the containment in FireEye HX
        if contain_request.status_code == 201:  # This line checks the status code of the request to see if the approval for contianment was successful
            print "Containment was successful"

def check_status_of_containment(agent_id): # This line defines the function for checking the state of containment for a host. This function takes the agent id as input
    check_containment_status = requests.get(feurl + agent_id, headers=fe_headers, verify=False) # This line makes the call to check on the status of containment for a machine
    if check_containment_status.json()["containment_state"] == "normal": # This line just checks to see if the host is not contained
        print "The Host is NOT Contained"
    elif check_containment_status.json()["containment_state"] == "containing": # This line checks to see if the host is currently in the process of being contained
        print "The Host is currently in the process of being contained"
    elif check_containment_status.json()["containment_state"] == "contained": # This line checks to see if the host has been contained
        print "The Host has been contained"
    elif check_containment_status.json()["containment_state"] == "uncontaining": # This line checks to see if the host is currently in the process of being uncontained
        print "The Host is in the process of currently being uncontained"

def uncontain_machine(agent_id): # This line just defines the function for unconatining a machine in FireEye HX
    uncontainment_request = requests.delete(feurl + agent_id + "/containment/", headers=fe_headers, verify=False) # This line makes the REST call to uncontain a machine in FireEye HX
    if uncontainment_request.status_code == 204: # This line checks to see if the containment was successful
        print "The host is being released from containment"
