(function(){
    var utils = new u_nord_PagerDuty_provisioning();
    //var result = utils.addAccess('steve2 Huitt', 'xsmh@nordstrom.com');
    var result = utils.removeAccess('P2SB6GK');
    //var result = utils.getSchedule('PJTU43M');
    //var result = utils.getEscalationPolicy('PYCDPOG');
    for (var key in result) {
        if (typeof(result[key]) == 'object') {
            gs.print('result.' + key + ' = ' + JSON.stringify(result[key]));
        } else {
            gs.print('result.' + key + ' = ' + result[key]);
        }
    }

    if (result.conflicts) {
        for (var i = 0; i < result.body.error.conflicts.length; i++) {
            gs.print('conflict type: ' + result.body.error.conflicts[i].type + ', conflict id: ' + result.body.error.conflicts[i].id);
            switch (result.body.error.conflicts[i].type) {
                case 'incident':
                    gs.print('resolve incident id ' + result.body.error.conflicts[i].id);
                    break;
                case 'escalation_policy':
                    gs.print('update escalation policy id ' + result.body.error.conflicts[i].id);
                    break;
                case 'schedule':
                    gs.print('update schedule id ' + result.body.error.conflicts[i].id);
                    break;
            }
        }
    }
}())
