// sys_audit_role table:
// rule: u_Role_Add_Rem
// when: after
// filter: role is admin, sn_si.admin or security_admin

(function executeRule(current, previous /*null when async*/) {
	gs.addInfoMessage('Enter business rule u_Role_Add_Rem');
    var gr = new GlideRecord('u_sir_account_events');
    gr.newRecord();
    gr.u_date = current.sys_created_on;
    gr.u_action = current.operation;
    gr.u_user = current.changed_by;
    gr.u_affected_user = current.user;
    gr.u_role = current.role;
    var session = gs.getSession();
    gr.u_user_ip_address = session.getClientIP();
	gs.addInfoMessage('IP address is ' + session.getClientIP());
    gr.insert();
	gs.addInfoMessage('Exit business rule u_Role_Add_Rem');
})(current, previous);


// sysevent table:
//
// register events: security.elevated_role.enabled and security.elevated_role.disabled

// script action: User elevated to security_admin
// event: security.elevated_role.enabled

gs.log('In the script action');
var gr = new GlideRecord('u_sir_account_events');
gs.log('parm1 = ' + event.parm1);
gs.log('parm2 = ' + event.parm2);
gr.newRecord();
gr.u_date = event.sys_created_on;
gr.u_action = event.name;
gr.u_user = event.user_id;
gr.u_affected_user = event.user_id;
// parm2 is the name of the role, need to get sys_id
var grRole = new GlideRecord('sys_user_role');
grRole.addQuery('name', event.parm2);
grRole.query();
if (grRole.next()) {
	gr.u_role = grRole.getUniqueValue();
	gs.log('role = ' + grRole.getUniqueValue());
}
var session = gs.getSession();
gr.u_user_ip_address = session.getClientIP();
gr.insert();
gs.log('Leaving the script action');


// script action: User lowered from security_admin
// event: security.elevated_role.disabled

gs.log('SH: In the script action');
var gr = new GlideRecord('u_sir_account_events');
gs.log('SH: parm1 = ' + event.parm1);
gs.log('SH: parm2 = ' + event.parm2);
gr.newRecord();
gr.u_date = event.sys_created_on;
gr.u_action = event.name;
gr.u_user = event.user_id;
gr.u_affected_user = event.user_id;
// parm2 is the name of the role, need to get sys_id
var grRole = new GlideRecord('sys_user_role');
grRole.addQuery('name', event.parm2);
grRole.query();
if (grRole.next()) {
	gr.u_role = grRole.getUniqueValue();
	gs.log('SH: role = ' + grRole.getUniqueValue());
}
var session = gs.getSession();
gr.u_user_ip_address = session.getClientIP();
gr.insert();
gs.log('SH: Leaving the script action');
