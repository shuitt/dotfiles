(function () {
    var utils = new u_Nord_User_Utils();
    var users = [
                '1bca7415dba9fe048b475434ce961943',   // steve
                '90dfb4d5dbe9fe048b475434ce961914',   // rj
                '8292741ddbe5fe048b475434ce961967',   // cho
                '5e74f0d1db29fe048b475434ce961946',   // mike s
                'c0643891db29fe048b475434ce96199c'    // travis
    ]

    var gr = new GlideRecord('sys_user');
    for (var i = 0; i < users.length; i++) {
        //gr.initialize();
        //gr.get(user);
        gs.print(users[i]);


    }
})();
