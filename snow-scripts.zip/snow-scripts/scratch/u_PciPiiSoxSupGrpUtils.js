var u_PciPiiSoxSupGrpUtils = Class.create();

// this script include is used by various scripts that pull information from ebs
u_PciPiiSoxSupGrpUtils.prototype = {
	initialize: function(source) {
        this.role = 'nord_pci_pii_sox_support_group';
        this.query_str = 'u_pci=true^ORu_pii=true^ORu_soc1=true^ORu_soc1_bank=true^ORu_sox=true';
		this.grp_role_tbl = 'sys_group_has_role';
        this.app_tbl = 'u_applications';
        this.role_id = this.getRoleId(this.role);
        //gs.addInfoMessage(this.role + ' sys_id is ' + this.role_id);
	},

    // get the sys_id for the given group name
    getRoleId: function(role) {
        var gr = new GlideRecord('sys_user_role');
        gr.addQuery('name', role);
        gr.query();
        if (gr.next()) {
            return gr.getUniqueValue();
        } else {
            return null;
        }
    },

    // check if the given role is assigned to the given group
    grpHasRole: function(grp) {
        var gr = new GlideRecord(this.grp_role_tbl);
        gr.addQuery('role', this.role);
        gr.addQuery('group', grp);
        gr.query();
        return gr.hasNext();
    },

    // add the given role to the given group
    addRoleToGrp: function(grp) {
        var gr = new GlideRecord(this.grp_role_tbl);
        gr.addQuery('role', this.role_id);
        gr.addQuery('group', grp);
        gr.query();
        if (!gr.next()) {
            gr.initialize();
            gr.role = this.role_id;
            gr.group = grp;
            var id = gr.insert();
            if (id != null) {
                gs.addInfoMessage('added role ' + this.role + ' to group ' + grp.name);
            } else {
                gs.addInfoMessage('failed to add role ' + this.role + ' to group ' + grp.name);
            }
        } else {
            gs.addInfoMessage('group ' + grp.name + ' already has role ' + this.role);
        }
    },

    // remove the given role from the given group
    remRoleFromGrp: function(grp) {
        var gr = new GlideRecord(this.grp_role_tbl);
        gr.addQuery('role', this.role_id);
        gr.addQuery('group', grp);
        gr.query();
        if (gr.next()) {
            gr.deleteRecord();
            gs.addInfoMessage('removed role ' + this.role + ' from group ' + grp.name);
        } else {
            gs.addInfoMessage('group ' + grp.name + ' does not have role ' + this.role);
        }
    },

    // check if the given group has any pci/pii/sox apps
    grpHasApps: function(grp) {
        var gr = new GlideRecord('u_applications');
        gr.addQuery('support_group', grp);
        gr.addEncodedQuery(this.query_str);
        gr.query();
        return gr.hasNext();
    },

    type: 'u_PciPiiSoxSupGrpUtils'
}
