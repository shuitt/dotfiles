function validateCaller() {
	//Get the values to pass into the dialog
	//var employee_number = g_form.getValue("employee_number");
	var employee_number = g_form.getReference('caller').employee_number;
	//alert('Employee number: ' + employee_number);

	//Initialize and open the Dialog Window
	var dialog = new GlideDialogWindow("validate_caller_dialog"); //Render the dialog containing the UI Page 'validate_caller_dialog'
	dialog.setTitle("Validate Caller Identity"); //Set the dialog title
	dialog.removeCloseDecoration();   // remove 'X' from upper right
	dialog.setPreference("employee_number", employee_number); //Pass in employee number for use in the dialog
	dialog.render(); //Open the dialog
}
