(function(){
    // create group member records from temp tale

    function inGroup(grpID, user) {
        var gr = new GlideRecord ('sys_user_grmember');
        gr.addQuery('group', grpID);
        gr.addQuery('user', user);
        gr.query();
        if (gr.next()) {
            return true;
        } else {
            return false;
        }
    }

    var grUser = new GlideRecord('sys_user');
    var grGrp  = new GlideRecord('sys_user_group');
    var grMbrs = new GlideRecord('sys_user_grmember');
    var grTmp  = new GlideRecord('u_group_member_load');

    grTmp.query();
    while (grTmp.next()) {
        grUser.initialize();
        grUser.addQuery('employee_number', grTmp.u_employee_number);
        grUser.query();
        if (grUser.next()) {
            //gs.print('Found user ' + grTmp.u_user_name + ', emp nbr ' + grTmp.u_employee_number);
            grGrp.initialize();
            grGrp.addQuery('name', grTmp.u_group);
            grGrp.query();
            if (grGrp.next()) {
                //gs.print('Found group ' + grTmp.u_group);
                if (!inGroup(grGrp.getUniqueValue(), grUser.getUniqueValue())) {
                    //gs.print('Create new group membership');
                    grMbrs.initialize();
                    grMbrs.group = grGrp.getUniqueValue();
                    grMbrs.user = grUser.getUniqueValue();
                    grMbrs.insert();
                } else {
                    //gs.print('group membership already exists');
                }
            } else {
                gs.print('Did not find group ' + grTmp.u_group);
            }
        } else {
            gs.print('Group ' + grTmp.u_group + ', did not find user ' + grTmp.u_user_name + ', emp nbr ' + grTmp.u_employee_number);
        }
    }
}())
