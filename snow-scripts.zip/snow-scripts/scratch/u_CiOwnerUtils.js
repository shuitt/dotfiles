var u_CiOwnerUtils = Class.create();
u_CiOwnerUtils.prototype = {
	initialize: function() {
		this.locPat = /^\D*(\d+)\D*/i;		// get possible loc number from dev name
		this.rmZeroPat = /^0+/;				// remove leading zeros
	},

	// determine location based on device name
	getLocation: function(devName) {
		var store_sys_id = null;
		loc = devName.match(this.locPat);
		if (loc != null) {
			store = loc[1].replace(this.rmZeroPat, '');
			store_sys_id = this.getLocId(store);
		}
		return store_sys_id;
	},

	// get the sys_id for a location table record
	getLocId: function(store) {
		var gr = new GlideRecord('cmn_location');
		gr.addQuery('u_store_number', store);
		gr.query();
		if (gr.next()) {
			return gr.sys_id;
		} else {
			return null;
		}
	},

	// get a support group sys_id for a location from the assignment routing table
	getOwningGroup: function(loc) {
		var nsgLocs = ['319', '805', '865', '865'];
		gr = new GlideRecord('u_assignment_routing_details');
		gr.addQuery('u_location', loc);
		gr.addNotNullQuery('u_assignment_routing');
		gr.query();
		if (gr.next()) {
			gs.info('CiOwner: store is ' + gr.u_location.u_store_number);
			if (gr.u_location.u_store_number == '319' ||
				gr.u_location.u_store_number == '805' ||
				gr.u_location.u_store_number == '864' ||
				gr.u_location.u_store_number == '865') { // nsg supported
					gs.info('CiOwner: nsg suported');
					return this.getNsgGroup();
			} else { // not nsg supported
				gs.info('CiOwner: not nsg suported');
				return gr.u_assignment_group.sys_id;
			}
		} else {  // unknown loc
			return null;
		}
	},

	// get the sys_id for the nsg group
	getNsgGroup: function() {
		var  gr = new GlideRecord('sys_user_group');
		gr.addQuery('name', 'Platform Engineering - Network');
		gr.query();
		if (gr.next()) {
			return gr.sys_id;
		} else {
			return null;
		}
	},

    type: 'u_CiOwnerUtils'
};
