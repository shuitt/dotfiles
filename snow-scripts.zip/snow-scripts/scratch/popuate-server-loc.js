(function executeRule() {
  	var ciUtils = new u_CiOwnerUtils();
    var gr = new GlideRecord('cmdb_ci_server');
    //gr.addEncodedQuery('location=330 Irvine Spectrum Center');
  	//gr.setLimit(7000);
  	//gr.orderBy('location');
    gr.query();
  	//gs.print('rows: ' + gr.getRowCount());
    while (gr.next()) {
        var msg = 'name: ' + gr.name;
        // get location from hosting virtualization server
        var loc = ciUtils.getLocFromVirtHost(gr.sys_id);
        msg += '\n++ getLocFromVirtHost returned ' + loc;
        // no location yet, try getting it from server name
    	if (gs.nil(loc)) {
            loc = ciUtils.getLocation(gr.name);  // get loc based on name
            msg += '\n++ getLocation returned ' + loc;
        }
        // still no location, try getting it from connected switch
    	if (gs.nil(loc)) {
            loc = ciUtils.getLocationFromSw(gr.name);  // get loc based on connected sw
            msg += '\n++ getLocationFromSw returned ' + loc;
        }
        if (!gs.nil(loc)) {    // update if we got a loc
    		gr.location = loc;
            gr.setWorkflow(false);
            gr.autoSysFields(false);
            gr.update();
            //msg += '\n++ setting loc to: ' + loc;
        }
    }
})();
