// after delete in cmdb_ci_server
// condition: u_server_tags is not empty

(function executeRule(current, previous /*null when async*/) {
	stUtils = new u_ServerTaggingUtils();
	stUtils.delTaggedServer(current.name);
})(current, previous);
