(function() {
	var logmsg = 'Review Complete: starting\nApp ID: ' + current.u_app_id;
	var app = new GlideRecord('u_application_portfolio');
	app.addQuery('u_app_id', current.u_app_id);
	app.query();
	if (app.next()) {
		logmsg += '\nUpddating App ID: ' + app.u_app_id;
		app.support_group = current.u_support_group;
		app.operational_status = current.u_operational_status;
		app.u_pci = current.u_pci;
		app.u_pii = current.u_pii;
		app.u_sox = current.u_sox;
		app.u_soc1_nordstrom = current.u_soc1_nordstrom;
		app.u_soc1_bank = current.u_soc1_bank;
		app.u_reviewed = new GlideDateTime();
		app.u_reviewed_by = gs.getUser().getID();
		app.update();
	}
	logmsg += '\nSet u_review_complete to true';
	current.u_review_complete = true;
	current.update();
	logmsg += "\nDone";
	gs.log(logmsg);
})();
