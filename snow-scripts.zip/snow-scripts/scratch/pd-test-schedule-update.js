(function(){
    //var sched = '{"schedule":{"id":"PPW7BH3","type":"schedule","summary":"Steve Test 2nd On-call","self":"https://api.pagerduty.com/schedules/PPW7BH3","html_url":"https://nordstrom.pagerduty.com/schedules/PPW7BH3","name":"Steve Test 2nd On-call","time_zone":"America/Los_Angeles","description":null,"privilege":null,"users":[{"id":"P2WR1IF","type":"user_reference","summary":"Steve2 Test Huitt","self":"https://api.pagerduty.com/users/P2WR1IF","html_url":"https://nordstrom.pagerduty.com/users/P2WR1IF"},{"id":"PTP3LA6","type":"user_reference","summary":"Steve3 Test Huitt","self":"https://api.pagerduty.com/users/PTP3LA6","html_url":"https://nordstrom.pagerduty.com/users/PTP3LA6"}],"escalation_policies":[{"id":"PYCDPOG","type":"escalation_policy_reference","summary":"Steve Test Escalation Policy","self":"https://api.pagerduty.com/escalation_policies/PYCDPOG","html_url":"https://nordstrom.pagerduty.com/escalation_policies/PYCDPOG"}],"schedule_layers":[{"name":"Layer 1","rendered_schedule_entries":[],"rendered_coverage_percentage":null,"id":"PQ970L7","start":"2017-12-12T11:16:14-08:00","end":null,"rotation_virtual_start":"2017-12-11T08:00:00-08:00","rotation_turn_length_seconds":604800,"users":[{"user":{"id":"PTP3LA6","type":"user_reference","summary":"Steve3 Test Huitt","self":"https://api.pagerduty.com/users/PTP3LA6","html_url":"https://nordstrom.pagerduty.com/users/PTP3LA6"}},{"user":{"id":"P2WR1IF","type":"user_reference","summary":"Steve2 Test Huitt","self":"https://api.pagerduty.com/users/P2WR1IF","html_url":"https://nordstrom.pagerduty.com/users/P2WR1IF"}}],"restrictions":[]}],"overrides_subschedule":{"name":"Overrides","rendered_schedule_entries":[],"rendered_coverage_percentage":null},"final_schedule":{"name":"Final Schedule","rendered_schedule_entries":[],"rendered_coverage_percentage":null},"teams":[{"id":"P88GC8I","type":"team_reference","summary":"Steve Test Team","self":"https://api.pagerduty.com/teams/P88GC8I","html_url":"https://nordstrom.pagerduty.com/teams/P88GC8I"}]}}';
    var sched = '{"schedule":{"id":"PPW7BH3","type":"schedule","summary":"Steve Test 2nd On-call","self":"https://api.pagerduty.com/schedules/PPW7BH3","html_url":"https://nordstrom.pagerduty.com/schedules/PPW7BH3","name":"Steve Test 2nd On-call","time_zone":"America/Los_Angeles","description":null,"privilege":null,"users":[{"id":"PTP3LA6","type":"user_reference","summary":"Steve3 Test Huitt","self":"https://api.pagerduty.com/users/PTP3LA6","html_url":"https://nordstrom.pagerduty.com/users/PTP3LA6"}],"escalation_policies":[{"id":"PYCDPOG","type":"escalation_policy_reference","summary":"Steve Test Escalation Policy","self":"https://api.pagerduty.com/escalation_policies/PYCDPOG","html_url":"https://nordstrom.pagerduty.com/escalation_policies/PYCDPOG"}],"schedule_layers":[{"name":"Layer 1","rendered_schedule_entries":[],"rendered_coverage_percentage":null,"id":"PQ970L7","start":"2017-12-12T11:16:14-08:00","end":null,"rotation_virtual_start":"2017-12-11T08:00:00-08:00","rotation_turn_length_seconds":604800,"users":[{"user":{"id":"PTP3LA6","type":"user_reference","summary":"Steve3 Test Huitt","self":"https://api.pagerduty.com/users/PTP3LA6","html_url":"https://nordstrom.pagerduty.com/users/PTP3LA6"}}],"restrictions":[]}],"overrides_subschedule":{"name":"Overrides","rendered_schedule_entries":[],"rendered_coverage_percentage":null},"final_schedule":{"name":"Final Schedule","rendered_schedule_entries":[],"rendered_coverage_percentage":null},"teams":[{"id":"P88GC8I","type":"team_reference","summary":"Steve Test Team","self":"https://api.pagerduty.com/teams/P88GC8I","html_url":"https://nordstrom.pagerduty.com/teams/P88GC8I"}]}}';

    var body = JSON.parse(sched);
    var user = 'PTP3LA6';
    var new_sched = updateOncallSchedule(body, user);
    gs.print('new schedule: ' + new_sched);


    function updateOncallSchedule(body, user) {
        gs.print('name: ' + body.schedule.name + ', id: ' + body.schedule.id);
        var new_users = processUsers(body.schedule.users, user);
        gs.print('new users: ' + JSON.stringify(new_users));
        if (new_users.length == 0) {
            //var replacement = findReplacement(user);
            new_users.push({"user": { "id": "REPLACE", "type": "user_reference"}});
        }
        body.schedule.users = new_users;

        var new_layers = processLayers(body.schedule.schedule_layers, user);
        gs.print('new layers: ' + JSON.stringify(new_layers));
        if (new_layers.length == 0) {
            //var replacement = findReplacement(user);
            new_layers.push({"user": { "id": "REPLACE", "type": "user_reference"}});
        }
        body.schedule.schedule_layers = new_layers;
        return JSON.stringify(body);
    }

    function processUsers(users, user) {
        var new_users = [];
        for (var i = 0; i < users.length; i++) {
            gs.print('user id: ' + users[i].id);
            if (users[i].id != user) {
                new_users.push(users[i]);
            } else {
                gs.print('found a match');
            }
        }
        return new_users;
    }

    function processLayers(layers, user) {
        gs.print('number of layers: ' + layers.length);
        var new_layers = [];
        for (var i = 0; i < layers.length; i++) {
            var new_users = processLayerUsers(layers[i], user);
            if (new_users.length > 0) {
                layers[i].users = new_users;
                new_layers.push(layers[i]);
            }
        }
        return new_layers;
    }

    function processLayerUsers(layer, user) {
        gs.print('number of layer users: ' + layer.users.length);
        var new_users = [];
        for (var i = 0; i < layer.users.length; i++) {
            var new_item = processLayerUserItem(layer.users[i], user);
            if (!gs.nil(new_item)) {
                new_users.push(new_item);
			}
        }
        return new_users;
    }

    function processLayerUserItem(item, user) {
        gs.print('looking for user id: ' + user);
        gs.print('item id: ' + item.user.id + ', type: ' + item.user.type + ', summary: ' + item.user.summary);
        if (item.user.type == 'user_reference' && item.user.id == user) {
            gs.print('found a match');
            return null;
        }
        return item;
    }
}())
