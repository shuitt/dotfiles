var u_Nord_Org_MDM_utils = Class.create();
u_Nord_Org_MDM_utils.prototype = {
	LOGPFX: '---> Org MDM integration: ',
    RESTMSG: 'Org MDM Store API',

    initialize: function(logging) {
		this.logging = logging;
    },

    // send a rest message
    callApi: function() {
        this.writeLog('In callApi');
		var response = null;
		var result = {'status': null,
			'body': null,
			'success': true
		};
        var msg = this.createMsg();

        try {
			response = msg.execute();
		} catch(ex) {
			this.writeErrorLog('Org MDM call exception: ' + ex.getMessage());
			result.success = false;
			return result;
		}

        result.status = response.getStatusCode();
		result.body = response.getBody();
		if (result.status != 200) {
			this.writeErrorLog('Org MDM API call failed: ' + '\nHTTP Status: ' + result.status +
                                '\nResponse: ' + response.getBody());
			result.success = false;
			return result;
		}
		return result;
	},

    // create the rest msg for calling the org mdm store api
    createMsg: function() {
        this.writeLog('Create REST message\nInstance: ' + gs.getProperty('instance_name'));
        var method = 'Prod';
        var key = gs.getProperty('u_nord.org_mdm_api_key.prod');

        // if dev or test sn instance we need different api key and method
        if (gs.getProperty('instance_name') == 'nordstromdev' ||
		    gs.getProperty('instance_name') == 'nordstromtest') {
				method = 'NonProd';
				key = gs.getProperty('u_nord.org_mdm_api_key.nonprod');
        }

        //  create rest msg and set vars
        var msg = new sn_ws.RESTMessageV2(this.RESTMSG, method);
        msg.setStringParameter('key', key);
        msg.setStringParameter('corrid', this.generateCorrId());

        // log the msg endpoint
        this.writeLog('REST message properties:\n\tEndpoint: ' + msg.getEndpoint());
        return msg;
    },

    // create an asynchronous import set using the specified table
	getImpSet: function(table) {
        this.writeLog('Create import set with table ' + table);
        var impset = new GlideRecord('sys_import_set');
        impset.initialize();
        impset.table_name = table;
        impset.mode = 'asynchronous';
        impset.state = 'loading';
        impset.insert();
        this.writeLog('Import set created');
		return impset;
	},

    // run a transformation using a given map
	doTransform: function(impset, mapname) {
		this.writeLog('Find transformation map "' + mapname + '"');
        var map = new GlideRecord('sys_transform_map');
        map.addQuery('name', mapname);
        map.query();
        // if we have a map run the transformation
        if(map.next()) {
            this.log('Run the transformation');
            var thread = new GlideImportSetTransformerWorker(impset.sys_id, map.sys_id);
            thread.setBackground(true);
            thread.start();
        } else {
            this.writeErrorLog('Did not find transform map ' + mapname);
        }
	},

    // generate a guid-like correlation id for org mdm api calls
	generateCorrId: function() {
        var uuid = '';
        for (var i = 0; i < 32; i++) {
            var random = Math.random() * 16 | 0;
            if (i == 8 || i == 12 || i == 16 || i == 20) {
                uuid += '-';
            }
            uuid += (i == 12 ? 4 : (i == 16 ? (random & 3 | 8) : random)).toString(16);
        }
        return uuid;
    },

    // write a message to the SN system log
	writeLog: function(msg) {
		if (this.logging) {
			gs.info(this.LOGPFX + msg);
		}
	},

    // write a message to the SN system log
	writeErrorLog: function(msg) {
		gs.info(this.LOGPFX + msg);
	},

    type: 'u_Nord_Org_MDM_utils'
};
