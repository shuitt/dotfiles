(function(){
    // update server ci server tagging reference
    var gr = new GlideRecord('cmdb_ci_server');

    gr.addNullQuery('u_server_tags');
    gr.query();
    gs.print('Found ' + gr.getRowCount() + ' servers with an empty server tagging reference');
    while (gr.next()) {
        gs.print('Updating server: ' + gr.name);
        gr.setForceUpdate(true); //Force the update
        gr.update();
    }
    gr.initialize();
    gr.addNullQuery('u_server_tags');
    gr.query();
    gs.print('Found ' + gr.getRowCount() + ' servers with an empty server tagging reference');
    while (gr.next()) {
        gs.print('Server was not updated: ' + gr.name);
    }
}())
