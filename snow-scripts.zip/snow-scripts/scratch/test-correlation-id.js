(function () {
    function getCorrelator(prefix) {
        var gdt = new GlideDateTime();
        var corr = prefix + '/' + gdt.getNumericValue();
        return corr;
    }

    var prefixes = ['abc', 'HRSw: 1212', '#@#osdcn'];
    for (var i = 0; i < prefixes.length; i++) {
        gs.print(getCorrelator(prefixes[i]));
    }
})();
