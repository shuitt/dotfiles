(function(){
    var query = "u_app_idSTARTSWITHapp000^sys_created_on>=javascript:gs.dateGenerate('2018-03-01','00:00:00')";
    var gr = new GlideRecord('u_applications');
    gr.addEncodedQuery(query);
    gr.query();
    while (gr.next()) {
        var app_id = gr.u_app_id;
        var new_app_id = app_id.substr(0, 3) + app_id.substr(5);
        gs.print(gr.u_long_name + ', ' + gr.u_app_id + ', ' + app_id + ', ' + new_app_id);
        gr.u_app_id = new_app_id;
        gr.update();
    }
}())
