(function () {
    var app = new GlideRecord('u_applications');
    app.setLimit(1);
    app.query();
    while (app.next()) {
        for (var p in app) {
            gs.print('field: ' + p);
        }
    }
})();
