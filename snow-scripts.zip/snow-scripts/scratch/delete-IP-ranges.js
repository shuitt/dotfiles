(function(){
    var gr = new GlideRecord('u_discovery_ip_range_steve');
    //var query = 'sys_created_onONToday@javascript:gs.beginningOfToday()@javascript:gs.endOfToday()';
    //gr.addEncodedQuery(query);
    gr.query();
    gs.print('Rows to delete: ' + gr.getRowCount());
    gr.deleteMultiple();
}())

(function(){
    var agg = new GlideAggregate('u_discovery_ip_range_steve');
    agg.addAggregate('COUNT');
    agg.groupBy('u_location');
    agg.query();
    while (agg.next()) {
        count = agg.getAggregate('COUNT');
        var location = agg.u_location.getDisplayValue();
        gs.print(location + '\t' + agg.getAggregate('COUNT'));
    }
}())
