(function(){
    gs.print('Label\tName\tCreated By\tCreated On\tRecords');
    var gr = new GlideRecord('sys_db_object');
    gr.addEncodedQuery('super_class=b7b6f09adbf032c0219074b5ae961939^nameSTARTSWITHu_');
    gr.query();
    while (gr.next()) {
        var count = new GlideAggregate(gr.name);
        count.addAggregate('COUNT');
        count.query();
        var records = 0;
        if (count.next()) {
            records = count.getAggregate('COUNT');
        }
        gs.print(gr.sys_name + '\t' + gr.name + '\t' + gr.sys_created_by + '\t' + gr.sys_created_on + '\t' + records);
    }
}())
