(function () {
    // get a list of servers where location is empty
    var pat = /\D+(\d+)\D.*/;

    var locs = new GlideRecord('cmn_location');
    var server = new GlideRecord('cmdb_ci_server');
    server.addEncodedQuery('locationISEMPTY');
    server.setLimit(2000);
    server.query();

    while (server.next()) {
        var l = server.name.match(pat);
        if (!gs.nil(l) && l.length > 0) {
            //gs.print('store: ' + l[1]);
            var store = l[1].replace(/^[0|\D]*/,'');
            //gs.print('store: ' + store);
            locs.initialize();
            locs.addQuery('u_store_number', store);
            locs.query();
            if (locs.next()) {
                //gs.print('found: ' + locs.name);
                server.location = locs.name;
                server.setWorkflow(false);
                server.update();
            }
        }
    }
})();
