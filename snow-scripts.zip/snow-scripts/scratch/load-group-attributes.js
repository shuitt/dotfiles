(function(){
    // update group attibutes

    function inGroup(grpID, user) {
        var gr = new GlideRecord ('sys_user_grmember');
        gr.addQuery('group', grpID);
        gr.addQuery('user', user);
        gr.query();
        if (gr.next()) {
            return true;
        } else {
            return false;
        }
    }

    var grUser = new GlideRecord('sys_user');
    var grGrp  = new GlideRecord('sys_user_group');
    var grTmp = new GlideRecord('u_load_group_attributes');

    grTmp.query();
    while (grTmp.next()) {
        var dirId = null;
        var mgrId = null;
        grGrp.initialize();
        grGrp.addQuery('name', grTmp.u_group);
        grGrp.query();

        if (grGrp.next()) {
            grUser.initialize();
            grUser.addQuery('employee_number', grTmp.u_director_employee_number);
            grUser.query();
            if (grUser.next()) {
                dirId = grUser.getUniqueValue();
            } else {
                gs.print('Could not find director ' + grTmp.u_director_name + ', emp nbr ' + grTmp.u_director_employee_number);
            }

            grUser.initialize();
            grUser.addQuery('employee_number', grTmp.u_manager_employee_number);
            grUser.query();
            if (grUser.next()) {
                mgrId = grUser.getUniqueValue();
            }else {
                gs.print('Could not find maanger ' + grTmp.u_manager_name + ', emp nbr ' + grTmp.u_manager_employee_number);
            }

            grGrp.name  = grTmp.u_group;
            grGrp.description  = grTmp.u_description;
            grGrp.u_director  = dirId;
            grGrp.manager  = mgrId;
            grGrp.email  = grTmp.u_group_email;
            grGrp.u_jira_project  = grTmp.u_jira_project;
            grGrp.u_jira_project_key = grTmp.u_jira_project_key;
            grGrp.update();
        } else {
            gs.print('Could not find group Group ' + grTmp.u_group);
        }
    }
}())
