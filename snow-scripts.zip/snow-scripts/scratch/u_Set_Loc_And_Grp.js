(function executeRule(current, previous /*null when async*/) {
	var ciUtils = new u_CiOwnerUtils();
	current.support_group = ciUtils.getNsgGroup();	// default support group
	var loc = ciUtils.getLocation(current.name);	// get loc based on dev name
	if (loc != null) {
		current.location = loc;
		var suppGrp = ciUtils.getOwningGroup(loc);
		if (suppGrp != null) {
			current.support_group = suppGrp;
		}
	}
})(current, previous);
