(function executeRule() {
    var count = 0;
  	var ciUtils = new u_CiOwnerUtils();
    var gr = new GlideRecord('cmdb_ci_vm_instance');
    //gr.addEncodedQuery('location=NULL');
  	//gr.setLimit(15000);
  	//gr.orderBy('location');
    gr.orderByDesc('name');
    gr.query();
  	gs.print('rows: ' + gr.getRowCount());
    while (gr.next()) {
        var msg = 'name: ' + gr.name;
        // get location from hosting virtualization server
        var loc = ciUtils.getLocFromRegHost(gr.sys_id);
        msg += '\n++ getLocFromVirtHost returned ' + loc;
        if (!gs.nil(loc)) {    // update if we got a loc
    		gr.location = loc;
            gr.setWorkflow(false);
            gr.autoSysFields(false);
            gr.update();
            msg += '\n++ setting loc to: ' + loc;
            count++;
        }
        //gs.print(msg);
    }
    gs.print('updated: ' + count);
})();
