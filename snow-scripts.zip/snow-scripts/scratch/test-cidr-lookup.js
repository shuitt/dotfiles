(function(){
    function findNetBySysid(array, key, value) {
        for (var i = 0; i < array.length; i++) {
            if (array[i][key] === value) {
                return array[i];
            }
        }
        return null;
    }

    var networks = [
        {net: '10.35.36.0/24', sys_id: '44902e36db2fdb002914788dbf961905'},
        {net: '10.82.1.0/24', sys_id: '89416af2db2fdb002914788dbf96193b'},
        {net: '10.82.2.0/23', sys_id: 'ac91e676db2fdb002914788dbf961936'},
        {net: '10.82.28.0/28', sys_id: '5e5122f2db2fdb002914788dbf9619ea'}
        ];
    var ips = [
        '10.35.36.1',
        '10.35.36.156',
        '10.82.1.10',
        '10.82.1.123',
        '10.82.2.28',
        '10.82.3.24',
        '10.82.2.550',
        '10.82.28.2',
        '10.82.28.250',
        '10.120.28.50',
        '161.181.178.10'
        ];
    var utils = new CidrUtil();
    for (var i = 0; i < ips.length; i++) {
        //var net = utils.findNetwork(ips[i]);
        var net = utils.findNetwork2(ips[i]);
        //gs.print('findNetwork for IP ' + ips[i] + ' returned ' + net);
        if (!gs.nil(net)) {
            //var range = findNetBySysid(networks, 'sys_id', net);
            gs.print('IP: ' + ips[i] + ', ' + net);
        } else {
            gs.print('IP: ' + ips[i] + ', no containing network found');
        }
    }
}())
