(function(){
    var utils = new u_Nord_User_Utils();
    var gr = new GlideRecord('sys_user_group');
    gr.addNullQuery('u_vp');
    gr.query();
    gs.print('groups without a VP: ' + gr.getRowCount());

    while (gr.next()) {
        var vp = utils.getUserVP(gr.manager);
        //gs.print('group: ' + gr.name + ', VP: ' + vp);
        gr.u_vp = vp;
        gr.setWorkflow(false);
        gr.autoSysFields(false);
        gr.update();
    }

    gr.initialize();
    gr.addNullQuery('u_vp');
    gr.query();
    gs.print('groups without a VP: ' + gr.getRowCount());
}())
