var data = "Name,Firstname";
data += "\n";
data += "Huitt,Steve";
data += "\n";
data += "Blow,Joe";
data += "\n";
data += "Brown,Bob";
var gr = new GlideRecord('incident');
if (gr.get('30bd3550db9613002914788dbf961919')) {  // sys_id of rec to attach to
    var attachment = new GlideSysAttachment();
    var newFile = attachment.write(gr, 'Test.csv', 'text/csv', data);
    if (!gs.nil(newFile)) {
        gs.print('attached');
    } else {
        gs.print('attach failed')
    }
} else {
    gs.print('get rec failed');
}
