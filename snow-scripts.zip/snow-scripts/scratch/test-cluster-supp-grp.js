(function(){
	var utils = new u_ServerTaggingUtils();
	var server = 'a0319p401';
	var grp_id = '046a984fdb00fe0063f6fcfaae961961';  // service management platform

	//Get server sys_id
	var server_id  = utils.findServerCI(server);
	if (JSUtil.notNil(server_id)) {
		gs.print('Server ' + server + ', name: ' + server_id.name + ', sys_id: ' + server_id);
		var node_id = utils.updateClNodeCi(server_id, grp_id);
		if (JSUtil.notNil(node_id)) {
			utils.updateClResCi(node_id, grp_id);
		}
	}
}())
