// Business Rules: u_Set_PCI_PII_SOX_Sup_Grp_Del
// Table: u_applications
// When: After
// Filter: Support Group is not empty and
//         PCI is true or
//         PII is true or
//         SOC1 Nordstrom is true or
//         SOC1 Bank  is true or
//         SOX  is true

(function executeRule(current, previous /*null when async*/) {
	gs.addInfoMessage('u_Set_PCI_PII_SOX_Sup_Grp_Del fired on ' + current.u_long_name);
	var utils = new u_PciPiiSoxSupGrpUtils();
	gs.addInfoMessage(current.support_group.name + ' has the nord_pci_pii_sox_support_group role');
    if (!utils.grpHasApps(current.support_group)) {
        gs.addInfoMessage(current.support_group.name + ' has no other PII/PCI/SOX apps, remove the nord_pci_pii_sox_support_group role');
        utils.remRoleFromGrp(current.support_group);
    } else {
        gs.addInfoMessage(current.support_group.name + ' has other PII/PCI/SOX apps, keep the nord_pci_pii_sox_support_group role');
    }
})(current, previous);
