#!/usr/bin/env python3

import json
import csv
import sys
import string

JSONFILE = '/Users/xsmh/Downloads/app-depend.json'
CSVFILE = '/Users/xsmh/Downloads/app-depend.csv'

HEADER = [
    'Parent',               # 0 - parent (dependent) app id
    'Type',                 # 1 - relationship type
    'Child',                # 2 - child app id
    'Connection strength'   # 3 - connection strength
]
do_header = True

json_file = open(JSONFILE)
data = json.load(json_file)
json_file.close()

app_data = open(CSVFILE, 'w')
csvwriter = csv.writer(app_data)

for p in data['apps']:
    outrow = [''] * len(HEADER)
    if do_header:
        csvwriter.writerow(HEADER)
        do_header = False

    if p['dependent_appid_id'].startswith('APP') and p['appid_id'].startswith('APP'):
        print( p['appid_id'] + ' -> Depends on::Used by -> ' + p['dependent_appid_id'])
        outrow[0] = p['appid_id']
        outrow[1] = 'Depends on::Used by'
        outrow[2] = p['dependent_appid_id']
        outrow[3] = 'always'
        csvwriter.writerow(outrow)

app_data.close()
