(function(){
	var loc = null;
	var devName = null;
	var store = null;
	var pat = /^\D*(\d+)\D*/i;
	var upsPat = /^powerxpert.*/i;
	rmZeroPat = /^0+/;

	function findeDevs(table, type) {
		var gr = new GlideRecord(table);
		gr.addEncodedQuery('location=false^ORlocationISEMPTY');
		gr.query();
		gs.print('Found ' + gr.getRowCount() + ' ' + type + ' devices without location');
		while (gr.next()) {
			devName = gr.name;
			loc = devName.match(pat);
			if (loc != null) {
				if (devName.match(upsPat) == null) {  // filter out misclassified ups devs
					loc = devName.match(pat);
					if (loc != null) {
						store = loc[1].replace(rmZeroPat, '');
						//gs.print(type + ' name: ' + devName + ', location: ' + store);
						store_sys_id = getLoc(store);
						if (store_sys_id != null) {
							gr.location = store_sys_id;
							gr.update();
							gs.print('Updated location for ' + type + ' ' + devName + ' to store ' + store);
						} else {
							gs.print('Unable to update location for ' + type + ' ' + devName + ', store ' + store + ' not found');
						}
					} else {
						gs.print('Unable to update location for ' + type + ' ' + devName + ', unable to determine store number');
					}
				}
			}
		}
	}

	function getLoc(store) {
		var grSt = new GlideRecord('cmn_location');
		grSt.addQuery('u_store_number', store);
		grSt.query();
		if (grSt.next()) {
			//gs.print('Found store ' + store + ', sys_id is ' + grSt.sys_id);
			return grSt.sys_id;
		} else {
			//gs.print('Did not find store ' + store);
			return null;
		}
	}

	findeDevs('cmdb_ci_ip_switch', 'IP Switch'); 		// IP Switch table
	findeDevs('cmdb_ci_ip_router', 'IP Router'); 		// IP router table
	findeDevs('u_cmdb_ci_wireless_controller', 'Wireless Controller'); 	// wireless controller table
}())
