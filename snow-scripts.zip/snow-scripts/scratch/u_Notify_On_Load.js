(function executeRule(current, previous /*null when async*/) {
    var utils = new u_Slack_Integration();
    var msg = utils.formatMessage(current, 'loaded');
    var logmsg = 'u_Notify_On_Load:\nMessage:' + msg;

    // send message to #we-smp-team
    var result = utils.sendHookMessage(msg, 'SMP');
    logmsg += '\nSend message to #we-smp-team\nResult: ' + result;

    // if update set is for the security incident application send message to #smp-sir-servicenow
    if (current.application.name == 'Security Incident') {
        result = utils.sendHookMessage(msg, 'SIR');
        logmsg += '\nSend message to #smp-sit-servicenow\nResult: ' + result;
    } else {
        logmsg += '\nNot a Security Incident update set - do not send message to #smp-sit-servicenow';
    }

	gs.log(logmsg);
})(current, previous);
