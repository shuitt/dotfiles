(function () {
    var query = 'childISNOTEMPTY^type.parent_descriptor=Ip Connection^parent.name=';
    var rels = new GlideRecord('cmdb_rel_ci');   // ci relationship table

    // get a list of servers where location is empty
    var server = new GlideRecord('cmdb_ci_server');
    server.addEncodedQuery('locationISEMPTY');
    server.setLimit(2000);
    server.query();

    while (server.next()) {
        // look for ci relationships where the server is the parent ci
        rels.initialize();
        rels.addEncodedQuery(query + server.name);
        rels.query();

        while (rels.next()) {
            // look for child cis that can switch and have a non-empty location
            if (rels.child.can_switch && !gs.nil(rels.child.location)) {
                server.location = rels.child.location;
                server.setWorkflow(false);
                var id = server.update();
                //gs.print('Bingo!! host: ' + server.name + ', switch: ' + rels.child.name + ', location: ' + rels.child.location.name + ', sys_id: ' + id);
                break;    // got a location so skip checking any remaining relationships
            }
        }
    }
})();
