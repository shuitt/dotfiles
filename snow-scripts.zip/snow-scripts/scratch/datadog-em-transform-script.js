(function process(/*RESTAPIRequest*/ request, body) {
	var logmsg = '--> Datadog listener transform script\nbody: ' + body + '\nheaders: ' + JSON.stringify(request.headers);
	try {
		var requestBody = JSON.parse(body);
        var gr = new GlideRecord('em_event');
		gr.initialize();

		gr.time_of_event = new GlideDateTime();
        gr.source = requestBody.source;
        gr.event_class = requestBody.event_class;
        gr.node = requestBody.node;
        gr.resource = requestBody.resource;
        gr.metric_name = requestBody.metric_name;
        gr.type = requestBody.type;
        gr.message_key = requestBody.message_key;
        gr.description = requestBody.description;

		if (requestBody.type.indexOf('[Recovered]') == 0) {
			gr.severity = 0; // clear
		} else if (requestBody.severity == 'normal') {
			gr.severity = 2; // major
		} else {
			gr.severity = 4; // warning
		}

        var additional_info = JSON.parse(JSON.stringify(requestBody.additional_info));
		additional_info.orig_severity = requestBody.severity;

        // get additional_info properties embedded in the description as:
		// %%{key1: value1, key2: value2, ...}
		var ai = /%%{.+}%%/.exec(requestBody.description);
		if (!gs.nil(ai)) {
			logmsg += '\n--> ai: ' + ai[0] + ', length: ' + ai[0].length;
			var add_info = null;
			try {
				add_info = JSON.parse(ai[0].slice(2, -2));
				logmsg += '\nproperties found in description:';
				for (var k in add_info) {
				    logmsg += '\n    add.info.' + k + ': ' + add_info[k];
					if (k == 'application') {
						additional_info.u_app_id = add_info[k];
						//additional_info.name = add_info[k];
						//additional_info.u_long_name = add_info[k];
					} else {
						additional_info[k] = add_info[k];
					}
				}
			} catch (er) {
				logmsg += '\n--> Error parsing additional_info properties from description: ' + er;
			}
		} else {
			logmsg += '\nNo additional_info properties found in description';
		}

		//additional_info['original_body'] = requestBody;
		gr.additional_info = JSON.stringify(additional_info);
		logmsg += '\n--> additional_info: ' + JSON.stringify(additional_info);

		gr.insert();
		gs.info(logmsg);
	} catch (er) {
		gs.log(logmsg + '\n--> Datadog listener script error: ' + er);
		status=500;
		return er;
	}
	return "success";
})(request, body);
