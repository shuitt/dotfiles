(function(){
    function updateIncidents() {
        var inc_query = 'assignment_groupSTARTSWITHregional it^stateIN1,2,3';
        var inc_gr = new GlideRecord('incident');
        inc_gr.addEncodedQuery(inc_query);
        inc_gr.orderBy('number');
        //inc_gr.setLimit(2);
        inc_gr.query();
        gs.print('incidents: ' + inc_gr.getRowCount());
        while (inc_gr.next()) {
            //gs.print('Updating ' + inc_gr.number);
            inc_gr.assignment_group = gs.getProperty('u_nord.unisys.task.reassign.group.id');
            inc_gr.assigned_to = '';
            inc_gr.state = 1;   // new
            inc_gr.comments.setJournalEntry('** BACKLOG **');
            inc_gr.autoSysFields(false);
            inc_gr.update();
        }
    }

    function updateTasks() {
        var task_query = 'sys_class_name=change_task^ORsys_class_name=incident_task^ORsys_class_name=problem_task^ORsys_class_name=sc_task^ORsys_class_name=ticket^assignment_groupSTARTSWITHregional it^stateIN-5,1,2';
        var task_gr = new GlideRecord('task');
        task_gr.addEncodedQuery(task_query);
        task_gr.orderBy('number');
        //task_gr.setLimit(2);
        task_gr.query();
        gs.print('tasks: ' + task_gr.getRowCount());
        while (task_gr.next()) {
            //gs.print('Updating ' + task_gr.number);
            task_gr.assignment_group = gs.getProperty('u_nord.unisys.task.reassign.group.id');
            task_gr.assigned_to = '';
            task_gr.state = 1;   // open
            task_gr.comments.setJournalEntry('** BACKLOG **');
            task_gr.autoSysFields(false);
            task_gr.update();
        }
    }

    updateIncidents();
    updateTasks();
}())
