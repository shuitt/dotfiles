(function(){
    // script to sync server CIs with the server tagging table
    var grCI = new GlideRecord('cmdb_ci_server');
    grCI.addNullQuery('u_server_tagging');
    grCI.query();
    gs.info('Number of server CIs not linked to a tagging record: ' + grCI.getRowCount());
    var updCnt = 0;
    var newCnt = 0;
    while (grCI.next()) {
		var grTag = new GlideRecord('u_server_tagging');
        grTag.setForceUpdate(true);
        grTag.addQuery('u_server_name', grCI.name);
		grTag.query();
        if (grTag.next()) {
			//gs.info('Server tagging record found: ' + grCI.name);
            // force update to drive biz rule linking ci to tag record
            grTag.update();
            updCnt = updCnt + 1;
        } else {
			//gs.info('Server tagging record not found: ' + grCI.name);
            grTag.newRecord();
        	grTag.u_server_name = grCI.name;
        	grTag.insert();
            newCnt = newCnt + 1;
        }
    }
	gs.info('Updated server tagging records records: ' + updCnt);
    gs.info('New server tagging records records: ' + newCnt);
}())
