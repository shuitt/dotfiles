(function(){
    var query = 'nameSTARTSWITHpower^sys_class_name=cmdb_ci_ip_router';
    var ups_class = 'cmdb_ci_ups';

    var gr = new GlideRecord('cmdb_ci_hardware');
    gr.addEncodedQuery(query);
    //gr.setLimit(2);
    gr.query();
    gs.print('rows:' + gr.getRowCount());
    gr.setValue('sys_class_name',  ups_class);
    gr.updateMultiple();
}())
