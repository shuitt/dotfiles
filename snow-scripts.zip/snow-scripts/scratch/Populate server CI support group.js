(function executeRule(current, previous /*null when async*/) {
    // get server tagging rec support group
	var sg = current.u_server_tags.u_support_group;
    // JSUtil.notNil validates value is not null or empty or undefined.
    if (JSUtil.notNil(sg) && current.support_group != sg) {
		// fire event that will push server tagging supprot group to this ci as well
		// as any associated cluster related ci and any ci with a runs on relationship
		gs.eventQueue('server_tag.support.group.changed', current, current.name, sg);
	}
})(current, previous);
