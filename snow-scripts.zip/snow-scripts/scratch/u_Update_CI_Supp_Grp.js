// after update into u_server_tagging
// condition: u_server_ci is not empty and u_support_group changes

(function executeRule(current, previous /*null when async*/) {
	//stUtils = new u_ServerTaggingUtils();
	//var ci_id = stUtils.updCiSupp_grp(current.u_server_ci, current.u_support_group);
	gs.eventQueue('server_tag.support.group.changed', current, current.u_server_name, current.u_support_group);
})(current, previous);
