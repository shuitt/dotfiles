(function(){
    var gr = new GlideRecord('sys_user');
    gr.addEncodedQuery('u_termination_date<=javascript:gs.daysAgoEnd(0)');
    gr.query();
    gs.info('Deleting ' + gr.getRowCount() + ' terminated users');
    while (gr.next()) {
        gr.deleteRecord();
    }
}())
