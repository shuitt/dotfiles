(function executeRule(current, previous /*null when async*/) {
	//STRY1740093 - Feb 2017

		var str = current.u_batch_job;
		var res = str.split("/");
		var ciapp = (res[1]);

		// safety net assignment group
		var gr = new GlideRecord('sys_user_group');
		gr.addQuery('name', 'Service Desk');
		gr.query();
		if (gr.next()) {
			current.assignment_group = gr.getUniqueValue();
		}

		var matchHlq = new GlideRecord("u_hlq");
		matchHlq.addQuery("u_hlq", ciapp.substr(0,5)); //return first 5 only
		matchHlq.query();
		if (matchHlq.next()) {
			current.short_description = "Job " + ciapp + " failed";
			current.cmdb_ci = matchHlq.u_application_portfolio;
			 if(JSUtil.notNil(matchHlq.u_application_portfolio.support_group)) {
				current.assignment_group = matchHlq.u_application_portfolio.support_group;
			}
			return;
		}

		matchHlq.initialize();
		matchHlq.addQuery("u_hlq", ciapp.substr(0,4)); //return first 4 only
		matchHlq.query();
		if (matchHlq.next()) {
			current.short_description = "Job " + ciapp + " failed";
			current.cmdb_ci = matchHlq.u_application_portfolio;
			 if(JSUtil.notNil(matchHlq.u_application_portfolio.support_group)) {
				current.assignment_group = matchHlq.u_application_portfolio.support_group;
			}
			return;
		}

		matchHlq.initialize();
		matchHlq.addQuery("u_hlq", ciapp.substr(0,3)); //return first 3 only
		matchHlq.query();
		if (matchHlq.next()) {
			current.short_description = "Job " + ciapp + " failed";
			current.cmdb_ci = matchHlq.u_application_portfolio;
			if(JSUtil.notNil(matchHlq.u_application_portfolio.support_group)) {
				current.assignment_group = matchHlq.u_application_portfolio.support_group;
			}
			return;
		}

		matchHlq.initialize();
		matchHlq.addQuery("u_hlq", ciapp.substr(0,2)); //return first 2 only
		matchHlq.query();
		if (matchHlq.next()) {
			current.short_description = "Job " + ciapp + " failed";
			current.cmdb_ci = matchHlq.u_application_portfolio;
			if(JSUtil.notNil(matchHlq.u_application_portfolio.support_group)) {
				current.assignment_group = matchHlq.u_application_portfolio.support_group;
			}
		} else {
			current.short_description = "Job " + ciapp + " failed";
			current.cmdb_ci = gs.getProperty('nordstrom.notlisted.ci');
		}
})(current, previous);
