(function(){
    // add group managers and directors to 'Technology Leadership - Approvers' group

    function getGroupId(group) {
        var gr = new GlideRecord ('sys_user_group');
        gr.addQuery('name', group);
        gr.query();
        if (gr.next()) {
            return gr.getUniqueValue();
        } else {
            return null;
        }
    }

    function inGroup(grpID, user) {
        var gr = new GlideRecord ('sys_user_grmember');
        gr.addQuery('group', grpID);
        gr.addQuery('user', user);
        gr.query();
        if (gr.next()) {
            return true;
        } else {
            return false;
        }
    }

    var techLeadGrpId = getGroupId('Technology Leadership - Approvers');
    var grMbr = new GlideRecord('sys_user_grmember');
    var grGrp = new GlideRecord('sys_user_group');
    grGrp.query();
    while (grGrp.next()) {
        if (grGrp.u_director != null && !inGroup(techLeadGrpId, grGrp.u_director)) {
            gs.print('Add director: ' + grGrp.u_director.user_name + ', sys_id: ' + grGrp.u_director);
            grMbr.initialize();
            grMbr.group = techLeadGrpId;
            grMbr.user = grGrp.u_director;
            grMbr.insert();
        }
        if (grGrp.manager != null && !inGroup(techLeadGrpId, grGrp.manager)) {
            gs.print('Add manager: ' + grGrp.manager.user_name + ', sys_id: ' + grGrp.manager);
            grMbr.initialize();
            grMbr.group = techLeadGrpId;
            grMbr.user = grGrp.manager;
            grMbr.insert();
        }
    }
}())
