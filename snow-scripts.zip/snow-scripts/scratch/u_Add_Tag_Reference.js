// Before insert or update into cmdb_ci_server
// condition: u_server_tags is empty

(function executeRule(current, previous /*null when async*/) {
	stUtils = new u_ServerTaggingUtils();
	var st_id = stUtils.findTaggedServer(current.name);

	if (st_id != null) { // matching st rec exists add ci <-> st rec refrences
		current.u_server_tags = st_id;
		stUtils.addRefServer(st_id, current.sys_id);
	} else {  // no matching st rec exists, create on and add ci <-> st rec refrences
		st_id = stUtils.createTaggedServer(current.name, current.sys_id);
		current.u_server_tags = st_id;
	}
})(current, previous);
