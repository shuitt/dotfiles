(function(){
    // see https://developer.servicenow.com/app.do#!/api_doc?v=kingston&id=c_WorkflowAPI for info
    // Define which workflow we want to execute, and what input parameters we want to provide
    var workflowName = "Steve Test 2";
    var inputs = {
        u_name: 'Steve Huitt',
        u_stuff: 'Some nonsense goes here'
    };
    // Prepare our workflow, and execute it, keeping track of the GR for the newly spawned context
    var wf = new Workflow();
    var wfId = wf.getWorkflowFromName(workflowName);
    var wfContextGr = wf.startFlow(wfId,null, null, inputs);
}())
