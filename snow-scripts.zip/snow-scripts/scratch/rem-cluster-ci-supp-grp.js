(function(){
	function remSuppGrp(table, type) {
		gr = new GlideRecord(table);
		gr.addEncodedQuery('support_groupISNOTEMPTY');
		gr.setLimit(20);
		gr.query();
		gs.print('Removing support group from ' + gr.getRowCount() + ' ' + type);
		while (gr.next()) {
			gs.print('   name: ' + gr.name + ', support group: ' + gr.support_group.name);
			gr.support_group = '';
			gr.update();
		}
	}

	remSuppGrp('cmdb_ci_cluster', 'clusters');
	remSuppGrp('cmdb_ci_cluster_node', 'cluster nodes');
	remSuppGrp('cmdb_ci_cluster_resource', 'cluster resources');
}())
