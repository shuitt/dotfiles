// Business Rules: u_Set_PCI_PII_SOX_Sup_Grp_Upd
// Table: u_applications
// When: After
// Filter: Support Group is changed or
//         PCI is changed or
//         PII is changed or
//         SOC1 Nordstrom is changed or
//         SOC1 Bank  is changed or
//         SOX  is changed
// Action:
//
//   Support Group    Current         Previous        Action
//   The Same?        PCI/PII/SOX     PCI/PII/SOX
// 1 FALSE	          TRUE            TRUE            See if current group already has role assigned, if not add it
//                                                    See if previous group has any other PCI/PII/SOX apps, if not remove rolr
// 2 FALSE            TRUE	          FALSE	          See if current group already has role assigned, if not add it
// 3 FALSE	          FALSE	          TRUE        	  See if previous group has any other PCI/PII/SOX apps, if not remove role
// 4 FALSE	          FALSE       	  FALSE	          No action needed
// 5 TRUE	          TRUE	          TRUE	          No action needed
// 6 TRUE	          TRUE	          FALSE	          See if current group already has role assigned, if not add it
// 7 TRUE	          FALSE	          TRUE        	  See if current group has any other PCI/PII/SOX apps, if not remove role
// 8 TRUE	          FALSE	          FALSE	          No action needed

(function executeRule(current, previous /*null when async*/) {
	gs.addInfoMessage('u_Set_PCI_PII_SOX_Sup_Grp_Upd fired for ' + current.u_long_name);
    var utils = new u_PciPiiSoxSupGrpUtils();

    var now = current.u_pci || current.u_pii || current.u_soc1 || current.u_soc1_bank || current.u_sox;
    var then = previous.u_pci || previous.u_pii || previous.u_soc1 || previous.u_soc1_bank || previous.u_sox;
    var sameGrp = current.support_group == previous.support_group;

    gs.addInfoMessage('same group: ' + sameGrp + ', then = ' + then + ', now = ' + now);

    if (!now && !then) {  // 4 & 8
        gs.addInfoMessage('still not pci/pii/sox - no change needed');
        return;
    }
    if (sameGrp) {
        if (now && then) {  // 5
            gs.addInfoMessage('same group and still pci/pii/sox - no change needed');
        } else if (now) {  // 6
            if (!current.support_group.nil()) {
                gs.addInfoMessage('same group and now pci/pii/sox - add role if needed');
                utils.addRoleToGrp(current.support_group);
            } else {
                gs.addInfoMessage('current group is empty - no add action needed');
            }
        } else if (then) {  // 7
            if (!current.support_group.nil()) {
                gs.addInfoMessage('same group and no longer pci/pii/sox - remove role if needed');
                utils.remRoleFromGrp(current.support_group);
            } else {
                gs.addInfoMessage('current group is empty - no remove action needed');
            }
        }
    } else {
        if (now && then) {  // 1
            gs.addInfoMessage('diff group and still pci/pii/sox - add & remove role as needed');
            if (!current.support_group.nil()) {
                utils.addRoleToGrp(current.support_group);
            } else {
                gs.addInfoMessage('current group is empty - no add action needed');
            }
            if (!previous.support_group.nil()) {
                utils.remRoleFromGrp(previous.support_group);
            } else {
                gs.addInfoMessage('previous group is empty - no remove action needed');
            }
        } else if (now) {  // 2
            gs.addInfoMessage('diff group and now pci/pii/sox - add role if needed');
            if (!current.support_group.nil()) {
                utils.addRoleToGrp(current.support_group);
            } else {
                gs.addInfoMessage('current group is empty - no add action needed');
            }
        } else if (then) {  // 3
            gs.addInfoMessage('diff group and no longer pci/pii/sox - remove role if needed');
            if (!previous.support_group.nil()) {
                utils.remRoleFromGrp(previous.support_group);
            } else {
                gs.addInfoMessage('previous group is empty - no remove action needed');
            }
        }
    }
})(current, previous);
