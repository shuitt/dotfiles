(function processEvent(event) {
	// event.parm1 is the server name
	// event.parm2 is the support group sys_id
	gs.log('u_server_supp_grp_chgd 1: server is ' + event.parm1 + ' , group is ' + event.parm2);
	var utils = new u_ServerTaggingUtils();
	var sid = utils.findServerCI(event.parm1);
	gs.log('u_server_supp_grp_chgd 2: server ' + event.parm1 + ' sys_id is ' + sid);
	sid = utils.updCiSupp_grp(sid, event.parm2);
	gs.log('u_server_supp_grp_chgd 3: updated server ' + event.parm1 + ' sys_id is ' + sid);
	if (sid != null) {
		gs.log('u_server_supp_grp_chgd 4: server ' + event.parm1 + ': update hosted CIs');
		utils.updHostedCisSupp_grps(sid, event.parm2);

		// see if server is a cluster node, if so update cluster node support group
		gs.log('u_server_supp_grp_chgd 5: server '  + event.parm1 + ', update associated cluster node CI');
		var node_id = utils.updateClNodeCi(sid, event.parm2);
		if (JSUtil.notNil(node_id)) {
			// see if server related to any cluster resource, if so update their
			// cluster resource support group
			gs.log('u_server_supp_grp_chgd 6: server: ' + event.parm1 + 'update associated cluster resource CIs');
			utils.updateClResCi(node_id, event.parm2);
		} else {
			gs.log('u_server_supp_grp_chgd: server 7: ' + event.parm1 + 'no associated cluster node CI');
		}
	}
	//gs.log('u_server_supp_grp_chgd: all done');
})(event);
