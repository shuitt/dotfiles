(function(){
    //var policy = '{"escalation_policy":{"id":"PYCDPOG","type":"escalation_policy","summary":"Steve Test Escalation Policy","self":"https://api.pagerduty.com/escalation_policies/PYCDPOG","html_url":"https://nordstrom.pagerduty.com/escalation_policies/PYCDPOG","name":"Steve Test Escalation Policy","escalation_rules":[{"id":"PPOABTM","escalation_delay_in_minutes":30,"targets":[{"id":"PJTU43M","type":"schedule_reference","summary":"Steve Test 1st On-call","self":"https://api.pagerduty.com/schedules/PJTU43M","html_url":"https://nordstrom.pagerduty.com/schedules/PJTU43M"}]},{"id":"PVD1XZ8","escalation_delay_in_minutes":30,"targets":[{"id":"PPW7BH3","type":"schedule_reference","summary":"Steve Test 2nd On-call","self":"https://api.pagerduty.com/schedules/PPW7BH3","html_url":"https://nordstrom.pagerduty.com/schedules/PPW7BH3"},{"id":"P2SB6GK","type":"user_reference","summary":"Steve Huitt","self":"https://api.pagerduty.com/users/P2SB6GK","html_url":"https://nordstrom.pagerduty.com/users/P2SB6GK"}]},{"id":"P8S05PM","escalation_delay_in_minutes":30,"targets":[{"id":"P63YB8B","type":"user_reference","summary":"Steve4 Test Huitt","self":"https://api.pagerduty.com/users/P63YB8B","html_url":"https://nordstrom.pagerduty.com/users/P63YB8B"},{"id":"P2SB6GK","type":"user_reference","summary":"Steve Huitt","self":"https://api.pagerduty.com/users/P2SB6GK","html_url":"https://nordstrom.pagerduty.com/users/P2SB6GK"}]},{"id":"P35N3P9","escalation_delay_in_minutes":30,"targets":[{"id":"P2SB6GK","type":"user_reference","summary":"Steve Huitt","self":"https://api.pagerduty.com/users/P2SB6GK","html_url":"https://nordstrom.pagerduty.com/users/P2SB6GK"}]}],"services":[{"id":"PXXG3GF","type":"service_reference","summary":"Steve Test Service","self":"https://api.pagerduty.com/services/PXXG3GF","html_url":"https://nordstrom.pagerduty.com/services/PXXG3GF"}],"num_loops":0,"teams":[{"id":"P88GC8I","type":"team_reference","summary":"Steve Test Team","self":"https://api.pagerduty.com/teams/P88GC8I","html_url":"https://nordstrom.pagerduty.com/teams/P88GC8I"}],"description":"","privilege":null}}';
    var policy = '{"escalation_policy":{"id":"PYCDPOG","type":"escalation_policy","summary":"Steve Test Escalation Policy","self":"https://api.pagerduty.com/escalation_policies/PYCDPOG","html_url":"https://nordstrom.pagerduty.com/escalation_policies/PYCDPOG","name":"Steve Test Escalation Policy","escalation_rules":[{"id":"PVD1XZ8","escalation_delay_in_minutes":30,"targets":[{"id":"P2SB6GK","type":"user_reference","summary":"Steve Huitt","self":"https://api.pagerduty.com/users/P2SB6GK","html_url":"https://nordstrom.pagerduty.com/users/P2SB6GK"}]},{"id":"P8S05PM","escalation_delay_in_minutes":30,"targets":[{"id":"P2SB6GK","type":"user_reference","summary":"Steve Huitt","self":"https://api.pagerduty.com/users/P2SB6GK","html_url":"https://nordstrom.pagerduty.com/users/P2SB6GK"}]},{"id":"P35N3P9","escalation_delay_in_minutes":30,"targets":[{"id":"P2SB6GK","type":"user_reference","summary":"Steve Huitt","self":"https://api.pagerduty.com/users/P2SB6GK","html_url":"https://nordstrom.pagerduty.com/users/P2SB6GK"}]}],"services":[{"id":"PXXG3GF","type":"service_reference","summary":"Steve Test Service","self":"https://api.pagerduty.com/services/PXXG3GF","html_url":"https://nordstrom.pagerduty.com/services/PXXG3GF"}],"num_loops":0,"teams":[{"id":"P88GC8I","type":"team_reference","summary":"Steve Test Team","self":"https://api.pagerduty.com/teams/P88GC8I","html_url":"https://nordstrom.pagerduty.com/teams/P88GC8I"}],"description":"","privilege":null}}';

    var body = JSON.parse(policy);
    //var user = 'P2SB6GK';
    var user = 'P2SB6GK';
    var new_policy = updateEscalationRules(body, user);
    gs.print('new policy: ' + new_policy);

    function updateEscalationRules(body, user) {
        gs.print('name: ' + body.escalation_policy.name + ', id: ' + body.escalation_policy.id);
        var new_rules = processRules(body.escalation_policy.escalation_rules, user);
        gs.print('new rules: ' + JSON.stringify(new_rules));
        body.escalation_policy.escalation_rules = new_rules;
        return JSON.stringify(body);
    }

    function processRules(rules, user) {
        var new_rules = [];
        for (var i = 0; i < rules.length; i++) {
            gs.print('rule id: ' + rules[i].id);
            var new_targets = processTargets(rules[i].targets, user);
            if (new_targets.length > 0) {
                rules[i].targets = new_targets;
                new_rules.push(rules[i]);
            }
        }
        return new_rules;
    }

    function processTargets(targets, user) {
        gs.print('number of targets: ' + targets.length);
        var new_targets = [];
        for (var i = 0; i < targets.length; i++) {
            var new_item = processTargetItem(targets[i], user);
            if (!gs.nil(new_item)) {
                new_targets.push(new_item);
            }
        }
        if (new_targets.length == 0) {
            //var replacement = findReplacement(user);
            new_targets.push({"id": "REPLACE", "type": "user_reference"});
        }
        return new_targets;
    }

    function processTargetItem(item, user) {
        gs.print('looking for user id: ' + user);
        gs.print('item id: ' + item.id + ', type: ' + item.type + ', summary: ' + item.summary);
        if (item.type == 'user_reference' && item.id == user) {
            gs.print('found a match');
            return null;
        }
        return item;
    }
}())
