(function executeRule(current, previous /*null when async*/) {
    var nord_all = 'Nordstrom - All';
    var grp_id = null;

    var gr_grp =  new GlideRecord ('sys_user_group');
    gr_grp.addQuery('name', nord_all);
    gr_grp.query();
    if (gr_grp.next()) {
        grp_id = gr_grp.getUniqueValue();
        var gr_mbr = new GlideRecord ('sys_user_grmember');
        gr_mbr.addQuery('group', grp_id);
        gr_mbr.addQuery('user', current.sys_id);
        if (!gr_mbr.next()) {
            gr_mbr.newRecord();
            gr_mbr.group = grp_id;
            gr_mbr.user = current.sys_id;
            gr_mbr.insert();
        }
    }
})(current, previous);
