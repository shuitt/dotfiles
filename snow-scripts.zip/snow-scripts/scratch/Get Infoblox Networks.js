(function(){
    var start = new GlideDateTime();
    gs.print('---> Get Infoblox Neworks: start time: ' + start.getValue());

    var cUtils = new CidrUtil();
    var more = true;
    var get_next = false;
    var next_page = null;
    var gr = new GlideRecord('u_discovery_ip_range_steve');

    while (more) {
        var response = null;
        try {
            var restMessage = new sn_ws.RESTMessageV2('Infoblox Networks', 'GET');
            if (get_next) {
                restMessage.setQueryParameter('_page_id', next_page);
            }
            response = restMessage.execute();
        } catch(ex) {
            gs.print('---> Get Infoblox Neworks: exception: ' + ex.getMessage());
            return;
        }

        if (response == null) {
            gs.print('---> Get Infoblox Neworks: response is null - exiting');
            return;
        }

        if (response.haveError()) {
            gs.print('---> Get Infoblox Neworks: API error:\nError code: ' + response.getErrorCode() +
                      ', error message: ' + response.getErrorMessage());
            //return;
        }

        var httpStatus = response.getStatusCode();
        gs.print('---> Get Infoblox Neworks: response code = ' + response.getStatusCode());
        var parsed = JSON.parse(response.getBody());
        gs.print('---> Get Infoblox Neworks: parsed.result.length = ' + parsed.result.length);
        if (!gs.nil(parsed.next_page_id)) {
            //gs.print('---> Get Infoblox Neworks: next_page_id = ' + parsed.next_page_id);
            next_page = parsed.next_page_id;
            get_next = true;

        } else {
            gs.print('---> Get Infoblox Neworks: no next page');
            more = false;
        }

        for (var i = 0; i < parsed.result.length; i++) {
            var n = parsed.result[i].network.split('/');
            var loc = parsed.result[i].extattrs["Location ID"].value;
            gr.newRecord();
            gr.name = parsed.result[i].network;
            gr.type = 'IP Network';
            gr.network_ip = n[0];
            gr.netmask = n[1];
            gr.u_location = loc.replace(/^(0+)/g, '');
            gr.u_cidr_lookup = cUtils.IPnumber(n[0]);
            var id = gr.update();
            if (!gs.nil(id)) {
                //gs.print('---> Get Infoblox Neworks: update successful');
            } else {
                gs.print('---> Get Infoblox Neworks: update failed');
            }
        }
        //more = false;
    }
    // get ending date and time and compute and display duration

    var stop = new GlideDateTime();
    gs.print('---> Get Infoblox Neworks: end time: ' + stop.getValue());
    var dur = GlideDateTime.subtract(start, stop); //the difference between gdt1 and gdt2
    gs.print('---> Get Infoblox Neworks: script duration: ' + dur.getByFormat('HH:mm:ss'));
}())
