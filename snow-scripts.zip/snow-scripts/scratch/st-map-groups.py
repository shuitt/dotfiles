#!/usr/bin/env python3

import csv

IN_GRP_MAP = '/Users/xsmh/Downloads/server_tagging_groups_xpjc.txt'
IN_SYSID_MAP = '/Users/xsmh/Downloads/sn-groups-with-sys_ids.txt'
IN_ST = '/Users/xsmh/Downloads/Server Tagging.txt'
OUT_ST = '/Users/xsmh/Downloads/Server Tagging Updated.txt'

grp_dict = {}
sysid_dict = {}

#------------------------------------------------------------------------------
# read a tsv file into a list
#------------------------------------------------------------------------------
def getListTsv(file_name):
    print('Reading TSV file', file_name)
    with open(file_name, 'r') as f:
        reader = csv.reader(f, dialect="excel-tab")
        the_list = list(reader)
    f.close()
    print('%d rows read from CSV file' % len (the_list))
    return the_list

#------------------------------------------------------------------------------
# create a dictionary of es groups to sn groups
# params: group_list - list with group info
#------------------------------------------------------------------------------
def makeGrpMap(group_list):
    del group_list[0]
    for grp in group_list:
        grp_dict[grp[0]] = grp[1] # map esmart group to sn group
    print("%d mapped esmart groups loaded" % len(grp_dict))
    #for k, v in grp_dict.items():
    #    print(k + ' => ' + v)

#------------------------------------------------------------------------------
# create a dictionary of es groups to sn groups
# params: sysid_list - list with group info
#------------------------------------------------------------------------------
def makeSysidMap(sysid_list):
    del sysid_list[0]
    for grp in sysid_list:
        sysid_dict[grp[0]] = grp[1] # map to sn group to its sys_id
    print("%d mapped sn groups with sys_ids loaded" % len (sysid_dict))
    #for k, v in sysid_dict.items():
    #    print(k + ' => ' + v)

#------------------------------------------------------------------------------
# create a new server tagging csv file with sn groups replacing esmart groups
# params: job_list - list with job info
#------------------------------------------------------------------------------
def makeTaggingTsv(st_list, out_file):
    print('Output tagging file is ' + out_file)
    missing_grps = []
    header = ['Server Name', 'On Call Group Name', 'Environment', 'Sys_id']
    del st_list[0]
    server_count = 0
    with open(out_file, 'w', newline='') as f:
        writer = csv.writer(f, dialect="excel-tab")
        writer.writerow(header)
        for server in st_list:
            out_row = [''] * len(header)
            out_row[0] = server[0]      # server name
            if server[1] in grp_dict:   # es group map exists`
                out_row[1] = grp_dict[server[1]]  # sn group
                out_row[3] = sysid_dict[out_row[1]]  # sn group sys_id
            else:
                if not server[1] in missing_grps:
                    missing_grps.append(server[1])
            if server[2] == 'Production':   # environment
                out_row[2] = server[2]
            else:
                out_row[2] = 'Test'
            writer.writerow(out_row)
            server_count += 1
    print('%d user rows written' % server_count)
    print('eSmart groups with no SN group:')
    for grp in missing_grps:
        print('\t' + grp)
    f.close()

#-----------------------------------------------------------------------------
# main program logic
#------------------------------------------------------------------------------
if __name__ == '__main__':
    print('Script staring')
    group_list = getListTsv(IN_GRP_MAP)
    makeGrpMap(group_list)
    sysid_list = getListTsv(IN_SYSID_MAP)
    makeSysidMap(sysid_list)
    st_list = getListTsv(IN_ST)
    makeTaggingTsv(st_list, OUT_ST)
    print('Script completed')
