(function(){
    var utils = new u_Slack_Integration();

    // test formatDateTime
    var dt = utils.formatDateTime();
    gs.print('formatDateTime result: ' + dt);

    // test formatMessage
    var gr = new GlideRecord('sys_remote_update_set');
    gr.get('5101f6e0dbe507c8219074b5ae9619ce'); //SMP-1016 SVC Create SC item for C310
    var msg = utils.formatMessage(gr, 'loaded');
    gs.print('formatMessage result: ' + msg);

    // test sendHookMessage
    var result = utils.sendHookMessage('Ignore this test message', 'SMP');
    gs.print('sendHookMessage result (SMP): ' + result);
    result = utils.sendHookMessage('Ignore this test message', 'SIR');
    gs.print('sendHookMessage result (SIR): ' + result);
}())
