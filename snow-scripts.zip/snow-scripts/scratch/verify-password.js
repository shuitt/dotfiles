(function(){
    function validatePwd(pwd) {
        var has_digit   = RegExp('[0-9]');
        var has_upper   = RegExp('[A-Z]');
        var has_lower   = RegExp('[a-z]');
        var has_special = RegExp('[^a-zA-Z0-9]');
        var has_space   = RegExp('[ ]');
        var valid = (pwd.p.length > 11) &&
                     has_digit.test(pwd.p) &&
                     has_upper.test(pwd.p) &&
                     has_lower.test(pwd.p) &&
                     has_special.test(pwd.p) &&
                     !has_space.test(pwd.p);
        gs.print('Password: ' + pwd.p + ', Test: ' + pwd.s +
                 '\n\tLength: ' + (pwd.p.length > 11) +
                 '\n\tDigit: ' + has_digit.test(pwd.p) +
                 '\n\tUpper: ' + has_upper.test(pwd.p) +
                 '\n\tLower: ' + has_lower.test(pwd.p) +
                 '\n\tSpecial: ' + has_special.test(pwd.p) +
                 '\n\tSpace: ' + !has_space.test(pwd.p) +
                 '\n\tValid: ' + valid + '\n');
    }

    function validatePwd2(pwd) {
        // this does not catch strings starting with a space
        var pat = RegExp('^(.{0,11}|[^0-9]*|[^A-Z]*|[^a-z]*|[a-zA-Z0-9]*|.*[^ ]*\s.*)$');
        gs.print('\nPassword: ' + pwd.p + '\nTest: ' + pwd.s + '\nValid: ' + !pat.test(pwd.p) + '\n');
    }

    var pswds = [
        {p: 'abc123EFG$000000', s: 'ok length > 12'},
        {p: 'abc123EFG$12', s: 'ok length 12, start with lower'},
        {p: 'Abc123EFG$12', s: 'ok length 12, start with upper'},
        {p: '0bc123EFG$12', s: 'ok length 12, start with digit'},
        {p: '#bc123EFG$12', s: 'ok length 12, start with special'},
        {p: '1bA$', s: 'short'},
        {p: '1bA$1234567', s: 'short length = 11'},
        {p: 'sdckhLIUGLUG**^^$#', s: 'no digit'},
        {p: 'sddckhsdl9813471734$', s: 'no upper'},
        {p: 'KJSXJGKHJ76`5238$$#', s: 'no lower'},
        {p: 'sdkjhsdk1234274JGLUG', s: 'no special'},
        {p: 'sdkjnJGKJH980$$ llk', s: 'has space'},
        {p: ' dkjnJGKJH980$$llk', s: 'starts with space'},
        {p: '123456789012', s: 'no upper, no lower, no special'},
        {p: 'ABCDEFGHIJKLMN', s: 'no digit, no lower, no special'},
        {p: 'abcdefghijklmn', s: 'no digit, no upper, no special'},
        {p: '$$##@@!!&&^^%%', s: 'no digit, no lower, no upper'}
    ];

    for (var i = 0; i < pswds.length; i++) {
        validatePwd(pswds[i]);
        //validatePwd2(pswds[i]);
    }
}())
