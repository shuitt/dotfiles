(function(){
    var strings = ['all lower case',
                    'ALL UPPER CASE',
                    'MixEd Case iN this onE',
                    'special char/symbols here',
                    'askjasx / asiaslk'
    ];
    var zips = ['1', '22', '333', '4444', '55555',
                '666666', '7777777', '88888888', '999999999'
    ];
    var phones = ['1234567', '1234567890',
                  '666666', '88888888'
    ];
    var utils = new u_Nord_StrFormatUtils();
    var i = null;
    var f = null;

    gs.print('---------- Test toTitleCase()\n');
    for (i = 0; i < strings.length; i++) {
        f = utils.toTitleCase(strings[i]);
        gs.print('In: ' + strings[i] + ', Out: ' + f);
    }

    gs.print('---------- Test formatZip()\n');
    for (i = 0; i < zips.length; i++) {
        f = utils.formatZip(zips[i]);
        gs.print('In: ' + zips[i] + ', Out: ' + f);
    }

    gs.print('---------- Test formatPhone()\n');
    for (i = 0; i < phones.length; i++) {
        f = utils.formatPhone(phones[i]);
        gs.print('In: ' + phones[i] + ', Out: ' + f);
    }

    gs.print('---------- Test generateIdString()\n');
    for (i = 0; i < 4; i++) {
        gs.print('UUID: ' + utils.generateIdString());
    }
}())
