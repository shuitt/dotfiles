(function(){
    function insertServiceAccount(user) {
        var svcacct = new GlideRecord('u_service_account');
        svcacct.newRecord();
        svcacct.u_creating_request = user.u_service_account_request;
    	svcacct.u_owning_group.setDisplayValue(user.u_service_account_owner);
    	svcacct.u_retired = false;
    	svcacct.u_service_account_created = user.sys_created_on;
    	svcacct.u_service_account_user = user.sys_id;
    	svcacct.u_user_id = user.user_name;
    	return svcacct.insert();
    }

    function insertAudit(svc_acct_id, request) {
        var audit = new GlideRecord('u_service_account_audit');
        audit.newRecord();
        audit.u_action = 'create';
		audit.u_request = request;
		audit.u_service_account = svc_acct_id;
		return audit.insert();
    }

    var gr = new GlideRecord('sys_user');
    //gr.addEncodedQuery('web_service_access_only=true^user_nameSTARTSWITHapi^u_service_account_ownerISNOTEMPTY');
    gr.addEncodedQuery('web_service_access_only=true');
    gr.orderBy('user_name');
    //gr.setLimit(4);
    gr.query();
    while (gr.next()) {
        //gs.print('Processing service account: ' + gr.user_name);
        var id = insertServiceAccount(gr);
        insertAudit(id, gr.u_service_account_request);
    }
}())


(function(){
    var svcacct = new GlideRecord('u_service_account');
    svcacct.query();
    while (svcacct.next()) {
        svcacct.u_service_account_user = svcacct.u_service_account;
        svcacct.update();
    }
}())

(function(){
    gs.print('script starting...');
    var gr = new GlideRecord('sys_user');
    var svcacct = new GlideRecord('u_service_account');
    gr.addEncodedQuery('web_service_access_only=true');
    gr.orderBy('user_name');
    gr.query();
    gs.print('updating ' + gr.getRowCount() + ' users');
    while (gr.next()) {
        svcacct.initialize();
        svcacct.addQuery('u_user_id', gr.user_name);
        svcacct.query();
        if (svcacct.next()) {
            gr.u_service_account = svcacct.sys_id;
            gr.update();
        }
    }
    gs.print('done');
}())
