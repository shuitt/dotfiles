(function(){
    // switch location based assignment form regional it to unisys dispatch queue
    var loc_list = [
        '831', '833', '834', '835', '841', '843', '844', '845', '859'
    ];

    gs.print('number of locations: ' + loc_list.length);
    var query = 'u_assignment_group.nameSTARTSWITHregional it^u_location.u_store_number=';
    var unisys_disp_q = '0aebcaf8db3c2bc0cdf5f8fdae961974';
    var sd_unisys = 'a9a4c584db5a2b887d40499e0b961923';

    var gr = new GlideRecord('u_assignment_routing_details');
    for (var i = 0; i < loc_list.length; i++) {
    //for (var i = 0; i < 2; i++) {
        //gs.print('Store: ' + loc_list[i]);
        gr.initialize();
        gr.addEncodedQuery(query + loc_list[i]);
        gr.query();
        while (gr.next()) {
            //gs.print('\tUpdate to Unisys Dispatch Queue: ' + gr.u_location.name);
            //gr.u_assignment_group.setValue(unisys_disp_q);
            gr.u_assignment_group.setValue(sd_unisys);
            gr.setWorkflow(false);
            gs.autoSysFields(false);
            gr.update();
        }
    }
}())


(function(){
    // switch all assignments to unisys dispatch queue to service desk - unisys
    var sd_unisys = 'a9a4c584db5a2b887d40499e0b961923';
    var query = 'u_assignment_group=0aebcaf8db3c2bc0cdf5f8fdae961974';
    var count = 0;
    var gr = new GlideRecord('u_assignment_routing_details');
    gr.addEncodedQuery(query);
    gr.orderBy('u_location');
    //gr.setLimit(2);
    gr.query();
    gs.print('Records found: ' + gr.getRowCount());
    while (gr.next()) {
        count++;
        //gs.print('Updating location ' + gr.u_location.name);
        gr.u_assignment_group.setValue(sd_unisys);
        gr.setWorkflow(false);
        gs.autoSysFields(false);
        gr.update();
    }
    gs.print('Records updated: ' + count);
}())
