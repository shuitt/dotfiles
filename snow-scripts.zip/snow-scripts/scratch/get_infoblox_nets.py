#!/usr/bin/env python3

import os
import requests
import json
import getpass
import csv

# get exec info
def getExecInfo():
    user = input('User ID: ')
    pswd = getpass.getpass()
    out_file = input('Output file name: ')
    max = input('Max networks per call: ')
    all = input('Get all networks? (y/N): ')
    all_nets = all.lower == 'y'
    return (user, pswd, out_file, max, all_nets)

# get the networks
def getNetworks(user, pswd, out_file, max, all_nets):
    BASEURL = 'https://dnsmgmt1.0319.datacenter.nordstrom.net/wapi/v2.7.1/network?_return_as_object=1&_paging=1&_return_fields=network,extattrs&*Location+ID~=^[0-9]&_max_results=' + str(max)
    url = BASEURL
    NEXT = '&_page_id='
    HEADERS = {"Accept":"application/json"}

    more_nets = True
    net_list = []

    print('Getting ' + str(max) + ' networks per API call')
    if all_nets:
        print('Retrieving all networks with a Location ID')
    else:
        print('Rtrieving only ' + str(max) + ' networks')

    # Do the HTTP request(s)
    while more_nets:
        requests.packages.urllib3.disable_warnings()
        response = requests.get(url, auth=(user, pswd), headers=HEADERS, verify=False)

        # Check for HTTP codes other than 200
        if response.status_code != 200:
            print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:', response.text)
            exit()

        # Decode the JSON response into a dictionary and use the data
        data = json.loads(response.text)
        networks = data['result']

        for net in networks:
            if 'Location ID' in net['extattrs']:
                net_list.append([net['network'], net['extattrs']['Location ID']['value']])
            else:
                net_list.append(net['network'], 'No Location ID')

        if all_nets:
            if 'next_page_id' in data:
                url = BASEURL + NEXT + data['next_page_id']
            else:
                more_nets = False
        else:
            more_nets = False

    # return the list of networks
    print('Found ' + str(len(net_list)) + ' networks')
    return net_list

# write the networks to a csv file
def makeCsv(net_list, out_file):
    print('Writing networks to CSV file: ' + out_file)
    with open(out_file, 'w', newline='') as f:
        out_row = ['Network', 'Location ID']
        writer = csv.writer(f)
        writer.writerow(out_row)
        for in_row in net_list:
            out_row[0] = in_row[0]              # network
            out_row[1] = in_row[1]              # location id
            writer.writerow(out_row)
    f.close()

if __name__ == '__main__':
    print('Script staring')
    (user, pswd, out_file, max, all_nets) = getExecInfo()
    net_list = getNetworks(user, pswd, out_file, max, all_nets)
    makeCsv(net_list, out_file)
    print('Script finished')
