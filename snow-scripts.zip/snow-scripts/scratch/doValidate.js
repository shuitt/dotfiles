function doValidate() {
    // called when the 'OK' dialog button is clicked

    // clear any info or error messages
	g_form.clearMessages();

	// validate employee number and last four fields
	if (!empNbrOk(gel("employee_number").value)) {
		return false;
	}
	if (!last4Ok(gel("last_four").value)) {
		return false;
	}

    // input is ok - call u_Validate_Caller script include to perform validation
    var val = new GlideAjax('u_Validate_Caller');
    val.addParam('sysparm_name', 'doValidation');
    val.addParam('sysparm_empNbr', gel("employee_number").value);
    val.addParam('sysparm_last4', gel("last_four").value);
    val.getXML(showResult);

	// destroy the pop-up window
    GlideDialogWindow.get().destroy(); //Close the dialog window
}

function empNbrOk(empNbr) {
    var re = /^\d+$/;
    val = trim(empNbr);
    if (val == "") {
        g_form.addErrorMessage("Please provide an employee number to validate the caller.");
        return false;
    }
    if (empNbr.match(re) == null) {
        g_form.addErrorMessage("Employee number must be numeric.");
        return false;
    }
    return true;
}

function last4Ok(last4) {
    var re = /^\d+$/;
    val = trim(last4);
    if (val == "") {
        g_form.addErrorMessage("Please provide the last four digts of national identifier to validate the caller.");
        return false;
    }
    if (last4.match(re) == null) {
        g_form.addErrorMessage("The last four digts of national identifier must be numeric.");
        return false;
    }
    if (last4.length != 4) {
        g_form.addErrorMessage("Must provide exactly four digts of national identifier.");
        return false;
    }
    return true;
}

function showResult(response) {
	// called when the u_Validate_Caller script include completes
    var answer = response.responseXML.documentElement.getAttribute("answer");

	// get the result code and msg
    answer = answer.evalJSON();
    var code = answer.code;
    var msg = answer.msg;

    if (code == 'TRUE') {
		g_form.addInfoMessage(msg);
    } else if (code == 'FALSE') {
		g_form.addErrorMessage(msg);
	} else {
		g_form.addErrorMessage(msg);
	}
}
