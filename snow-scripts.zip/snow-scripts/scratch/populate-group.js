(function(){
	function assignGroup(table, type, locs) {
		// sysid of 'Platform Engineering - Network' - will be different on each instance!!
		var nsgGroupId = 'fbe773f6db5d7200cdf5f8fdae9619b5';
		var gr = new GlideRecord(table);
		gr.addEncodedQuery('support_group=false^ORsupport_groupISEMPTY');
		gr.query();
		gs.print('Found ' + gr.getRowCount() + ' ' + type + ' devices without support group');
		while (gr.next()) {
			if (locs[gr.location] != '' && locs[gr.location] != null) {
				gr.support_group = locs[gr.location];
			} else {
				gr.support_group = nsgGroupId;
			}
			gr.update();
			break;
		}
	}

	function getLocGroups() {
		var locs = {};
		var gr = new GlideRecord('u_assignment_routing_details');
		gr.query();
		while (gr.next()) {
			if (!locs.hasOwnProperty(gr.u_location)) {
				locs[gr.u_location] = gr.u_assignment_group.sys_id;
			}
		}
		return locs;
	}

	// create a dictionary of locations and support groups
	var loc2Group = getLocGroups();

	assignGroup('cmdb_ci_ip_switch', 'IP Switch', loc2Group); 		// IP Switch table
	assignGroup('cmdb_ci_ip_router', 'IP Router', loc2Group); 		// IP router table
	assignGroup('u_cmdb_ci_wireless_controller', 'Wireless Controller', loc2Group); 	// wireless controller table
	assignGroup('cmdb_ci_wap_network', 'Wireless APs', loc2Group);	// wireless ap table
}())
