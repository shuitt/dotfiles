(function () {
    var gr = new GlideRecord('incident');
    gr.addQuery('cmdb_ci', '23e6a7f3dbd3aa00cdf5f8fdae96191c');
    gr.query();
    gs.print('rows found: ' + gr.getRowCount());
    gr.setValue('cmdb_ci',  gs.getProperty('nordstrom.notlisted.ci'));
    gr.setWorkflow(false);
    gr.autoSysFields(false);
    gr.updateMultiple();
})();
