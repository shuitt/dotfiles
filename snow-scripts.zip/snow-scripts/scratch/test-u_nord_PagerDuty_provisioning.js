(function(){
    function showResult(result) {
        for (var key in result) {
            if (typeof(result[key]) == 'object') {
                gs.print('showResult: result.' + key + " = " + JSON.stringify(result[key]));
            } else {
                gs.print('\nshowResult: result.' + key + " = " + result[key]);
            }
        }
    }
    var result = {};
    var req = null;
    var utils = new u_nord_PagerDuty_provisioning();
    var user = 'PC58PFH';
    var policy = 'PYCDPOG';
    var sched = 'PPW7BH3';


    //result = utils.addAccess('steve2 Huitt', 'xsmh@nordstrom.com');
    //result = utils.removeAccess('P2SB6GK');

    // test updating a schedule

    result = utils.getSchedule(sched);
    gs.print('result from getting schedule ' + sched);
    showResult(result);

    req = utils.updateOncallSchedule(result.body, user);
    gs.print('\nupdated schedule: ' + req);
    result = utils.updateSchedule(sched, req);
    showResult(result);

    // test updating an escalation policy
/*
    result = utils.getEscalationPolicy(policy);
    gs.print('\nresult from getting escalation policy ' + policy);
    showResult(result);

    req = utils.updateEscalationRules(result.body, user);
    gs.print('\nupdated policy: ' + req);
    result = utils.updateEscalationPolicy(policy, req)
    showResult(result);
*/
}())
