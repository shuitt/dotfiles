(function executeRule(current, previous /*null when async*/) {
	if (current.u_wireless_controller != null) {
		current.location = current.u_wireless_controller.location;
		current.support_group = current.u_wireless_controller.support_group;
	} else {
		var ciUtils = new u_CiOwnerUtils();
		current.support_group = ciUtils.getNsgGroup();
	}
})(current, previous);
