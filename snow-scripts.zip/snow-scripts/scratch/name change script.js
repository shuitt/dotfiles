(function(){
    var gr = new GlideRecord('sys_user');
    gr.addNotNullQuery('u_preferred_name');
    gr.query();
    gs.info('Number of users with a preferred name: ' + gr.getRowCount());
    var i = 0;
    while (gr.next()) {
        gr.name = gr.u_preferred_name + ' ' + gr.last_name;
        gr.u_transposed_name = gr.last_name + ' ' + gr.u_preferred_name;
        //gr.update('Use preferred name instead of first name');
        i = i + 1;
    }
	gs.info('Updated user records: ' + i);
}())
