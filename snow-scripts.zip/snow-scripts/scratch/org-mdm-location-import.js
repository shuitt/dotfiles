(function(){
    var utils = new u_Nord_Org_MDM_utils(true);  // argument turns logging on or off

    // result is an object:
    // {'status': <http status code>,
    //  'body': <response body as string>,
    //  'success': [true|false] }
    var result = utils.callApi();
    if (!result.success) {
        utils.writeErrorLog('Terminating job due to API error');
    }

    var locs = JSON.parse(result.body);
    if (locs.stores.length < 1) {
        utils.writeErrorLog('The response stores array is empty');
        return;
    }

    // create a new import set
    utils.writeLog('There are ' + locs.stores.length + ' locations in the reponse');
    var table = 'u_org_mdm_location_import';     //import set table name
    impset = utils.getImpSet(table);
    var gr = new GlideRecord(table);

    // process result inserting into import set table
    for (var i = 0; i < locs.stores.length; i++) {
		var text = 'Location properties:';
        gr.initialize();
        gr.u_store_number = locs.stores[i].storeNumber;
        gr.u_name = locs.stores[i].storeNumber + ' ' + locs.stores[i].name;
        gr.u_full_name = locs.stores[i].storeNumber + ' ' + locs.stores[i].name;
        if (!gs.nil(locs.stores[i].adminHier.buDesc)) { // location type
            gr.u_location_type = locs.stores[i].adminHier.buDesc;
            text += '\nLocation type: ' +  locs.stores[i].adminHier.buDesc;
        }
        if (!gs.nil(locs.stores[i].adminHier.regionDesc)) { // store region
            gr.u_store_region = locs.stores[i].adminHier.regionDesc;
            text += '\nRegion: ' + locs.stores[i].adminHier.regionDesc;
        }
        if (!gs.nil(locs.stores[i].isStoreOperationalToPublic)) { // active
            gr.u_active = locs.stores[i].isStoreOperationalToPublic;
            text += '\nActive: ' + locs.stores[i].isStoreOperationalToPublic;
        }
        if (!gs.nil(locs.stores[i].telephone.externalTelephoneNumber)) { // phone
            gr.u_phone = locs.stores[i].telephone.externalTelephoneNumber;
            text += '\nPhone:  ' + locs.stores[i].telephone.externalTelephoneNumber;
        }
        if (!gs.nil(locs.stores[i].postalAddress.stdzdLine1Text)) { // street
            gr.u_street = locs.stores[i].postalAddress.stdzdLine1Text;
            text += '\nStreet: ' + locs.stores[i].postalAddress.stdzdLine1Text;
        } else if (!gs.nil(locs.stores[i].displayAddress.line1Text)) {
            gr.u_street = locs.stores[i].displayAddress.line1Text;
            text += '\nStreet: ' + locs.stores[i].displayAddress.line1Text;
        }
        if (!gs.nil(locs.stores[i].postalAddress.stdzdCityName)) { // city
            gr.u_city = locs.stores[i].postalAddress.stdzdCityName;
            text += '\nCity: ' + locs.stores[i].postalAddress.stdzdCityName;
        } else if (!gs.nil(locs.stores[i].displayAddress.cityName)) {
            gr.u_city = locs.stores[i].displayAddress.cityName;
            text += '\nCity: ' + locs.stores[i].displayAddress.cityName;
        }
        if (!gs.nil(locs.stores[i].postalAddress.origStateCode)) { // state or province
            gr.u_state_or_province = locs.stores[i].postalAddress.origStateCode;
            text += '\nState: ' + locs.stores[i].postalAddress.origStateCode;
        } else if (!gs.nil(locs.stores[i].displayAddress.stateCode)) {
            gr.u_state_or_province = locs.stores[i].displayAddress.stateCode;
            text += '\nState: ' + locs.stores[i].displayAddress.stateCode;
        }
        if (!gs.nil(locs.stores[i].postalAddress.origCountryIsoCode)) { // country
            gr.u_country = locs.stores[i].postalAddress.origCountryIsoCode;
            text += '\nCountry: ' + locs.stores[i].postalAddress.origCountryIsoCode;
        }
        if (!gs.nil(locs.stores[i].postalAddress.stdzdPostalCode)) { // zip or postal code
            gr.u_zip_or_postal_code = locs.stores[i].postalAddress.stdzdPostalCode;
            text += '\nZip: ' + locs.stores[i].postalAddress.stdzdPostalCode;
        } else if (!gs.nil(locs.stores[i].displayAddress.postalCode)) {
            gr.u_zip_or_postal_code = locs.stores[i].displayAddress.postalCode;
            text += '\nZip: ' + locs.stores[i].displayAddress.postalCode;
        }
        if (!gs.nil(locs.stores[i].postalAddress.latitude)) { // latitude
            gr.u_latitude = locs.stores[i].postalAddress.latitude;
            text += '\nLatitude: ' + locs.stores[i].postalAddress.latitude;
        } else if (!gs.nil(locs.stores[i].displayAddress.displayLatitude)) {
            gr.u_latitude = locs.stores[i].displayAddress.displayLatitude;
            text += '\nLatitude: ' + locs.stores[i].displayAddress.displayLatitude;
        }
        if (!gs.nil(locs.stores[i].postalAddress.longitude)) { // longitude
            gr.u_longitude = locs.stores[i].postalAddress.longitude;
            text += '\nLongitude: ' + locs.stores[i].postalAddress.longitude;
        } else if (!gs.nil(locs.stores[i].displayAddress.displayLongitude)) {
            gr.u_longitude = locs.stores[i].displayAddress.displayLongitude;
            text += '\nLongitude: ' + locs.stores[i].displayAddress.displayLongitude;
        }
        if (!gs.nil(locs.stores[i].timeZoneName)) { // time zone
            gr.u_time_zone = locs.stores[i].timeZoneName;
            text += '\nTZ: ' + locs.stores[i].timeZoneName;
        }
        if (!gs.nil(locs.stores[i].postalAddress.standardTimeZoneUTCOffset)) { //time zone offset
            gr.u_time_zone_offset = locs.stores[i].postalAddress.standardTimeZoneUTCOffset;
            text += '\nTZ offset: ' + locs.stores[i].postalAddress.standardTimeZoneUTCOffset;
        }
        gr.insert();
        //utils.writeLog(text);     // uncomment to write location properties to the log
    }

    // all data loaded - run the transformation
    impset.state = 'loaded';
    var mapname = 'Org MDM Location Import';
    utils.doTransform(impset, mapname);
}())
