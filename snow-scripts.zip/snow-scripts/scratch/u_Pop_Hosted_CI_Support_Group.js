// When support group field of related server tagging record is populated
// use it to populate that CI's support_group field
(function executeRule(current, previous /*null when async*/) {
    //dot-walk to capture the field
	var sg = current.database_instance.running_process.computer.support_group;
	var sg1 = current.running_process.computer.support_group;
	//gs.addInfoMessage('sg = ' + sg);
	//gs.addInfoMessage('sg1 = ' + sg1);
    //JSUtil.notNil validates value is not null or empty.
    if(JSUtil.notNil(sg)){
		//gs.addInfoMessage('name = ' + sg.name);
		current.support_group = sg; //set the current field to this value
	}
    if(JSUtil.notNil(sg1)){
		//gs.addInfoMessage('name = ' + sg1.name);
		current.support_group = sg1; //set the current field to this value
	}
})(current, previous);
