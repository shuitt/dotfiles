(function(){
    var query = 'support_group.nameSTARTSWITHregional it^sys_class_name=cmdb_ci_ip_router^ORsys_class_name=cmdb_ci_ip_switch^ORsys_class_name=cmdb_ci_wap_network^ORsys_class_name=u_cmdb_ci_wireless_controller';
    var grp_id = 'fbe773f6db5d7200cdf5f8fdae9619b5';
    var gr = new GlideRecord('cmdb_ci');
    gr.addEncodedQuery(query);
    gr.orderBy('name');
    gr.query();
    gs.print('count: ' + gr.getRowCount());
    while (gr.next()) {
        //gs.print(gr.name);
        gr.support_group = grp_id;
        gr.autoSysFields(false);
        gr.setWorkflow(false);
        var id = gr.update();
    }
}())
