#!/usr/bin/env python3

import json
import csv
import sys
import string

JSONFILE = '/Users/xsmh/Downloads/20180904 Stores All.json'
CSVFILE = '/Users/xsmh/Downloads/20180904 Stores All.csv'

HEADER = [
    'Store number',         # 0 - storeNumber
    'Name',                 # 1 - store number + name
    'Full name',            # 2 - store number + name
    'Street',               # 3 - postalAddress.stdzdLine1Text
    'City',                 # 4 - postalAddress.stdzdCityName
    'State / Province',     # 5 - postalAddress.origStateCode
    'Country',              # 6 - postalAddress.origCountryIsoCode
    'Zip / Postal Code',    # 7 - postalAddress.stdzdPostalCode
    'Phone',                # 8 - telephone.externalTelephoneNumber
    'Location type',        # 9 - adminHier.buDesc
    'Active',               # 10 - isStoreOperationalToPublic
    'Store Region',         # 11 - adminHier.regionDesc
    'Time zone',            # 12 - timeZoneName
    'Longitude',            # 13 - postalAddress.longitude
    'Latitude'              # 14 - postalAddress.latitude
]
do_header = True

json_file = open(JSONFILE)
data = json.load(json_file)
json_file.close()

store_data = open(CSVFILE, 'w')
csvwriter = csv.writer(store_data)

for p in data['stores']:
    outrow = [''] * len(HEADER)
    if do_header:
        csvwriter.writerow(HEADER)
        do_header = False

    print('Store ' + p['storeNumber'] + ' ' + p['name'])
    outrow[0] = p['storeNumber']
    outrow[1] = p['storeNumber'] + ' ' + string.capwords(p['name'])
    outrow[2] = p['storeNumber'] + ' ' + string.capwords(p['name'])

    if 'postalAddress' in p:
        if 'tdzdLine1Text' in p['postalAddress']:
            outrow[3] = string.capwords(p['postalAddress']['stdzdLine1Text'])
        if 'stdzdCityName' in p['postalAddress']:
            outrow[4] = string.capwords(p['postalAddress']['stdzdCityName'])
        if 'origStateCode' in p['postalAddress']:
            outrow[5] = p['postalAddress']['origStateCode']
        if 'origCountryIsoCode' in p['postalAddress']:
            outrow[6] = p['postalAddress']['origCountryIsoCode']
        if 'stdzdPostalCode' in p['postalAddress']:
            outrow[7] = p['postalAddress']['stdzdPostalCode']
        if 'longitude' in p['postalAddress']:
            outrow[13] = p['postalAddress']['longitude']
        if 'latitude' in p['postalAddress']:
            outrow[14] = p['postalAddress']['latitude']

    if 'displayAddress' in p:
        if 'line1Text' in p['displayAddress']:
            outrow[3] = p['displayAddress']['line1Text']
        if 'cityName' in p['displayAddress']:
            outrow[4] = p['displayAddress']['cityName']
        if 'stateCode' in p['displayAddress']:
            outrow[5] = p['displayAddress']['stateCode']
        if 'postalCode' in p['displayAddress']:
            outrow[7] = p['displayAddress']['postalCode']
        if 'displayLongitude' in p['displayAddress']:
            outrow[13] = p['displayAddress']['displayLongitude']
        if 'displayLatitude' in p['displayAddress']:
            outrow[14] = p['displayAddress']['displayLatitude']

    if 'telephone' in p and 'externalTelephoneNumber' in p['telephone']:
        outrow[8] = p['telephone']['externalTelephoneNumber']

    if 'adminHier' in p:
        #if 'buDesc' in p['adminHier']:
        #    outrow[9] = string.capwords(p['adminHier']['buDesc'])
        if 'regionDesc' in p['adminHier']:
            outrow[11] = string.capwords(p['adminHier']['regionDesc'])
        if 'groupDesc' in p['adminHier']:
            outrow[9] = string.capwords(p['adminHier']['groupDesc'])

    if 'isStoreOperationalToPublic' in p:
        outrow[10] = p['isStoreOperationalToPublic']

    if 'timeZoneName' in p:
        outrow[12] = p['timeZoneName']

    csvwriter.writerow(outrow)

store_data.close()
