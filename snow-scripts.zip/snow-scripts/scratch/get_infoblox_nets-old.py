#!/usr/bin/env python3

import os
import requests
import json
import getpass

# constants
MAX = '250'
BASEURL = 'https://dnsmgmt1.0319.datacenter.nordstrom.net/wapi/v2.7.1/network?_return_as_object=1&_paging=1&_return_fields=network,extattrs&*Location+ID~=^[0-9]&_max_results=' + MAX
NEXT = '&_page_id='
HEADERS = {"Accept":"application/json"}

more_nets = True
url = BASEURL

#user = input('User ID: ')
#pswd = getpass.getpass()
#all = input('Get all networks? (y/N): ')
#all_nets = all.lower == 'y'

user = 'xsmh'
pswd = 'G0tmyc3rt'
all_nets = True

# Do the HTTP request
while more_nets:
    requests.packages.urllib3.disable_warnings()
    response = requests.get(url, auth=(user, pswd), headers=HEADERS, verify=False)

    # Check for HTTP codes other than 200
    if response.status_code != 200:
        print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:', response.text)
        exit()

    # Decode the JSON response into a dictionary and use the data
    #print(response.text)
    data = json.loads(response.text)
    #print(data['next_page_id'])

    networks = data['result']
    for net in networks:
        if 'Location ID' in net['extattrs']:
            print(net['network']+ '\t' + net['extattrs']['Location ID']['value'])
        else:
            print(net['network']+ '\t' + 'No Location ID')

    if all_nets:
        if 'next_page_id' in data:
            url = BASEURL + NEXT + data['next_page_id']
        else:
            more_nets = False
    else:
        more_nets = False
