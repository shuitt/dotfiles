var u_AccountUtils = Class.create();

u_AccountUtils.prototype = {

	initialize: function(ritm) {
		// ritm is gliderecord object
		this.api_grp_id = 'cfe37a0ddb7dc744cdf5f8fdae961967';   // API Service Accounts group's sys_id
		this.group = ritm.variables.v_group;
		this.request = ritm.request;
	},

	// create a pair of service accounts - one for prod, one for non-prod
	createSvcAccts: function(user_id) {
		var ok = false;
		var seq = null;
		var result = {
			dev_user_id : null,
			dev_pswd : null,
			dev_sysid : null,
			prod_user_id : null,
			prod_pswd : null,
			prod_sysid : null,
		};

		// make sure seq number is not already used
		while (!ok) {
			seq = this.getNextSeqNbr();
			result.dev_user_id = 'api' + seq + '.dev.user';
			result.prod_user_id = 'api' + seq + '.prod.user';
			if (this.userIdAvailable(result.dev_user_id ) && this.userIdAvailable(result.prod_user_id)) {
				ok = true;
			}
		}

		result.dev_pswd = this.generatePassword();
		result.prod_pswd = this.generatePassword();
		result.dev_sysid = this.insertUser(result.dev_user_id, result.dev_pswd, seq);
		result.prod_sysid = this.insertUser(result.prod_user_id, result.prod_pswd, seq);
		return result;
	},

	// create the service account
	insertUser: function(user_id, pswd, seq) {
		var gr = new GlideRecord('sys_user');
		gr.newRecord();
		gr.user_name = user_id;
		gr.user_password.setDisplayValue(pswd);
		gr.first_name = 'API ' + seq;
		gr.last_name = 'Service Account';
		if (user_id.indexOf('prod') < 0) {
			gr.u_production_service_account = false;
			gr.active = false;
			gr.locked_out = true;
		} else {
			gr.u_production_service_account = true;
		}
		gr.web_service_access_only  = true;
		var sys_id = gr.insert();
		if (!gs.nil(sys_id)) {
			this.addToGroup(sys_id);
			var svc_acct_id = this.insertServiceAcct(sys_id, user_id);
			if (!gs.nil(svc_acct_id)) {
				gr.u_service_account = svc_acct_id;
				gr.update();
				this.insertAudit(svc_acct_id);
			}
		}
		return sys_id;
	},

	// create service account record
	insertServiceAcct: function(user_sys_id, user_id) {
		gs.info('--> in insertServiceAcct\nuser_sys_id: ' + user_sys_id + '\nuser_id: ' + user_id + '\nrequest: ' + this.request + '\ngroup: ' + this.group + '\nuser_id: ' + user_id);
		var gdt = new GlideDateTime();
		var svcacct = new GlideRecord('u_service_account');
		svcacct.u_creating_request = this.request;
		svcacct.u_owning_group = this.group;
		svcacct.u_retired = false;
		svcacct.u_service_account_created = gdt;
		svcacct.u_service_account = user_sys_id;
		svcacct.u_user_id = user_id;
		return svcacct.insert();
	},

	// create service account audit record
	insertAudit: function(svc_acct_id) {
		gs.info('--> in insertAudit\nrequest: ' + this.request + '\nsvc_acct_id: ' + svc_acct_id);
		var audit = new GlideRecord('u_service_account_audit');
		audit.u_action = 'create';
		audit.u_request = this.request;
		audit.u_service_account = svc_acct_id;
		return audit.insert();
	},

	// add user to the API Service Accounts group
	addToGroup: function(user_sysid) {
		var mbr = new GlideRecord('sys_user_grmember');
		mbr.group = this.api_grp_id;
		mbr.user = user_sysid;
		mbr.insert();
		return;
	},

	// return a list of instances to synch the service account password to
	// for nonprod only update current instance to allow testing
	getInstanceList: function() {
		if (gs.getProperty('instance_name') == 'nordstrom') {
			return ['nordstromdev', 'nordstromtest', 'nordstrompreprod'];
		} else {
			return [gs.getProperty('instance_name')];
		}
	},

	// synch the service acct password to another instance
	updatePassword: function(sys_id, pwd, instance) {
		var response = null;
		var result = {
				status: null,
				msg: null,
				success: true
		};

		var msg = new sn_ws.RESTMessageV2('Nord User Update', 'put');
		msg.setStringParameter('instance', instance);
		msg.setStringParameter('id', sys_id);
		msg.setStringParameter('pwd', pwd);
		try {
			response = msg.execute();
		} catch(ex) {
			result.msg = 'REST message exception: ' + ex.getMessage();
			result.success = false;
			return result;
		}

		result.status = response.getStatusCode();
		result.msg = JSON.parse(response.getBody());
		if (result.status == 200) {
			result.success = true;
		} else {
			result.success = false;
		}
		return result;
	},

	// get the next seq number to use
	getNextSeqNbr: function() {
		var nextSeq = '000' + gs.getProperty('u_nord.api.userid.seq');
		var suffix = nextSeq.substring(nextSeq.length - 4);
		nextSeq++;
		gs.setProperty('u_nord.api.userid.seq', nextSeq, 'Next sequence value for service accounts');
		return suffix;
	},

	// check if a user ID already exists
	userIdAvailable: function(user_id) {
		var gr = new GlideRecord('sys_user');
		gr.addQuery('user_name', user_id);
		gr.query();
		return !gr.hasNext();
	},

	// generate a randomized 16 character password that use a mix of character types.getContentType()
	// this code is based on example code shared in blog post by
	// Tom Raithel(http://www.frontcoded.com/javascript-generate-passwords.html
	generatePassword: function() {
		// chars that can be included in a password
		var lcLetters = 'abcdefghijklmnopqrstuvwxyz';
		var ucLetters = lcLetters.toUpperCase();
		var numbers = '0123456789';
		var special = '!?=#*@+-';

		// the count of each char type to include in the password
		var numLc = 5;
		var numUc = 4;
		var numDigits = 5;
		var numSpecial = 2;

		var pass = [];
		var i = 0;

		for (i = 0; i < numLc; ++i) { // get some lowercase chars
			pass.push(this.getRand(lcLetters));
		}
		for (i = 0; i < numUc; ++i) { // get some uppercase chars
			pass.push(this.getRand(ucLetters));
		}
		for (i = 0; i < numDigits; ++i) { // get some digits
			pass.push(this.getRand(numbers));
		}
		for (i = 0; i < numSpecial; ++i) { //get some special chars
			pass.push(this.getRand(special));
		}
		// shuffle the chars and return the password
		return this.shuffle(pass).join('');
	},

	// select a random char form the specified list
	getRand: function(values) {
		return values.charAt(Math.floor(Math.random() * values.length));
	},

	// shuffle the spefified list of chars. based on code posted by
	// Jonas Raoni Soares Silva (http://jsfromhell.com/array/shuffle)
	shuffle: function(o) {
		for(var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
			return o;
	},

	type: 'u_AccountUtils'
};
