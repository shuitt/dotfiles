var u_CiOwnerUtils = Class.create();
u_CiOwnerUtils.prototype = {
	initialize: function() {
		this.locPat = /^\D*(\d+)\D*/i;		// get possible loc number from dev name
		this.rmZeroPat = /^0+/;				// remove leading zeros
		this.ci_rel_table = 'cmdb_rel_ci';
		this reg_query = 'parent.sys_class_name=cmdb_ci_vmware_instance^' +
		                 'ORparent.sys_class_name=cmdb_ci_hyper_v_instance' +
						 '^type.parent_descriptor=Registered on^parent=';
	},

	// determine location based on device name
	getLocation: function(devName) {
		var store_sys_id = null;
		loc = devName.match(this.locPat);
		if (loc != null) {
			store = loc[1].replace(this.rmZeroPat, '');
			store_sys_id = this.getLocId(store);
		}
		return store_sys_id;
	},

	getLocFromVirtHost: function(vm_id) {
	    var gr = new GlideRecord(this.ci_rel_table);
	    gr.addQuery('parent', vm_id);
	    gr.addQuery('parent_descriptor', 'Virtualized by');
	    gr.query();
	    if (gr.next()) {
	        return gr.child.location;
	    } else {
	        return null;
	    }
	},

	getLocFromRegHost: function(inst_id) {
	    var gr = new GlideRecord(this.ci_rel_table);
	    gr.addEncodedQuery(reg_query + inst_id);
	    gr.query();
	    if (gr.next()) {
	        return gr.child.location.sys_id;
	    } else {
	        return null;
	    }
	},

	// get the sys_id for a location table record
	getLocId: function(store) {
		var gr = new GlideRecord('cmn_location');
		gr.addQuery('u_store_number', store);
		gr.query();
		if (gr.next()) {
			return gr.sys_id;
		} else {
			return null;
		}
	},

    // determine location based on connected switch
	getLocationFromSw: function(devName) {
        var store_sys_id = null;
        var query = 'childISNOTEMPTY^type.parent_descriptor=Ip Connection^parent.name=';
        var rels = new GlideRecord('cmdb_rel_ci');
        rels.addEncodedQuery(query + devName);
        rels.query();

        while (rels.next()) {
            // look for child cis that can switch and have a non-empty location
            if (rels.child.can_switch && !gs.nil(rels.child.location)) {
                store_sys_id = rels.child.location;
                break;    // got a location so skip checking any remaining relationships
            }
        }
		return store_sys_id;
	},

	// get a support group sys_id for a location from the assignment routing table
	getOwningGroup: function(loc) {
		var nsgLocs = ['319', '805', '865', '865'];
		gr = new GlideRecord('u_assignment_routing_details');
		gr.addQuery('u_location', loc);
		gr.addNotNullQuery('u_assignment_routing');
		gr.query();
		if (gr.next()) {
			gs.info('CiOwner: store is ' + gr.u_location.u_store_number);
			if (gr.u_location.u_store_number == '319' ||
				gr.u_location.u_store_number == '805' ||
				gr.u_location.u_store_number == '864' ||
				gr.u_location.u_store_number == '865') { // nsg supported
					gs.info('CiOwner: nsg suported');
					return this.getNsgGroup();
			} else { // not nsg supported
				gs.info('CiOwner: not nsg suported');
				return gr.u_assignment_group.sys_id;
			}
		} else {  // unknown loc
			return null;
		}
	},

	// get the sys_id for the nsg group
	getNsgGroup: function() {
		var  gr = new GlideRecord('sys_user_group');
		gr.addQuery('name', 'Platform Engineering - Network');
		gr.query();
		if (gr.next()) {
			return gr.sys_id;
		} else {
			return null;
		}
	},

	// get the sys_id for the regional group
	getRegnlGroup: function() {
		var  gr = new GlideRecord('sys_user_group');
		gr.addQuery('name', 'Regional IT - NW Local Region');
		gr.query();
		if (gr.next()) {
			return gr.sys_id;
		} else {
			return null;
		}
	},

    type: 'u_CiOwnerUtils'
};
