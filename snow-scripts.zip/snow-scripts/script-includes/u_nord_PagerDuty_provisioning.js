var u_nord_PagerDuty_provisioning = Class.create();
u_nord_PagerDuty_provisioning.prototype = {
	initialize: function() {
		this.apiKey =  gs.getProperty('u_nord.pagerduty.oncall.api.key');
	},

	////// functions for calling the pagerduty api

	// create a pagerduty user
	// name - the new user's name
	// email - the new user's email address
	addAccess: function(name, email) {
		var restMessage = new sn_ws.RESTMessageV2('PagerDuty Create User', 'POST');
		//restMessage.setLogLevel('all');   // more verbose outbound http logging
		restMessage.setStringParameter('key', this.apiKey);
		restMessage.setStringParameter('name', name);
		restMessage.setStringParameter('email', email);
		var result = this.sendRestMsg(restMessage);
		if (result.status == 201) {
			result.id = result.body.user.id;
		} else if (!gs.nil(result.body)) {
			result.errmsg = this.formatErrorMsg(result);
		}
		return result;
	},

	// delete a pagerduty user
	// pd_id - the user's pagerduty id
	removeAccess: function(pd_id) {
		var restMessage = new sn_ws.RESTMessageV2('PagerDuty Delete User', 'DELETE');
		//restMessage.setLogLevel('all');   // more verbose outbound http logging
		restMessage.setStringParameter('key', this.apiKey);
		restMessage.setStringParameter('id', pd_id);
		var result = this.sendRestMsg(restMessage);
		if (result.status == 400 && result.body.error.hasOwnProperty('conflicts')) {
			result.conflicts = true;
		}
		return result;
	},

	// resolve a pagerduty incident
	// incident - the pagerduty incident id
	// email - the email identifying the incident resolver
	resolveIncident: function(incident, email) {
		var restMessage = new sn_ws.RESTMessageV2('PagerDuty Resolve Incident', 'PUT');
		//restMessage.setLogLevel('all');   // more verbose outbound http logging
		restMessage.setStringParameter('key', this.apiKey);
		restMessage.setStringParameter('from', email);
		restMessage.setStringParameter('incident', incident);
		var result = this.sendRestMsg(restMessage);
		if (result.status != 200) {
			result.errmsg = this.formatErrorMsg(result);
		}
		return result;
	},

	// get a pagerduty schedule
	// sched - the schedule's pagerduty id
	getSchedule: function(sched) {
		var restMessage = new sn_ws.RESTMessageV2('PagerDuty Get A Schedule', 'GET');
		//restMessage.setLogLevel('all');   // more verbose outbound http logging
		restMessage.setStringParameter('key', this.apiKey);
		restMessage.setStringParameter('sched', sched);
		var result = this.sendRestMsg(restMessage);
		if (result.status != 200) {
			result.errmsg = this.formatErrorMsg(result);
		}
		return result;
	},

	// update a pagerduty schedule
	// sched - the schedule's pagerduty id
	// body - the api request body (a string)
	updateSchedule: function(sched, body) {
		var restMessage = new sn_ws.RESTMessageV2('PagerDuty Update A Schedule', 'PUT');
		//restMessage.setLogLevel('all');   // more verbose outbound http logging
		restMessage.setStringParameter('key', this.apiKey);
		restMessage.setStringParameter('sched', sched);
		restMessage.setRequestBody(body);
		var result = this.sendRestMsg(restMessage);
		if (result.status != 200) {
			result.errmsg = this.formatErrorMsg(result);
		}
		return result;
	},

	// get a pagerduty escalation policy
	// policy - the escalation policy's pagerduty id
	getEscalationPolicy: function(policy) {
		var restMessage = new sn_ws.RESTMessageV2('PagerDuty Get An Escalation Policy', 'GET');
		//restMessage.setLogLevel('all');   // more verbose outbound http logging
		restMessage.setStringParameter('key', this.apiKey);
		restMessage.setStringParameter('policy', policy);
		var result = this.sendRestMsg(restMessage);
		if (result.status != 200) {
			result.errmsg = this.formatErrorMsg(result);
		}
		return result;
	},

	// update a pagerduty escalation policy
	// policy - the escalation policy's pagerduty id
	// body - the api request body (a string)
	updateEscalationPolicy: function(policy, body) {
		var restMessage = new sn_ws.RESTMessageV2('PagerDuty Update An Escalation Policy', 'PUT');
		//restMessage.setLogLevel('all');   // more verbose outbound http logging
		restMessage.setStringParameter('key', this.apiKey);
		restMessage.setStringParameter('policy', policy);
		restMessage.setRequestBody(body);
		var result = this.sendRestMsg(restMessage);
		if (result.status != 200) {
			result.errmsg = this.formatErrorMsg(result);
		}
		return result;
	},

	////// utility functions for updating the user's sys_user record

	// update a user record with their pagerduty id
	// user - user record sys_id
	// pd_id - user's pagerduty id
	addUserPdId: function(user, pd_id) {
		var gr = new GlideRecord('sys_user');
		gr.get(user);
		gr.x_pd_integration_pagerduty_id = pd_id;
		gr.update();
	},

	// remove the pagerduty id from user record
	// user - user record sys_id
	remUserPdId: function(user) {
		var gr = new GlideRecord('sys_user');
		gr.get(user);
		gr.x_pd_integration_pagerduty_id = '';
		gr.update();
	},

	////// utility functions used with api calls

	// send a rest message (make an api call)
	// rest_msg - the rest message object for the call
	sendRestMsg: function(rest_msg) {
		var response = null;
		var result = {'status': null,
			'body': null,
			'code': null,
			'errmsg': null,
			'id': null,
			'conflicts': false
		};

		try {
			response = rest_msg.execute();
		} catch(ex) {
			result.errmsg = 'REST message exception: ' + ex.getMessage();
			return result;
		}

		result.status = response.getStatusCode();
		if (result.status == 401) {
			result.errmsg = 'Unauthorized - the PagerDuty API key is probably incorrect';
		} else {
			result.body = JSON.parse(response.getBody());
		}

		return result;
	},

	// format api errors into a single message
	// result - a result object created by the sendRestMsg() function
	formatErrorMsg: function(result) {
		var msg = 'PagerDuty API error:\n';
		if (!gs.nil(result.status)) {
			msg += '\nHTTP status: ' + result.status;
		} else {
			msg += '\nHTTP status: ';
		}
		if (!gs.nil(result.body.error.code)) {
			msg += '\nAPI code: ' + result.body.error.code;
		} else {
			msg += '\nAPI code: ';
		}
		if (!gs.nil(result.body.error.message)) {
			msg += '\nMessage: ' + result.body.error.message;
		} else {
			msg += '\nMessage: ';
		}
		if (!gs.nil(result.body.error.errors)) {
			if (result.body.error.errors.length > 0) {
				msg += '\nError details: ';
				for (var i = 0; i < result.body.error.errors.length; i++) {
					msg += result.body.error.errors[i];
				}
			}
		}
		msg += '\nAPI response: ' + JSON.stringify(result.body);
		return msg;
	},

	////// functions for building a request body for updating an escalation policy

	// remove the specified user from an escalation policy
	// body - the response body from a get escalation policy api call
	// user - the pagerduty id of the user to remove
	updateEscalationRules: function(body, user) {
        var new_rules = this.processRules(body.escalation_policy.escalation_rules, user);
        body.escalation_policy.escalation_rules = new_rules;
        return JSON.stringify(body);
    },

	// remove the specified user from an escalation policy's rules
	// rules - a list of rules from an escalation policy
	// user - the user to remove from the rules
    processRules: function(rules, user) {
        var new_rules = [];
        for (var i = 0; i < rules.length; i++) {
            var new_targets = this.processTargets(rules[i].targets, user);
            if (new_targets.length > 0) {
                rules[i].targets = new_targets;
                new_rules.push(rules[i]);
            }
        }
        return new_rules;
    },

	// remove the specified user from an escalation policy's targets
	// targets - a list of targets from an escalation policy
	// user - the user to remove from the targets
    processTargets: function(targets, user) {
        var new_targets = [];
        for (var i = 0; i < targets.length; i++) {
            var new_item = this.processTargetItem(targets[i], user);
            if (!gs.nil(new_item)) {
                new_targets.push(new_item);
            }
        }
        if (new_targets.length == 0) {
            var replacement = this.findReplacement(user);
            new_targets.push({"id": replacement, "type": "user_reference"});
        }
        return new_targets;
    },

	// check whether an escalation target item is for the specified user
	// item - the escalation target item to check
	// user - the user to remove
    processTargetItem: function(item, user) {
        if (item.type == 'user_reference' && item.id == user) {
            return null;
        }
        return item;
    },

	////// functions for building a request body for updating a schedule

	// remove the specified user from a schedule
	// body - the response body from a get schedule api call
	// user - the pagerduty id of the user to remove
	updateOncallSchedule: function(body, user) {
		var replacement = null;
        var new_users = this.processUsers(body.schedule.users, user);
        if (new_users.length == 0) {
            replacement = this.findReplacement(user);
            new_users.push({"user": { "id": replacement, "type": "user_reference"}});
        }
        body.schedule.users = new_users;

        var new_layers = this.processLayers(body.schedule.schedule_layers, user);
        if (new_layers.length == 0) {
            replacement = this.findReplacement(user);
            new_layers.push({"user": { "id": replacement, "type": "user_reference"}});
        }
        body.schedule.schedule_layers = new_layers;
        return JSON.stringify(body);
    },

	// remove the user from the schedule's user list
	// users - the schedule's user list
	// user - the user to remove
    processUsers: function(users, user) {
        var new_users = [];
        for (var i = 0; i < users.length; i++) {
            if (users[i].id != user) {
                new_users.push(users[i]);
            }
        }
        return new_users;
    },

	// remove the user from the schedule's layers
	// layers - the schedule's layers list
	// user - the user to remove
    processLayers: function(layers, user) {
        var new_layers = [];
        for (var i = 0; i < layers.length; i++) {
            var new_users = this.processLayerUsers(layers[i], user);
            if (new_users.length > 0) {
                layers[i].users = new_users;
                new_layers.push(layers[i]);
            }
        }
        return new_layers;
    },

	// remove the user from the layer's user list
	// layer - the layer's user list
	// user - the user to remove
    processLayerUsers: function(layer, user) {
        var new_users = [];
        for (var i = 0; i < layer.users.length; i++) {
            var new_item = this.processLayerUserItem(layer.users[i], user);
            if (!gs.nil(new_item)) {
                new_users.push(new_item);
			}
        }
        return new_users;
    },

	// check whether layer user list item is for the specified user
	// item - the layer user item to check
	// user - the user to remove
    processLayerUserItem: function(item, user) {
        if (item.user.type == 'user_reference' && item.user.id == user) {
            gs.print('found a match');
            return null;
        }
        return item;
    },

	////// functions for selecting a replacement pagerduty user

	// find a user to replace the user to be deleted in a schedule or escalation policy
	// user - the user to be replaced
	findReplacement: function(user) {
		gs.print('findReplacement: find replacement for user: ' + user);
        var found = false;
        var replace = null;
        var i = 0;
        var teams = this.getUserTeams(user);
		gs.print('findReplacement: teams found: ' + teams.length);
		for (i = 0; i < teams.length; i++) {
			gs.print('findReplacement: team id: ' + teams[i]);
		}

		i = 0;
        while (i < teams.length && !found) {
            var mbrs = this.getTeamMembers(teams[i], user);
			gs.print('findReplacement: team members found: ' + mbrs.length);
			for (var k = 0; k < mbrs.length; k++) {
				gs.print('findReplacement: member id: ' + mbrs[k]);
			}
            var j = 0;
            while (j < mbrs.length && !found) {
                if (this.userExists(mbrs[j])) {
					gs.print('findReplacement: user exists, id: ' + mbrs[j]);
                    found = true;
                    replace = mbrs[j];
                } else {
					gs.print('findReplacement: user does not exist, id: ' + mbrs[j]);
				}
                j++;
            }
            i++;
        }
		gs.print('findReplacement: replacement id: ' + replace);
        return replace;
    },

	// get the teams that the specified user is a member of
	// user - the user's pagerduty id
    getUserTeams: function(user) {
		gs.print('getUserTeams: find teams for user: ' + user);
        var teams = [];
        var gr = new GlideRecord('u_pagerduty_team_members');
        gr.addQuery('u_user_id', user);
        gr.query();
        while (gr.next()) {
			gs.print('getUserTeams: member of team: ' + gr.getValue('u_team_id'));
            teams.push(gr.getValue('u_team_id'));
        }
        return teams;
	},

	// team - the pagerduty id of the team
	// user - the pagerduty id of the user
    getTeamMembers: function(team, user) {
		gs.print('getTeamMembers: find members for teams: ' + team);
        var mbrs = [];
        var gr = new GlideRecord('u_pagerduty_team_members');
        gr.addQuery('u_team_id', team);
        gr.addQuery('u_user_id', '!=', user);
        gr.query();
        while (gr.next()) {
			gs.print('getTeamMembers: team member: ' + gr.getValue('u_user_id'));
            mbrs.push(gr.getValue('u_user_id'));
        }
        return mbrs;
    },

	// use the pagerduty get user api to check whether  user exists
	// user - the pagerduty id of the user
    userExists: function(user) {
		gs.print('userExists: check user: ' + user);
		var restMessage = new sn_ws.RESTMessageV2('PagerDuty Get User', 'GET');
		//restMessage.setLogLevel('all');   // more verbose outbound http logging
		restMessage.setStringParameter('key', this.apiKey);
		restMessage.setStringParameter('id', user);
		var result = this.sendRestMsg(restMessage);
		gs.print('userExists: api status: ' + result.status);
		if (result.status == 200) {
			return true;
		} else {
			for (var key in result) {
				if (typeof(result[key]) == 'object') {
					gs.print('userExists: result.' + key + " = " + JSON.stringify(result[key]));
				} else {
					gs.print('\nuserExists: result.' + key + " = " + result[key]);
				}
			}
			return false;
		}
    },

	type: 'u_nord_PagerDuty_provisioning'
};
