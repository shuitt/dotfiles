var u_SIR_WF_Utils = Class.create();
u_SIR_WF_Utils.prototype = {
    initialize: function() {
    },

    // autenticate to the fireeye hx appliance and get a token to use with subsequent api calls
	feGetAPIToken: function() {
		var httpStatus = 0;
		workflow.scratchpad.token = null;
		var mid = this.getMidServer();
		if (!gs.nil(mid)) {
	        try {
				var restMessage = new sn_ws.RESTMessageV2('FireEye Authentication', 'get');
				restMessage.setMIDServer(mid);
                restMessage.setLogLevel('all');
				response = restMessage.execute();
				httpStatus = response.getStatusCode();
				if (httpStatus == 204) {
					workflow.scratchpad.token = response.getHeader("X-FeApi-Token");
				} else {
					workflow.scratchpad.logmsg += '\nFireEye get token API call failed, HTTP status = ' + httpStatus;
				}
			} catch(ex) {
				workflow.scratchpad.logmsg += '\nFireEye get token API call exception: ' + ex.getMessage();
			}
		}
	},

    // get the fireeye agent id for the specified host. the agent id is required for
    // host containment api calls
	feGetAgentID: function(host) {
		var httpStatus = 0;
		workflow.scratchpad.agent_id = null;
		var mid = this.getMidServer();
		if (!gs.nil(mid)) {
	        try {
				var restMessage = new sn_ws.RESTMessageV2('FireEye Get Host Info', 'get');
				restMessage.setRequestHeader('X-FeApi-Token', workflow.scratchpad.token);
                restMessage.setStringParameter('host', host.trim());
				restMessage.setMIDServer(mid);
                restMessage.setLogLevel('all');
				var response = restMessage.execute();
				httpStatus = response.getStatusCode();
				if (httpStatus == 200) {
                    workflow.scratchpad.logmsg += '\nResponse: ' + response.getBody();
                    var body = JSON.parse(response.getBody());
                    if (!gs.nil(body)) {
                        if (body.data.total > 0) {
        					workflow.scratchpad.agent_id = body.data.entries[0]._id;
                            workflow.scratchpad.logmsg += '\nAgent ID for host '+ host + ' is ' + workflow.scratchpad.agent_id;
                        } else {
                            workflow.scratchpad.logmsg += '\nHost ' + host + ' not found';
                        }
                    } else {
                        workflow.scratchpad.logmsg += '\nNull response body returned by the API';
                    }
				} else {
					workflow.scratchpad.logmsg += '\nFireEye get host info API call failed, HTTP status = ' + httpStatus;
				}
			} catch(ex) {
				workflow.scratchpad.logmsg += '\nFireEye get host info API call exception: ' + ex.getMessage();
			}
		}
	},

    // request containment of a host
	feRequestContain: function() {
		var httpStatus = 0;
        var mid = this.getMidServer();
		if (!gs.nil(mid)) {
	        try {
				var restMessage = new sn_ws.RESTMessageV2('FireEye Request Host Contain', 'post');
				restMessage.setRequestHeader('X-FeApi-Token', workflow.scratchpad.token);
                restMessage.setStringParameter('agentid', workflow.scratchpad.agent_id);
				restMessage.setMIDServer(mid);
                restMessage.setLogLevel('all');
				response = restMessage.execute();
				httpStatus = response.getStatusCode();
				if (httpStatus == 202) {
                    workflow.scratchpad.logmsg += '\nHost containment request accepted';
				} else {
					workflow.scratchpad.logmsg += '\nFireEye request host containment API call failed, HTTP status = ' + httpStatus;
				}
			} catch(ex) {
				workflow.scratchpad.logmsg += '\nFireEye request host containment API call exception: ' + ex.getMessage();
			}
		}
        return httpStatus;
	},

    // approve a previous request to contain a host
	feApproveContain: function() {
		var httpStatus = 0;
        var mid = this.getMidServer();
		if (!gs.nil(mid)) {
	        try {
				var restMessage = new sn_ws.RESTMessageV2('FireEye Approve Host Contain', 'patch');
				restMessage.setRequestHeader('X-FeApi-Token', workflow.scratchpad.token);
                restMessage.setStringParameter('agentid', workflow.scratchpad.agent_id);
				restMessage.setMIDServer(mid);
                restMessage.setLogLevel('all');
				response = restMessage.execute();
				httpStatus = response.getStatusCode();
				if (httpStatus == 201) {
                    workflow.scratchpad.logmsg += '\nHost containment approved';
				} else {
					workflow.scratchpad.logmsg += '\nFireEye approve host containment API call failed, HTTP status = ' + httpStatus;
				}
			} catch(ex) {
				workflow.scratchpad.logmsg += '\nFireEye approve host containment API call exception: ' + ex.getMessage();
			}
		}
        return httpStatus;
	},

    // chekc the containment status of a host
	feCheckContain: function() {
		var httpStatus = 0;
		workflow.scratchpad.contain = null;
		var mid = this.getMidServer();
		if (!gs.nil(mid)) {
	        try {
				var restMessage = new sn_ws.RESTMessageV2('FireEye Check Contain Status', 'get');
				restMessage.setRequestHeader('X-FeApi-Token', workflow.scratchpad.token);
                restMessage.setStringParameter('agentid', workflow.scratchpad.agent_id);
				restMessage.setMIDServer(mid);
                restMessage.setLogLevel('all');
				response = restMessage.execute();
				httpStatus = response.getStatusCode();
				if (httpStatus == 200) {
                    workflow.scratchpad.logmsg += '\nResponse: ' + response.getBody();
                    var body = JSON.parse(response.getBody());
					workflow.scratchpad.contain = body.data.containment_state;
                    workflow.scratchpad.logmsg += '\Containment state = ' + workflow.scratchpad.contain;
				} else {
					workflow.scratchpad.logmsg += '\nFireEye check containment status API call failed, HTTP status = ' + httpStatus;
				}
			} catch(ex) {
				workflow.scratchpad.logmsg += '\nFireEye check containment status API call exception: ' + ex.getMessage();
			}
		}
        return httpStatus;
	},

    // logout of the fireeye appliance expiring the prevously acquired api token
	feLogout: function() {
		var httpStatus = 0;
		var mid = this.getMidServer();
		if (!gs.nil(mid)) {
	        try {
				var restMessage = new sn_ws.RESTMessageV2('FireEye Logout', 'delete');
				restMessage.setMIDServer(mid);
				restMessage.setRequestHeader('X-FeApi-Token', workflow.scratchpad.token);
                restMessage.setLogLevel('all');
				response = restMessage.execute();
				httpStatus = response.getStatusCode();
				if (httpStatus != 204) {
					workflow.scratchpad.logmsg += '\nFireEye logout API call failed, HTTP status = ' + httpStatus;
				}
			} catch(ex) {
				workflow.scratchpad.logmsg += '\nFireEye logout API call exception: ' + ex.getMessage();
			}
		}
	},

    // select an active mid server to use with the api calls
	getMidServer: function() {
		var gr = new GlideRecord('ecc_agent');
        gr.addEncodedQuery('nameENDSWITHintegration^statusSTARTSWITHup^validatedINtrue');
        gr.orderBy('last_refreshed');
        gr.setLimit(1);
        gr.query();
        if (gr.next()) {
			workflow.scratchpad.logmsg += '\nUsing MID server: ' + gr.name;
            return gr.name;
        } else {
			workflow.scratchpad.logmsg += '\nNo up and validated integration MID server found';
            return null;
        }
	},

    type: 'u_SIR_WF_Utils'
};
