var OracleEbsIntegrationUtils = Class.create();

// this script include is used by various scripts that pull information from ebs
OracleEbsIntegrationUtils.prototype = {
	initialize: function(source) {
		this.logSource = source;
		this.keepTypes = ['contractor', 'cosmetic vendor speciality', 'designer boutique',
		                  'designer boutique dis', 'employee', 'nfcu', 'trunk club'];
	},

	// send a rest message
    sendMsg: function(webService, cmd) {
        var response = null;
		var mid = this.getMidServer('integration');
		if (mid != null) {
	        try {
	            var restMessage = new sn_ws.RESTMessageV2(webService, cmd);
				restMessage.setMIDServer(mid);
	            response = restMessage.execute();
	        } catch(ex) {
	            this.log('exception: ' + ex.getMessage());
		    }
		}
		return response;
	},

	// send a rest message with last update parm
	sendMsgWithDate: function(webService, cmd, lastRun) {
	    var response = null;
		var mid = this.getMidServer('integration');
		if (mid != null) {
		    try {
		        var restMessage = new sn_ws.RESTMessageV2(webService, cmd);
				restMessage.setMIDServer(mid);
		        restMessage.setStringParameter('Last_Update', lastRun);
		        response = restMessage.execute();
		    } catch(ex) {
		        this.log('exception: ' + ex.getMessage());
		    }
		}
	    return response;
	},

	getMidServer: function(contains) {
        var gr = new GlideRecord('ecc_agent');
        gr.addEncodedQuery('nameENDSWITH' + contains + '^statusSTARTSWITHup^validatedINtrue');
        gr.orderBy('last_refreshed');
        gr.query();
        if (gr.next()) {
			this.log('using MID server: ' + gr.name);
            return gr.name;
        } else {
			this.log('no up and validated ' + contains + ' MID server found');
            return null;
        }
    },


	// get the date/time from the last time the web service was called
	getLastUpdate: function(webService) {
	    var gr = new GlideRecord('u_hr_web_service_control');
	    gr.addQuery('u_web_service', webService);
	    gr.query();
	    if(gr.next()) {
	        return gr.getElement('u_last_update_date');
	    } else {
	        return null;
	    }
	},

	// set the date/time that the web service was last called
	setLastUpdate: function(webService, lastRun) {
	    var gr = new GlideRecord('u_hr_web_service_control');
	    gr.addQuery('u_web_service', webService);
	    gr.query();
	    if(gr.next()) {
	        gr.u_last_update_date = lastRun;
			gr.update();
	    } else {
			this.log('setting last update of ' + lastRun + ' failed');
	    }
	},

	// determine whether a given property has a volue
	hasValue: function(obj, prop) {
	    if (obj[prop].hasOwnProperty('@xsi:nil')) {
	        return false;
	    } else {
	        return true;
	    }
	},

    // see if a given user exists
    userExists: function(empNbr) {
        var gr = new GlideRecord('sys_user');
        gr.addQuery('employee_number', empNbr);
        gr.query();
        return gr.next();   // true if there's a record
    },

    // determine if the user update indicates the user has been terminated
    termedUser: function(user) {
        exists = this.userExists(user.EMP_CWK_NUMBER);
        if (user.PURGE_FLAG == 'Y' && exists) {
            return true;
        }
        if (user.ASSIGNMENT_STATUS == 'Terminate Assignment' && exists) {
            return true;
        }
        if (this.hasValue(user, 'TERMINATION_DATE')) {
            termDate = this.makeDate(user.TERMINATION_DATE);
            today = new GlideDateTime();
            if (termDate.compareTo(today) <= 0 && exists) {
                return true;
            }
        }
        return false;
    },

    // determine whether to process a user update
    processThisUser: function(userType) {
        if (this.keepTypes.indexOf(userType.toLowerCase()) >= 0) {
            return true;
        } else {
            return false;
        }
    },

    // convert the ebs web service datetime string to a GlideDateTime
    makeDate: function(dateStr) {
        parts = dateStr.split(/[T.]/g);     // input fmt is 'yyyy-mm-ddThh:mm:ss.ttt-hh:00'
        dt = parts[0] + ' ' + parts[1];     // fmt is 'yyyy-mm-dd hh:mm:ss'
        return new GlideDateTime(dt);
    },

	// drill down into the ebs web service response to find the list of data items
	getList: function(msg, prop1, prop2) {
		theList = [];
		var op = 'OutputParameters';
	    if (msg.hasOwnProperty([op])) {
	    	this.log('found ' + op);
	        var outParms = msg[op];
	        if (outParms.hasOwnProperty([prop1])) {
	    		this.log('found ' + prop1);
	            var outLocs = outParms[prop1];
	            if (outLocs.hasOwnProperty([prop2])) {  // this is the list
	                theList = outLocs[prop2];
	                this.log('got the list');
	            }
	        }
	    }
		return theList;
	},

	// create an asynchronous import set using the specified table
	getImpSet: function(impTbl) {
        var impSet = new GlideRecord('sys_import_set');
        impSet.initialize();
        impSet.table_name = impTbl;
        impSet.mode = 'asynchronous';
        impSet.state = 'loading';
        impSet.insert();
        this.log('import set created');
		return impSet;
	},

	// run a transformation using a given map
	doTransform: function(impSet, mapName) {
		this.log('find transformation map ' + mapName);
        var map = new GlideRecord('sys_transform_map');
        map.addQuery('name', mapName);
        map.query();
        // if we have a map run the transformation
        if(map.next()) {
            this.log('run the transformation');
            var thread = new GlideImportSetTransformerWorker(impSet.sys_id, map.sys_id);
            thread.setBackground(true);
            thread.start();
        } else {
            this.log('did not find Transform map');
        }
	},

	log: function(msg) {
		gs.log(this.logSource + msg);
	},
	type: 'OracleEbsIntegrationUtils'
}
