var EvtMgmtCustomIncidentPopulator = Class.create();
EvtMgmtCustomIncidentPopulator.prototype = {
	initialize: function() {
	},

	type: 'EvtMgmtCustomIncidentPopulator'
};

/*
 * Placeholder for custom script to assigne additional fields from the alert to the task being opened (by defualt to an incident).
 * This script is called from the EvtMgmtIncidentHandler script include.
 * @param alert - alert
 * @param task - any derivitive of 'task', as defined by the rule, such as incident, problem, etc. By default this will be an incident.
 * @param rule - the rule that triggered creating the incident for the alert. It can be empty - in case of manual incident creation from alert
 * @return - true if task creation should be continued, false - if task creation should be aborted
 */
EvtMgmtCustomIncidentPopulator.populateFieldsFromAlert = function(alert, task, rule){
	// Usage example:
	// task.short_description += ' source: ' + alert.source;
	// return true;

	//STRY1740093 Feb 2017, STRY1832149 Feb 2017
	if (alert.source == "Control-M") {
		task.u_batch_job = alert.resource;
		if (alert.severity == 5) {      // STRY2243239 Apr 2017
			task.urgency = 4;
		} else {
			task.urgency = alert.severity;
		}
		var json = alert.additional_info;
		obj = JSON.parse(json);
		var data = obj.additional_content.replace(" ", "").split(",");
		//JSUtil.logObject(obj);
		task.description = "Additional Job Information:\nOrder ID " + data[0].toString().split(":")[1] + "\nRun As " + data[1].toString().split(":")[1] + "\nHost ID " + data[2].toString().split(":")[1] + "\nRun Counter " + data[3].toString().split(":")[1];
		return true;
	}

	//SMP-145 June 2017
	if (alert.source == "Web Batch Scheduler") {
		task.u_batch_job = alert.resource;
		task.urgency = alert.severity;
		task.description = alert.description + '\n' + alert.additional_info;
		return true;
	}

	//STRY1953147 Mar 2017
	if (alert.source == "SCOM") {
		task.short_description = alert.type.name;
		task.description = alert.description;

		if (alert.source == "SCOM" && alert.cmdb_ci == "") {
			task.cmdb_ci = gs.getProperty('nordstrom.notlisted.ci');
			task.u_missing_ci = alert.node;
			task.assignment_group = gs.getProperty('nordstrom.DatabaseSQLServices');
		}
		if (alert.source == "SCOM" && alert.cmdb_ci != "") {
			if (alert.cmdb_ci.assignment_group != "") {
				task.assignment_group = alert.cmdb_ci.assignment_group;
			} else {
				task.assignment_group = gs.getProperty('nordstrom.DatabaseSQLServices');
			}
		}
		return true;
	}

	//STRY2198480 Apr 2017
	if (alert.source == "Trap From Enterprise 534" || alert.source == "Trap From Enterprise 318") {
		task.short_description = alert.type.name;
		if (alert.resource == "14") {
			task.urgency = 4;
		} else {
			task.urgency = 3;
		}
		var getUps = new GlideRecord('cmdb_ci_ups');
		getUps.addQuery("ip_address", alert.node);
		getUps.query();
		if (getUps.next()){
			task.cmdb_ci = getUps.sys_id;
			task.assignment_group = getUps.support_group;
		}
		return true;
	}

	//STRY2198750 Apr 2017
	if (alert.source == "Trap From Enterprise 11") {
	var myString = alert.description;
	mySplitResult = myString.split("=");
	for(i = 0; i < mySplitResult.length; i++) {
		}
	task.short_description = mySplitResult[5];
	}
	return true;

};
