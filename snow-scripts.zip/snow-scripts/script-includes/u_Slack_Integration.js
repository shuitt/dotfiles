var u_Slack_Integration = Class.create();

u_Slack_Integration.prototype = {
    formatMessage: function(current, action) {
        var user = gs.getUserDisplayName();
        var instance = gs.getProperty('instance_name');
        //var date_time = this.formatDateTime();
        var sys_id = current.getUniqueValue();
        var url = 'https://' + instance + '.service-now.com/sys_remote_update_set.do?sys_id=' + sys_id;
        //var msg = user + ' ' + action + ' update set ' + current.name + ' in the ' + instance  + ' instance at ' +  date_time + '\n' + url;
		var msg = instance + ': ' + current.name + ', ' + action + ' by ' + user + '\n' + url;
        return msg;
    },

    formatDateTime: function() {
        var gdt = new GlideDateTime();
        return gdt.getLocalDate() + ' ' + gdt.getLocalTime().getByFormat('hh:mm:ss');
    },

    sendHookMessage: function(message, method) {
        var restMessage = new sn_ws.RESTMessageV2('Slack Webhooks', method);
        //restMessage.setLogLevel('all');   // more verbose outbound http logging
		restMessage.setStringParameter('message', message);
        var response = this.sendRestMsg(restMessage);

        try {
            response = restMessage.execute();
        } catch(ex) {
            return 'API exception: ' + ex.getMessage();
        }

        return ' API status: ' + response.getStatusCode();
    },

    type: 'u_Slack_Integration'
};
