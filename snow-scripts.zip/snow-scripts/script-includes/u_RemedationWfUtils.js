var u_RemediationWfUtils = Class.create();

u_RemediationWfUtils.prototype = {
	initialize: function() {
	},

	// resolve an alert's incident
    // @current - remediation task record
	resolveIncident: function(current, worknotes) {
        var alert = new GlideRecord('em_alert');
        alert.get(current.alert);
        var gr = new GlideRecord('incident');
        if (gr.get(alert.incident)) {
			gr.work_notes.setJournalEntry(worknotes);
	        // set required fields
	        if (gs.nil(gr.cmdb_ci)) {
		       gr.cmdb_ci = gs.getProperty('nordstrom.notlisted.ci');
	        }
			gr.assigned_to = 'Event Management';
			gr.state = 6; // resolved
			gr.close_code = 'Closed/Resolved by Caller';
			gr.close_notes = 'Resolved by running remediation script';
			gr.update();
		}
	},

	// update an alert's incident
    // @current - remediation task record
	updateIncident: function(current, worknotes) {
        var alert = new GlideRecord('em_alert');
        alert.get(current.alert);
        var gr = new GlideRecord('incident');
        if (gr.get(alert.incident)) {;
			gr.work_notes.setJournalEntry(worknotes);
			gr.update();
		}
	},

    type: 'u_RemediationWfUtils'
};
