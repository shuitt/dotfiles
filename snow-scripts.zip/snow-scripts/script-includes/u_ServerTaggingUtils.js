var u_ServerTaggingUtils = Class.create();
// server tagging related utilities
u_ServerTaggingUtils.prototype = {
	initialize: function(source) {
		this.ci_table = 'cmdb_ci_server';
		this.tag_table = 'u_server_tagging';
		this.ip_table = 'u_server_tagging_ips_to_discover';
		this.grp_table = 'sys_user_group';
		this.apps_table = 'u_applications';
		this.hosts_apps_table = 'u_m2m_server_hosts_apps';
		this.ci_rel_table = 'cmdb_rel_ci';
		this.app_table = 'cmdb_ci_appl';
		this.cl_node_table = 'cmdb_ci_cluster_node';
		this.cl_node_res_table = 'cmdb_ci_cluster_node_resource';
	},

	// find a server ci with the given name
	findServerCI: function(server_name) {
		var gr = new GlideRecord(this.ci_table);
		gr.addQuery('name', server_name);
		gr.query();
		if (gr.next()) {
			return gr.getUniqueValue();
		} else {
			return null;
		}
	},

	// find a server tagging record with the given name
	findTaggedServer: function(server_name) {
		var gr = new GlideRecord(this.tag_table);
		gr.addQuery('u_server_name', server_name);
		gr.query();
		if (gr.next()) {
			return gr.getUniqueValue();
		} else {
			return null;
		}
	},

	// add a server tagging record ref to a server ci
	addRefToCI: function(ci_id, tags_id) {
		var gr = new GlideRecord(this.ci_table);
		gr.addQuery('sys_id', ci_id);
		gr.query();
		if (gr.next()) {
			gr.u_server_tags = tags_id;
			return gr.update();
		} else {
			return null;
		}
	},

	// upd server ci support groups
	updCiSupp_grp: function(ci_id, grp_id) {
		var gr = new GlideRecord(this.ci_table);
		gr.addQuery('sys_id', ci_id);
		gr.query();
		if (gr.next()) {
			//gs.log('u_server_supp_grp_chgd: updCiSupp_grp: update server ' + gr.name);
			gr.support_group = grp_id;
			gr.setWorkflow(false);
			return gr.update();
		} else {
			return null;
		}
	},

	// find cis running on the given server and udpate support group
	updHostedCisSupp_grps: function(server_id, grp_id) {
		var gr = new GlideRecord(this.ci_rel_table);
		gr.addQuery('child', server_id);
		gr.query();
		//gs.log('u_server_supp_grp_chgd: updHostedCisSupp_grps: found ' + gr.getRowCount() + ' hosted CIs');
		while (gr.next()) {
			//gs.log('u_server_supp_grp_chgd: updHostedCisSupp_grps: parent: ' + gr.parent.name + ', type: ' + gr.type.parent_descriptor + ', sys_id: ' + gr.parent);
			//gs.log('u_server_supp_grp_chgd: updHostedCisSupp_grps: child: ' + gr.child.name + ', sys_id: ' + gr.child);
			// only want cis with a 'runs on' relationship
	        if (gr.type.parent_descriptor == 'Runs on') {
	            //gs.log('u_server_supp_grp_chgd: updHostedCisSupp_grps: update parent support group');
				this.updRunsOnCI(gr.parent, grp_id);
	        }
		}
	},

	// update the support group for a ci running on a server
	updRunsOnCI: function(ci_id, grp_id) {
		//gs.log('u_server_supp_grp_chgd: updRunsOnCI: ci sys_id: ' + ci_id + ', support group sys_id: ' + grp_id);
		var gr = new GlideRecord(this.app_table);
		gr.addQuery('sys_id', ci_id);
		gr.query();
		while (gr.next()) {
			//gs.log('u_server_supp_grp_chgd: updRunsOnCI: update ' + gr.name + ' support group ' + grp_id);
			gr.support_group = grp_id;
			gr.update();
		}
	},

	// add a ci ref to a server tagging record
	addRefServer: function(tags_id, ci_id) {
		var gr = new GlideRecord(this.tag_table);
		gr.addQuery('sys_id', tags_id);
		gr.query();
		if (gr.next()) {
			gr.u_server_ci = ci_id;
			return gr.update();
		} else {
			return null;
		}
	},

	// create a new server tagging record
	createTaggedServer: function(server_name, ci_id) {
		id = this.findTaggedServer(server_name);
		if (id != null) {
			return id;
		}
		var gr = new GlideRecord(this.tag_table);
		gr.newRecord();
		gr.u_server_name = server_name;
		gr.u_server_ci = ci_id;
		gr.setWorkflow(false);    // do not run biz rules
		return gr.insert();
	},

	// flag the given server as decommissioned
	dcomTaggedServer: function(server_name) {
		var gr = new GlideRecord(this.tag_table);
		gr.addQuery('u_server_name', server_name);
		gr.query();
		if (gr.next()) {
			gr.u_decommissioned = true;
			gr.u_decommission_date = new GlideDateTime();
			return gr.update();
		} else {
			return null;
		}
	},

	// delete a server tagging record with the given name
	delTaggedServer: function(server_name) {
		var gr = new GlideRecord(this.tag_table);
		gr.addQuery('u_server_name', server_name);
		gr.query();
		if (gr.next()) {
			gr.deleteRecord();
		}
	},

	// get the sys_id of the given group
	getGroupId: function(group) {
		var gr = new GlideRecord(this.grp_table);
		gr.addQuery('name', group);
		gr.query();
		if (gr.next()) {
			return gr.sys_id;
		} else {
			return null;
		}
	},

	// get the sys_id of the given application
	getAppId: function(app) {
		var gr = new GlideRecord(this.apps_table);
		gr.addQuery('u_long_name', app);
		gr.query();
		if (gr.next()) {
			return gr.sys_id;
		} else {
			return null;
		}
	},

	// add an association between the given app and server
	tagToApp: function(server, app) {
		var gr = new GlideRecord(this.hosts_apps_table);
		gr.newRecord();
		gr.u_hosted_application = app;
		gr.u_hosting_server = server;
		return gr.insert();
	},

	// insert a record in the tagging ips to discover table
	addToIpTable: function(ip_addr) {
		var gr = new GlideRecord(this.ip_table);
		gr.newRecord();
		gr.u_ip_address = ip_addr;
		return gr.insert();
	},

	// find a cluster node CI that includes refs specified server. if found update
	// the support group for cluster node CI and refed cluster CI with specified group
	updateClNodeCi: function(server_id, grp_id) {
		gs.log('u_server_supp_grp_chgd 5a: updateClNodeCi');
		var gr = new GlideRecord(this.cl_node_table);
		gr.addQuery('server', server_id);
		gr.query();
		if (gr.next()) {
			//gs.log('u_server_supp_grp_chgd 5b: update cluster node ' + gr.name);
			//update cluster node
			gr.support_group = grp_id;
			gr.update();
			//update referenced cluster
			//gs.log('u_server_supp_grp_chgd 5c: update cluster ' + gr.cluster.name);
			var cl = gr.cluster.getRefRecord(); //Returns the GlideRecord the referenced cluster
			cl.support_group = grp_id;
			cl.update();
			return gr.getUniqueValue();
		} else {
			//gs.log('u_server_supp_grp_chgd 5d: no cluster found');
			return null;
		}
	},

	// find cluster node resources that ref the specified cluster node. if found
	// update the support group of all cluster resources refed by the cluster node resource
	updateClResCi: function(node_id, grp_id) {
		//gs.log('u_server_supp_grp_chgd 6a: updateClResCi');
		var gr = new GlideRecord(this.cl_node_res_table);
		gr.addQuery('cluster_node', node_id);
		gr.query();
		//gs.log('u_server_supp_grp_chgd 6b: found ' + gr.getRowCount() + ' cluster resources');
		while (gr.next()) {
			//for each match update referenced cluster resource
			var res = gr.cluster_resource.getRefRecord();
			//gs.log('u_server_supp_grp_chgd 6c: update cluster resrouce ' + res.name);
		 	res.support_group = grp_id;
			res.update();
		}
	},

    type: 'u_ServerTaggingUtils'
};
