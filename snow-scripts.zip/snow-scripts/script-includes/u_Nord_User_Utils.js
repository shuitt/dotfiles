var u_Nord_User_Utils = Class.create();
u_Nord_User_Utils.prototype = {
	initialize: function() {
	},

	// user is a user sys_id
	getUserVP: function(user_id) {
		var logmsg = '';
		var user = user_id;
		var vpFound = false;
		var safeCounter = 0;
		var vpUser = '';
		var gr = new GlideRecord('sys_user');

		while(vpFound == false){
			safeCounter++;
			gr.initialize();
			gr.get(user);
			var jobTitle = gr.u_job.u_job_title.toLowerCase();
			logmsg += '\nuser is: ' + gr.sys_id + ', name: ' + gr.name + ', title: ' + jobTitle;

			if(jobTitle.indexOf('vp') != -1 || jobTitle.indexOf('president') != -1) {
				vpUser = gr.sys_id + '';
				vpFound = true;
			} else {
				user = gr.manager.sys_id + '';
			}

			if (safeCounter > 10) {
				vpFound = true;
			}
		}

		logmsg += '\nVP: ' + vpUser;
		//gs.log(logmsg);
		return vpUser;
	},

	type: 'u_Nord_User_Utils'
};
