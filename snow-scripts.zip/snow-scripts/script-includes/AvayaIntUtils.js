var AvayaIntUtils = Class.create();
AvayaIntUtils.prototype = {
	/*
    this function is called by CTI Processing biz rule script. it inserts a new
    record into the Call table (new_call),

    Note that this script must not be client-callable and available to all application scopes.
	*/
	u_CTI_Create_Call: function() {
		var grCall = new GlideRecord('new_call');
		grCall.newRecord();
		grCall.caller = cti_sys_id;
		grCall.u_employee = cti_emp_nbr;
		grCall.u_lan_id = cti_lan_id;
		var callId = grCall.insert();
		return callId;
	},

    type: 'AvayaIntUtils'
};
