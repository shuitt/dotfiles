(function(){
    // delete pd services that have not been updated for a week
    function delServices() {
        var gr = new GlideRecord('u_pagerduty_services');
        gr.addEncodedQuery('u_last_pd_update<javascript:gs.daysAgoStart(7)');
        gr.query();
        logMsg += '\nDeleting ' + gr.getRowCount() + ' records from the PagerDuty Services table';
        gr.deleteMultiple();
    }

    // delete pd escalation policies that have not been updated for a week
    function delPolciies() {
        var gr = new GlideRecord('u_pagerduty_escalation_policies');
        gr.addEncodedQuery('u_last_pd_update<javascript:gs.daysAgoStart(7)');
        gr.query();
        logMsg += '\nDeleting ' + gr.getRowCount() + ' records from the PagerDuty Escalation policies table';
        gr.deleteMultiple();
    }

    // delete pd on-calls that were not created today
    function delOncalls() {
        var gr = new GlideRecord('u_pagerduty_on_calls');
        gr.addEncodedQuery('sys_created_onNOTONToday@javascript:gs.daysAgoStart(0)@javascript:gs.daysAgoEnd(0)');
        gr.query();
        logMsg += '\nDeleting ' + gr.getRowCount() + ' records from the PagerDuty On-calls table';
        gr.deleteMultiple();
    }

    // delete pd teams that have not been updated for a week
    function delTeams() {
        var grMbrs = new GlideRecord('u_pagerduty_team_members');
        var gr = new GlideRecord('u_pagerduty_teams');
        gr.addEncodedQuery('u_last_pd_update<javascript:gs.daysAgoStart(7)');
        gr.query();
        logMsg += '\nDeleting ' + gr.getRowCount() + ' records from the PagerDuty Teams table';
        while (gr.next()) {
            // delete memberships for the team
            grMbrs.initialize();
            grMbrs.addQuery('u_team_id', gr.u_id);
            grMbrs.query();
            logMsg += '\nDeleting ' + grMbrs.getRowCount() + ' memberships from team ' + gr.u_id;
            grMbrs.deleteMultiple();
            // then delete the team
            gr.deleteRecord();
        }
    }

    // delete pd users that have not been updated for a week
    function delUsers() {
        var grMbrs = new GlideRecord('u_pagerduty_team_members');
        var gr = new GlideRecord('u_pagerduty_users');
        gr.addEncodedQuery('u_last_pd_update<javascript:gs.daysAgoStart(7)');
        gr.query();
        logMsg += '\nDeleting ' + gr.getRowCount() + ' records from the PagerDuty Users table';
        while (gr.next()) {
            // delete memberships for the user
            grMbrs.initialize();
            grMbrs.addQuery('u_user_id', gr.u_id);
            grMbrs.query();
            logMsg += '\nDeleting ' + grMbrs.getRowCount() + ' memberships for user ' + gr.u_id;
            grMbrs.deleteMultiple();
            // then delete the user
            gr.deleteRecord();
        }
    }

    var logMsg = 'PagerDuty On-call Cleanup: script starting';
    delTeams();
    delServices();
    delPolciies();
    delUsers();
    delOncalls();
    logMsg += '\nScript done';
    gs.log(logMsg);
}())
