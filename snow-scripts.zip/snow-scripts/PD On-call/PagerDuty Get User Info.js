(function(){
    var logMsg = 'PagerDuty List Users: script starting';
    var apiKey = gs.getProperty('u_nord.pagerduty.oncall.api.key');
	var response = null;
    var queryLimit = 350;
    // only want users last updated from pagerduty today and where the contact methods were not updated to or the
    // contact methods updatedd field is empty
    var queryStr =  'u_last_pd_updateONToday@javascript:gs.daysAgoStart(0)@javascript:gs.daysAgoEnd(0)^u_contact_methods_updated<javascript:gs.daysAgoStart(0)^ORu_contact_methods_updatedISEMPTY';

    var curDate = new GlideDateTime();

    var gr = new GlideRecord('u_pagerduty_users');
    gr.addEncodedQuery(queryStr);
    gr.setLimit(queryLimit);
    gr.query();
    var userCount = gr.getRowCount();
    logMsg += '\nUpdating ' + userCount + ' user records';

    while (gr.next()) {
		var restMessage = new sn_ws.RESTMessageV2('PagerDuty Get User', 'get');
		restMessage.setLogLevel('all');
        restMessage.setStringParameter('key', apiKey);
        restMessage.setStringParameter('id', gr.u_id);

        try {
            response = restMessage.execute();
        } catch(ex) {
            logMsg += '\nREST message exception: ' + ex.getMessage();
            gs.error(logMsg);
            return;
        }

        var httpStatus = response.getStatusCode();
        if (httpStatus == 200) {
            var parsed = JSON.parse(response.getBody());      // convert JSON response to javascript object
            var user = parsed.user;
            var conMeths = user.contact_methods;
            var methCnt = conMeths.length;

            var methods = [];
            for (var i = 0; i < methCnt; i++) {
                // filter methods by type and replace with friendly type
                switch (conMeths[i].type) {
                    case 'email_contact_method':
                        methods.push('Email: ' + conMeths[i].address + ' (' + conMeths[i].label + ')');
                        break;
                    case 'phone_contact_method':
                        methods.push('Phone: ' + conMeths[i].address + ' (' + conMeths[i].label + ')');
                        break;
                    case 'sms_contact_method':
                        methods.push('SMS: ' + conMeths[i].address + ' (' + conMeths[i].label + ')');
                        break;
                    default:
                }
            }
            gr.u_contact_methods = methods.join('\n');
            gr.u_contact_methods_updated = curDate;
            gr.update();
        }
    }
    // if there could be more users to process trigger another job
    if (userCount >= queryLimit) {
        var job = new GlideRecord('sysauto_script');
        job.get('name', 'PagerDuty List On-calls');
        var jobId = SncTriggerSynchronizer.executeNow(job);
        logMsg += '\nTriggered new job, job sys_id = ' + jobId;
    }
    logMsg += '\nScript done';
    gs.log(logMsg);
}())
