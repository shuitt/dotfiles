(function(){
    function delAll(table, label) {
        var gr = new GlideRecord(table);
        gr.query();
        gs.print('Deleting ' + gr.getRowCount() + ' records from the ' + label + ' table);')
        gr.deleteMultiple();
    }

    gs.print('Starting script');
    delAll('u_pagerduty_teams', 'PagerDuty Teams');
    delAll('u_pagerduty_services', 'PagerDuty Services');
    delAll('u_pagerduty_escalation_policies', 'PagerDuty Escalation Policies');
    delAll('u_pagerduty_users', 'PagerDuty Users');
    delAll('u_pagerduty_team_members', 'PagerDuty Team Members');
    delAll('u_pagerduty_on_calls', 'PagerDuty On-calls');
    gs.print('Script done');
}())
