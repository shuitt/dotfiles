(function(){
    var logMsg = 'PagerDuty List Escalation Policies: script starting';
    var inserts = 0;
    var updates = 0;
    var calls = 0;          // number of times teh api has been called
    var maxCalls = 15;      // max times to call api before exiting
    var more = true;        // in response, indicates there is more data
    var limit = 100;        // query parm, number of records to iclude in response
    var offset = 0;         // query parm, offset to next set of records
	var response = null;
    var apiKey = gs.getProperty('u_nord.pagerduty.oncall.api.key');
    var curDate = new GlideDateTime();
    var gr = new GlideRecord('u_pagerduty_escalation_policies');

    while (more) {
		var restMessage = new sn_ws.RESTMessageV2('PagerDuty List Escalation Policies', 'get');
		restMessage.setLogLevel('all');
        restMessage.setStringParameter('key', apiKey);
        restMessage.setStringParameter('limit', limit.toString());
        restMessage.setStringParameter('offset', offset.toString());
        try {
            response = restMessage.execute();
        } catch(ex) {
            logMsg += '\nREST message exception: ' + ex.getMessage();
            gs.error(logMsg);
            return;
        }

        var httpStatus = response.getStatusCode();
        if (httpStatus != 200) {
            logMsg += '\nAPI error, HTTP status = ' + httpStatus + ', exiting script';
            gs.error(logMsg);
            return;
        }

        calls += 1;
        var parsed = JSON.parse(response.getBody());      // convert JSON response to javascript object
        more = parsed.more;
        offset += parsed.limit;
        var policies = parsed.escalation_policies;
        var recCount = policies.length;
        logMsg += '\nHTTP status = ' + httpStatus + ', number of ecalation policies: ' + recCount;
        logMsg += '\nMore=' + more + ', offset=' + parsed.offset + ', limit=' + parsed.limit;

        if (recCount > 0) {
            for (var i = 0; i < recCount; i++) {
                gs.print('PD List Escalation Policies: policy name = ' + policies[i].name + ', ID = ' + policies[i].id);
                gr.initialize();
                gr.addQuery('u_id', policies[i].id);
                gr.setLimit(1);
                gr.query();
                if (gr.next()) {
                    gr.u_name = policies[i].name;
                    gr.u_description = policies[i].description;
                    gr.u_summary = policies[i].summary;
                    gr.u_last_pd_update = curDate;
                    gr.update();
                    updates += 1;
                } else {
                    gr.newRecord();
                    gr.u_id = policies[i].id;
                    gr.u_name = policies[i].name;
                    gr.u_description = policies[i].description;
                    gr.u_summary = policies[i].summary;
                    gr.u_last_pd_update = curDate;
                    gr.insert();
                    inserts += 1;
                }
            }
        }
        if (calls >= maxCalls) {
            logMsg += '\nMax API calls (' + maxCalls + ') exceeded - script terminating';
            more = false;
        }
    }
    logMsg += '\nUpdated escalation policies = ' + updates + ', new escalation policies = ' + inserts;
    logMsg += '\nScript done';
    gs.log(logMsg);
}())
