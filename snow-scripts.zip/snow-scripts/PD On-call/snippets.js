gs.print('Script starting');
var gdt = new GlideDateTime();
gdt.addDaysLocalTime(-1);
gs.print('Setting escalation policy on-call updated to ' + gdt.getDate().toString());
var gr = new GlideRecord('u_pagerduty_escalation_policies');
gr.query();
gs.print('Updating ' + gr.getRowCount() + ' escalation policies');
gr.setValue('u_on_call_updated',  gdt);
gr.updateMultiple();
gs.print('Script finished');



var gdt = new GlideDateTime();
gs.print(gdt);
gs.print(gdt.getDate());
var dt = new GlideDateTime(gdt.getDate() + ' 00:00:00');
gs.print(dt);

var curDate = new GlideDateTime();
var gdtUntil = new GlideDateTime();
gdtUntil.addWeeksLocalTime(2);
var until = gdtUntil.getDate().toString();      // get on-calls until this date
var gdtStart = new GlideDateTime(curDate.getDate().toString() + ' 00:00:00');   // default start date
var gdtend = new GlideDateTime(until + ' 23:59:59');
gs.print('until = ' + until);
gs.print('start = ' + gdtStart);
gs.print('end   = ' + gdtend);


gs.print(gdt.getTZOffset());
gs.print(gdt.getNumericValue());
gdt.add(gdt.getTZOffset());
gs.print(gdt.getNumericValue());
gs.print(gdt);
gs.print(gdt.getDate());
gs.print(gdt.getDate().toString());



// "start": "2017-07-24T09:00:00-07:00"
var end = "2017-07-31T09:00:00-07:00";
var y = end.split('T');
var t = y[1].split('-');
gs.print(y[0]);
gs.print(t[0]);
d = y[0] + ' ' + t[0];
gs.print(d);
var gdt = new GlideDateTime(d);
gs.print(gdt);

var w = "the quick brown fox";
var x = "";
var y = null;
var z;

gs.print("w = '" + w + "', JSUtil.nil(w) = " + JSUtil.nil(w));
gs.print("x = '" + x + "', JSUtil.nil(x) = " + JSUtil.nil(x));
gs.print("y = '" + y + "', JSUtil.nil(y) = " + JSUtil.nil(y));
gs.print("z = '" + z + "', JSUtil.nil(z) = " + JSUtil.nil(z));


var grEP = new GlideRecord('u_pd_service_escalation_policies');
grEP.setLimit(10);
grEP.query();
while (grEP.next) {
    gs.print('policy ID: ' + grEP.u_escalation_policy_id);
}


(function(){
    gs.print('trigger script starting');
    var rec = new GlideRecord('sysauto_script');
    rec.get('name', 'PD List Teams');
    gs.print('triggering script');
    //var i = SncTriggerSynchronizer.executeNow(rec);
    var i = gs.executeNow(rec);
    gs.print('script triggered, job sys_id = ' + i);
}())

(function(){
    var gr = new GlideRecord('u_pagerduty_users');
    gr.addEncodedQuery('u_last_pd_updateONToday@javascript:gs.daysAgoStart(0)@javascript:gs.daysAgoEnd(0)^u_contact_methods_updated<javascript:gs.daysAgoStart(0)^ORu_contact_methods_updatedISEMPTY');
    gr.query();
    gs.print('found ' + gr.getRowCount() + ' records');
}())
