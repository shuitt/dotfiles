(function(){
    // update team members table
    function addTeamMbr(user_id, team_id) {
        var gr = new GlideRecord('u_pagerduty_team_members');
        gr.addQuery('u_user_id', user_id);
        gr.addQuery('u_team_id', team_id);
        gr.setLimit(1);
        gr.query();
        if (!gr.next()) {
            gr.newRecord();
            gr.u_user_id = user_id;
            gr.u_team_id = team_id;
            gr.insert();
        }
    }

    var logMsg = 'PagerDuty List Users: script starting';
    var inserts = 0;
    var updates = 0;
    var calls = 0;          // number of times teh api has been called
    var maxCalls = 30;      // max times to call api before exiting
    var more = true;        // in response, indicates there is more data
    var limit = 100;        // query parm, number of records to iclude in response
    var offset = 0;         // query parm, offset to next set of records
	var response = null;
    var apiKey = gs.getProperty('u_nord.pagerduty.oncall.api.key');
    var curDate = new GlideDateTime();
    var gr = new GlideRecord('u_pagerduty_users');

    while (more) {
		var restMessage = new sn_ws.RESTMessageV2('PagerDuty List Users', 'get');
		restMessage.setLogLevel('all');
        restMessage.setStringParameter('key', apiKey);
        restMessage.setStringParameter('limit', limit.toString());
        restMessage.setStringParameter('offset', offset.toString());

        try {
            response = restMessage.execute();
        } catch(ex) {
            logMsg += '\nREST message exception: ' + ex.getMessage();
            gs.error(logMsg);
            return;
        }

        var httpStatus = response.getStatusCode();
        if (httpStatus != 200) {
            logMsg += '\nAPI error, HTTP status = ' + httpStatus + ', exiting script';
            gs.error(logMsg);
            return;
        }

        calls += 1;
        var parsed = JSON.parse(response.getBody());      // convert JSON response to javascript object
        more = parsed.more;
        offset += parsed.limit;
        users = parsed.users;
        var recCount = users.length;
        logMsg += '\nHTTP status = ' + httpStatus + ', number of users: ' + recCount;
        logMsg += '\nMore=' + more + ', offset=' + parsed.offset + ', limit=' + parsed.limit;

        if (recCount > 0) {
            for (var i = 0; i < recCount; i++) {
                gr.initialize();
                gr.addQuery('u_id', users[i].id);
                gr.setLimit(1);
                gr.query();
                if (gr.next()) {
                    gr.u_name = users[i].name;
                    gr.u_last_pd_update = curDate;
                    gr.update();
                    updates += 1;
                } else {
                    gr.newRecord();
                    gr.u_id = users[i].id;
                    gr.u_name = users[i].name;
                    gr.u_last_pd_update = curDate;
                    gr.insert();
                    inserts += 1;
                }
                var teams = users[i].teams;
                var teamCnt = teams.length;
                if (teamCnt > 0) {
                    for (var j = 0; j < teamCnt; j++) {
                        addTeamMbr(users[i].id, teams[j].id);
                    }
                }
            }
        }
        if (calls >= maxCalls) {
            logMsg += '\nMax API calls (' + maxCalls + ') exceeded - script terminating';
            more = false;
        }
    }
    logMsg += '\nUpdated users = ' + updates + ', new users = ' + inserts;
    logMsg += '\nScript done';
    gs.log(logMsg);
}())
