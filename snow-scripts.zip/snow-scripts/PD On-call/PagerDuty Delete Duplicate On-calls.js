(function(){
	var logMsg = 'PagerDuty Delete Duplicate On-calls: script starting';
	var count = 0;
	var gr = new GlideAggregate('u_pagerduty_on_calls');
	var gr2 = new GlideAggregate('u_pagerduty_on_calls');
	gr. groupBy('u_escalation_policy_id');
	gr. groupBy('u_pd_user_id');
	gr. groupBy('u_level');
	gr. groupBy('u_start_date');
	gr. groupBy('u_end_date');
	gr.query();
	logMsg += '\nUnique records: ' + gr. getRowCount();
	while (gr.next()) {
		gr2.initialize();
		gr2.addQuery('u_escalation_policy_id', gr.u_escalation_policy_id);
		gr2.addQuery('u_pd_user_id', gr.u_pd_user_id);
		gr2.addQuery('u_level', gr.u_level);
		gr2.addQuery('u_start_date', gr.u_start_date);
		gr2.addQuery('u_end_date', gr.u_end_date);
		gr2.query();
		if (gr2.next()) {
			while (gr2.next()) {
				gr2.deleteRecord();
				count += 1;
			}
		}
	}
	logMsg += '\nDuplicate records deleted: ' + count;
	gs.log(logMsg);
}())
