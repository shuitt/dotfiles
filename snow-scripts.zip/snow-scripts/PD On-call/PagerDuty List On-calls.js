(function(){
    // return a glidedate object from a pagerduty date string "yyyy-mm-ddTHH:MM:SS-oo:oo"
    function makeGDT(dateString) {
        var y = dateString.split('T');      // y[0] is yyyy-mm-dd
        var t = y[1].split('-');            // t[0] is HH:MM:SS
        d = y[0] + ' ' + t[0];
        var gdt = new GlideDateTime(d);
        gdt.add(-1 * gdt.getTZOffset());
        return gdt;
    }

    var logMsg = 'PagerDuty List On-calls: script starting';
    var apiKey = gs.getProperty('u_nord.pagerduty.oncall.api.key');
    // get esclation polciies where on-call updated is before today or on-call updated is empty
    var queryStr = 'u_on_call_updated<javascript:gs.daysAgoStart(0)^ORu_on_call_updatedISEMPTY';
    var queryLimit = 175;

    // set the various date values we'll need
    var gdtUntil = new GlideDateTime();
    gdtUntil.addWeeksLocalTime(2);
    var until = gdtUntil.getDate().toString();      // get on-calls until this date
    var curDate = new GlideDateTime();
    var gdtStart = new GlideDateTime(curDate.getDate().toString() + ' 00:00:00');   // default start date
    var gdtend = new GlideDateTime(until + ' 23:59:59');       // default end date

    var gr = new GlideRecord('u_pagerduty_on_calls');
    var grEP = new GlideRecord('u_pagerduty_escalation_policies');
    grEP.addEncodedQuery(queryStr);
    grEP.setLimit(queryLimit);
    grEP.query();
    var polCount = grEP.getRowCount();
    logMsg += '\nGetting on-call users for  ' + polCount + ' escalation policies';

    while (grEP.next()) {
        grEP.u_on_call_updated = new GlideDateTime();
        grEP.update();
        var more = true;
        var limit = 100;
        var offset = 0;
    	var response = null;

        while (more) {
    		var restMessage = new sn_ws.RESTMessageV2('PagerDuty List On-Calls', 'get');
    		restMessage.setLogLevel('all');
            restMessage.setStringParameter('key', apiKey);
            restMessage.setStringParameter('limit', limit.toString());
            restMessage.setStringParameter('offset', offset.toString());
            restMessage.setStringParameter('until', until);
            restMessage.setStringParameter('polid', grEP.u_id);
            offset += limit;

            try {
                response = restMessage.execute();
            } catch(ex) {
                logMsg += '\nREST message exception: ' + ex.getMessage();
                gs.error(logMsg);
                return;
            }

            var httpStatus = response.getStatusCode();
            if (httpStatus != 200) {
                logMsg += '\nAPI error, HTTP status = ' + httpStatus + ', exiting script';
                gs.error(logMsg);
                return;
            }

            var parsed = JSON.parse(response.getBody());      // convert JSON response to javascript object
            more = parsed.more;
            var oncall = parsed.oncalls;
            var recCount = oncall.length;

            if (recCount > 0) {
                for (var i = 0; i < recCount; i++) {
                    gr.newRecord();
                    gr.u_escalation_policy_id = oncall[i].escalation_policy.id;
                    gr.u_user_id = oncall[i].user.id;
                    gr.u_level = oncall[i].escalation_level;
                    if (JSUtil.notNil(oncall[i].start)) {
                        gr.u_start = makeGDT(oncall[i].start);
                    } else {
                        gr.u_start = gdtStart;     // use default start for users always on-call
                    }
                    if (JSUtil.notNil(oncall[i].end)) {
                        gr.u_end = makeGDT(oncall[i].end);
                    } else {
                        gr.u_end = gdtend;         // use default end for users always on-call
                    }
                    gr.insert();
                }
            }
        }
    }
    // if there could be more escalation policies to process trigger another job
    if (polCount >= queryLimit) {
        var job = new GlideRecord('sysauto_script');
        job.get('name', 'PagerDuty List On-calls');
        var jobId = SncTriggerSynchronizer.executeNow(job);
        logMsg += '\nTriggered new job, job sys_id = ' + jobId;
    }
    logMsg += '\nScript done';
    gs.log(logMsg);
}())
